# Introduction 
The CI/CD pipelines we use for building and delivering our software are based on the _Pipelines-as-code_ concept for which we use the `Azure Pipelines` implementation.

Scripting our CI/CD pipelines enables us to write our pipelines once and then reuse them.

This project is the pipeline library where we keep all of our pipeline scripts.

# Getting Started
In order to connect a project to an existing CI/CD pipeline from our pipeline library you need to:

* Create a file called `azure-pipelines.yml` in the root of the project
* Refer to our pipeline library by adding the following to the newly created file:

    ```
    resources:
      repositories:
        - repository: kyca-pipelines-ng
          type: git
          name: Investments/kyca-pipelines-ng
    ```

# Usage
Different software components require different CI/CD pipelines.

Commonly shared components have no need to be deployed to an environment like CF for example, whereas our microservices do have.

The list below shows the various types of software components we support and have built a type specific pipeline script for.

* Maven parent POM files

## Maven parent POM files
To use the pre-defined pipeline script for a Maven parent POM project add the following to the `azure-pipelines.yml`file.

```
stages:
  - template: templates/pom.yml@kyca-pipelines-ng
```

## Common software components
To use the pre-defined pipeline script for a common software component project add the following to the `azure-pipelines.yml`file.

```
stages:
  - template: templates/commons.yml@kyca-pipelines-ng
```

# Azure Pipelines Library configuration
Our pipeline scripts use _Variable groups_ and _Secure files_ which are configured in the _Azure Pipelines Library_ section.

## Variable groups
In the _Variable group_ section there is a group called `Kyca Credentials` where we store the usernames, passwords and tokens we use in our pipeline scripts.

Any job that needs credentials or a token (to be able to deploy an artifact to Nexus for example) can reference our _Variable group_ by adding the following to the configuration of that job:

```
variables:
- group: Kyca Credentials
```

## Secure files
### kyca-maven-settings.xml
In the _Secure files_ section there is a file called `kyca-maven-settings.xml` which is the Maven settings.xml file we use in our pipeline scripts.

Any job that interacts with Maven can reference this file by adding the following task to the configuration of the step of that job:

```
- task: DownloadSecureFile@1
  displayName: 'Download Maven settings file'
  name: maven_settings
  inputs:
    secureFile: 'kyca-maven-settings.xml'
```

This will download the Maven settings.xml file and make it available in the pipeline's workspace.

When executing the Maven job we can refer to this settings.xml file by adding the following to our Maven command:

```
-s $(maven_settings.secureFilePath)
```

### test-cer.pem
In the _Secure files_ section there is a file called `test-cer.pem` which is the SSL certificate used to deploy our microservices to the `DevTest` environment on CF.

### test-key.pem
In the _Secure files_ section there is a file called `test-cer.pem` which is the SSL key used to deploy our microservices to the `DevTest` environment on CF.

# Azure Pipelines Environments configuration
Our pipeline scripts use different environments for deploying our microservices to CF.

The following environments are configured in the _Azure Pipelines Environments_ section:

* Kyca-Devtest
* Kyca-Production

# Project Settings Service connections configuration
Our pipeline scripts use different service connections for deploying our microservices to CF.

The following service connections are configured in the _Project Settings Service connections_ section:

* cloudfoundry-d06-kyca
* pcf-p01-we-kyca
* pcf-p02-we-kyca
