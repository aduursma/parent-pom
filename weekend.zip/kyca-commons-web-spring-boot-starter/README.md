[![Build Status](https://dev.azure.com/raboweb/Investments/_apis/build/status/expedite-commons-web-spring-boot-starter?repoName=expedite-commons-web-spring-boot-starter&branchName=master)](https://dev.azure.com/raboweb/Investments/_build/latest?definitionId=23025&repoName=expedite-commons-web-spring-boot-starter&branchName=master)

# Introduction
This project is a Spring Boot starter for adding general web configuration to your Spring Boot application.

# Getting Started
Just add this project as a dependency to the Maven project you want to have general web configuration enabled for, replacing the version number with the actual latest version number.

```
<parent>
    <groupId>nl.rabobank.investments.sales</groupId>
    <artifactId>kyca-commons-web-spring-boot-starter</artifactId>
    <version>...</version>
</parent>
```
