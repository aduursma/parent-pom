package nl.rabobank.investments.commons.web.rest.exception

import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import java.time.LocalDateTime

object ErrorResponseUtil {

    fun createErrorResponse(httpStatus: HttpStatus, path: String?): ErrorResponse {
        val errorResponse = ErrorResponse()
        errorResponse.timestamp = LocalDateTime.now()
        errorResponse.status = httpStatus.value()
        errorResponse.error = httpStatus.reasonPhrase
        errorResponse.path = path
        return errorResponse
    }

    fun createErrorResponseHeaders(): HttpHeaders {
        val responseHeaders = HttpHeaders()
        responseHeaders.add("Cache-Control", "no-cache, no-store, max-age=0, must-revalidate")
        responseHeaders.add("Pragma", "no-cache")
        responseHeaders.add("X-Frame-Options", "SAMEORIGIN")
        responseHeaders.add("X-XSS-Protection", "1; mode=block")
        return responseHeaders
    }
}
