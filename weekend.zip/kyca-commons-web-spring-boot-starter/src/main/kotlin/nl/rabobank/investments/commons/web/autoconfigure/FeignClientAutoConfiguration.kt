package nl.rabobank.investments.commons.web.autoconfigure

import feign.Client
import feign.Feign
import feign.Logger
import feign.codec.ErrorDecoder
import java.security.KeyStore
import nl.rabobank.investments.commons.web.feign.FeignClientErrorDecoder
import nl.rabobank.investments.commons.web.properties.SslProperties
import org.apache.http.ssl.SSLContextBuilder
import org.springframework.boot.autoconfigure.AutoConfiguration
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Bean
import org.zalando.logbook.Logbook
import org.zalando.logbook.openfeign.FeignLogbookLogger


@AutoConfiguration
@EnableConfigurationProperties(SslProperties::class)
class FeignClientAutoConfiguration(
    private val keyStore: KeyStore,
    private val sslProperties: SslProperties,
    private val logbook: Logbook
) {

    @Bean
    fun getClient(): Client? {
        val sslContext = SSLContextBuilder.create().apply {
            loadKeyMaterial(keyStore, sslProperties.keystorePassword.toCharArray())
            loadTrustMaterial(null) { _, _ -> true }
        }.build()
        return Client.Default(sslContext.socketFactory, null)
    }

    @Bean
    fun getFeignClient(): Feign? {
        return Feign.builder()
            .logger(FeignLogbookLogger(logbook))
            .client(getClient())
            .build()
    }

    @Bean
    fun feignLoggerLevel(): Logger.Level? {
        return Logger.Level.BASIC
    }

    @Bean
    fun errorDecoder(): ErrorDecoder? {
        return FeignClientErrorDecoder()
    }
}
