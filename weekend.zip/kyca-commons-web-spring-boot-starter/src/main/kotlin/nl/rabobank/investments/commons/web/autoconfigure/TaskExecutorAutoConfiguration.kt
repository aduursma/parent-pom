package nl.rabobank.investments.commons.web.autoconfigure

import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler
import org.springframework.aop.interceptor.SimpleAsyncUncaughtExceptionHandler
import org.springframework.beans.factory.BeanFactory
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.autoconfigure.AutoConfiguration
import org.springframework.cloud.sleuth.instrument.async.LazyTraceExecutor
import org.springframework.scheduling.annotation.AsyncConfigurer
import org.springframework.scheduling.annotation.EnableAsync
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor
import java.util.concurrent.Executor

@EnableAsync
@AutoConfiguration
class TaskExecutorAutoConfiguration : AsyncConfigurer {

    @Value("\${task.executor.core.pool.size:10}")
    private val corePoolSize = 0

    @Value("\${task.executor.max.pool.size:10}")
    private val maxPoolSize = 0

    @Value("\${task.executor.queue.capacity:500}")
    private val queueCapacity = 0

    @Autowired
    private val beanFactory: BeanFactory? = null
    override fun getAsyncExecutor(): Executor {
        val executor = ThreadPoolTaskExecutor()
        executor.corePoolSize = corePoolSize
        executor.maxPoolSize = maxPoolSize
        executor.setQueueCapacity(queueCapacity)
        executor.threadNamePrefix = "Task executor"
        executor.initialize()
        return LazyTraceExecutor(beanFactory, executor)
    }

    override fun getAsyncUncaughtExceptionHandler(): AsyncUncaughtExceptionHandler? {
        return SimpleAsyncUncaughtExceptionHandler()
    }
}
