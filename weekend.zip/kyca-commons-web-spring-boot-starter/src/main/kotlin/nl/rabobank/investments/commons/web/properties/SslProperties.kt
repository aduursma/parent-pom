package nl.rabobank.investments.commons.web.properties

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.boot.context.properties.ConstructorBinding

@ConstructorBinding
@ConfigurationProperties(prefix = "ssl")
data class SslProperties(
    val keystorePassword: String,
)
