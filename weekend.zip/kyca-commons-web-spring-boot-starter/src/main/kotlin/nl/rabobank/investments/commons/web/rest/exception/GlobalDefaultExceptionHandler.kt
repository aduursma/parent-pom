package nl.rabobank.investments.commons.web.rest.exception

import com.fasterxml.jackson.databind.ObjectMapper
import org.apache.commons.lang3.StringUtils
import org.slf4j.LoggerFactory
import org.springframework.core.Ordered
import org.springframework.core.annotation.Order
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.lang.Nullable
import org.springframework.web.bind.UnsatisfiedServletRequestParameterException
import org.springframework.web.bind.annotation.ExceptionHandler
import org.springframework.web.bind.annotation.RestControllerAdvice
import org.springframework.web.client.HttpStatusCodeException
import org.springframework.web.context.request.ServletWebRequest
import org.springframework.web.context.request.WebRequest
import org.springframework.web.server.ResponseStatusException
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler
import java.io.IOException
import java.util.concurrent.CompletionException
import javax.servlet.http.HttpServletRequest
import javax.validation.ConstraintViolationException

@RestControllerAdvice
@Order(Ordered.HIGHEST_PRECEDENCE)
class GlobalDefaultExceptionHandler(private val objectMapper: ObjectMapper) : ResponseEntityExceptionHandler() {

    private val log = LoggerFactory.getLogger(javaClass)

    @ExceptionHandler(UnsatisfiedServletRequestParameterException::class, ConstraintViolationException::class)
    fun handleGlobal(exception: Exception, request: HttpServletRequest): ResponseEntity<ErrorResponse?> {
        log.error(exception.message, exception)
        val entity = ErrorResponseUtil.createErrorResponse(HttpStatus.BAD_REQUEST, request.requestURI)
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).headers(ErrorResponseUtil.createErrorResponseHeaders())
            .body(entity)
    }

    @ExceptionHandler(HttpStatusCodeException::class)
    fun handleHttpStatusCodeException(
        exception: HttpStatusCodeException?,
        request: HttpServletRequest
    ): ResponseEntity<ErrorResponse?> {
        var errorResponse = tryToDeserialize(exception!!.responseBodyAsString)
        if (errorResponse == null) {
            errorResponse = ErrorResponseUtil.createErrorResponse(exception.statusCode, request.requestURI)
        }
        if (StringUtils.isEmpty(errorResponse.message)) {
            val stringBuilder = StringBuilder()
            stringBuilder.append(exception.message)
            if (StringUtils.isNotEmpty(exception.responseBodyAsString)) {
                stringBuilder.append(", body: ")
                stringBuilder.append(exception.responseBodyAsString)
            }
            errorResponse.message = stringBuilder.toString()
        }
        log.error(errorResponse.message, exception)
        return ResponseEntity.status(exception.statusCode).headers(ErrorResponseUtil.createErrorResponseHeaders())
            .body(errorResponse)
    }

    @ExceptionHandler(CompletionException::class)
    fun handleCompletionException(
        exception: CompletionException,
        request: HttpServletRequest
    ): ResponseEntity<ErrorResponse?> {
        return if (exception.cause is HttpStatusCodeException) {
            handleHttpStatusCodeException(exception.cause as HttpStatusCodeException?, request)
        } else {
            log.error(exception.message, exception)
            val entity = ErrorResponseUtil.createErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, request.requestURI)
            entity.message = exception.message
            ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .headers(ErrorResponseUtil.createErrorResponseHeaders()).body(entity)
        }
    }

    @ExceptionHandler(IllegalArgumentException::class)
    fun handleIllegalArgumentException(
        exception: IllegalArgumentException,
        request: HttpServletRequest
    ): ResponseEntity<ErrorResponse?> {
        log.error(exception.message, exception)
        val entity = ErrorResponseUtil.createErrorResponse(HttpStatus.BAD_REQUEST, request.requestURI)
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).headers(ErrorResponseUtil.createErrorResponseHeaders())
            .body(entity)
    }

    @ExceptionHandler(ResponseStatusException::class)
    fun handleResponseStatusException(
        exception: ResponseStatusException,
        request: HttpServletRequest
    ): ResponseEntity<ErrorResponse?> {
        log.error(exception.message, exception)
        val entity = ErrorResponseUtil.createErrorResponse(exception.status, request.requestURI)
        return ResponseEntity.status(exception.status).headers(ErrorResponseUtil.createErrorResponseHeaders())
            .body(entity)
    }

    override fun handleExceptionInternal(
        exception: Exception,
        @Nullable body: Any?,
        headers: HttpHeaders,
        status: HttpStatus,
        request: WebRequest
    ): ResponseEntity<Any> {
        log.error(exception.message, exception)
        val entity = ErrorResponseUtil.createErrorResponse(status, (request as ServletWebRequest).request.requestURI)
        return ResponseEntity.status(status).headers(ErrorResponseUtil.createErrorResponseHeaders()).body(entity)
    }

    private fun tryToDeserialize(errorResponseJson: String): ErrorResponse? {
        return try {
            objectMapper.readValue(errorResponseJson, ErrorResponse::class.java)
        } catch (exception: IOException) {
            null
        }
    }
}
