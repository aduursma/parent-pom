package nl.rabobank.investments.commons.web.rest.config

import com.fasterxml.jackson.annotation.JsonInclude.Include.NON_NULL
import org.apache.http.client.HttpClient
import org.apache.http.impl.client.HttpClients
import org.apache.http.ssl.SSLContextBuilder
import org.slf4j.LoggerFactory
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.http.client.BufferingClientHttpRequestFactory
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory
import org.springframework.http.converter.json.AbstractJackson2HttpMessageConverter
import org.springframework.web.client.RestTemplate
import org.zalando.logbook.spring.LogbookClientHttpRequestInterceptor
import java.security.KeyStore
import javax.net.ssl.SSLContext
import nl.rabobank.investments.commons.web.properties.SslProperties

@Configuration
@EnableConfigurationProperties(SslProperties::class)
class SecuredRestTemplateConfig(
    private val keyStore: KeyStore,
    private val sslProperties: SslProperties
) {
    private val log = LoggerFactory.getLogger(javaClass)

    @Bean
    fun restTemplate(
        logbookClientHttpRequestInterceptor: LogbookClientHttpRequestInterceptor
    ): RestTemplate {
        log.debug("Initializing secured RestTemplate with keystore $keyStore and properties $sslProperties")
        return RestTemplate().apply {
            configureSerialization()
            makeSecure()
            addInterceptors(logbookClientHttpRequestInterceptor)
        }
    }

    private fun RestTemplate.makeSecure() {
        requestFactory = BufferingClientHttpRequestFactory(
            HttpComponentsClientHttpRequestFactory(
                buildSecureHttpClient()
            )
        )
    }

    private fun buildSecureHttpClient(): HttpClient {
        return HttpClients.custom()
            .setSSLContext(buildSSLContext())
            .build()
    }

    private fun buildSSLContext(): SSLContext {
        log.info("load jks file into keystore $keyStore")

        return SSLContextBuilder.create().apply {
            loadKeyMaterial(keyStore, sslProperties.keystorePassword.toCharArray())
            // trust all certificates
            loadTrustMaterial(null) { _, _ -> true }
        }.build()
    }

    private fun RestTemplate.configureSerialization() {
        messageConverters.filterIsInstance<AbstractJackson2HttpMessageConverter>()
            .forEach {
                it.objectMapper.setSerializationInclusion(NON_NULL)
            }
    }

    private fun RestTemplate.addInterceptors(
        logbookClientHttpRequestInterceptor: LogbookClientHttpRequestInterceptor
    ) {
        interceptors.add(logbookClientHttpRequestInterceptor)
    }
}
