package nl.rabobank.investments.commons.web.autoconfigure

import brave.Tracer
import brave.handler.MutableSpan
import brave.handler.SpanHandler
import brave.propagation.TraceContext
import brave.sampler.Sampler
import nl.rabobank.investments.commons.web.tracing.MdcTracingFilter
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.autoconfigure.AutoConfiguration
import org.springframework.context.annotation.Bean

@AutoConfiguration
class TracingAutoConfiguration {

    @Value("\${spring.application.name}")
    private val serviceName: String? = null

    @Value("\${spring.application.version}")
    private val serviceVersion: String? = null

    @Value("\${RABOPCF_LOCALDOMAIN:-}")
    private val pcfLocalDomain: String? = null

    @Value("\${RABOPCF_LOCATION:-}")
    private val pcfLocation: String? = null

    @Value("\${RABOPCF_LOCATION_SHORT:-}")
    private val pcfLocationShort: String? = null

    @Value("\${RABOPCF_SYSTEM_ENV:vdi}")
    private val pcfSystemEnv: String? = null

    @Bean
    fun mdcTracingFilter(tracer: Tracer): MdcTracingFilter {
        return MdcTracingFilter(tracer)
    }

    @Bean
    fun defaultSampler(): Sampler {
        return Sampler.ALWAYS_SAMPLE
    }

    @Bean
    fun handleEnvironmentProperties(): SpanHandler {
        return object : SpanHandler() {
            override fun end(traceContext: TraceContext, span: MutableSpan, cause: Cause): Boolean {
                if (cause == Cause.FINISHED) {
                    span.tag("service_name", serviceName)
                    span.tag("service_version", serviceVersion)
                    span.tag("pcf_local_domain", pcfLocalDomain)
                    span.tag("pcf_location", pcfLocation)
                    span.tag("pcf_location_short", pcfLocationShort)
                    span.tag("pcf_system_env", pcfSystemEnv)
                }
                return true
            }
        }
    }
}
