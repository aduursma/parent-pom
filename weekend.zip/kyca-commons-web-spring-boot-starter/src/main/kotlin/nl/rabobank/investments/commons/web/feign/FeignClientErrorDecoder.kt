package nl.rabobank.investments.commons.web.feign;

import feign.Response
import feign.codec.ErrorDecoder

class FeignClientErrorDecoder(private val errorDecoder: ErrorDecoder = ErrorDecoder.Default()) : ErrorDecoder {
    override fun decode(methodKey: String?, response: Response): Exception {
        //Handle custom exception based on http status code
        return errorDecoder.decode(methodKey, response)
    }
}
