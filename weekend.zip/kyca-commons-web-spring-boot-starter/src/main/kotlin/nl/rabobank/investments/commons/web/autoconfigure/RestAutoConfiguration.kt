package nl.rabobank.investments.commons.web.autoconfigure

import org.springframework.boot.autoconfigure.AutoConfiguration
import org.springframework.context.annotation.ComponentScan

@AutoConfiguration
@ComponentScan("nl.rabobank.investments.commons.web.rest")
class RestAutoConfiguration
