package nl.rabobank.investments.commons.soap

import org.springframework.oxm.Unmarshaller
import org.springframework.ws.FaultAwareWebServiceMessage
import org.springframework.ws.WebServiceMessage
import org.springframework.ws.client.core.WebServiceMessageCallback
import org.springframework.ws.client.core.WebServiceMessageExtractor
import org.springframework.ws.client.core.support.WebServiceGatewaySupport
import org.springframework.ws.soap.SoapMessage
import org.springframework.ws.soap.client.SoapFaultClientException
import org.springframework.ws.support.MarshallingUtils

class SoapConnector : WebServiceGatewaySupport() {

    /**
     * Uses custom requestCallback and Webservice message extractor
     */
    fun callWebService(url: String, callback: WebServiceMessageCallback): Any {
        return webServiceTemplate.sendAndReceive(url, callback, webServiceMessageExtractor())
    }

    /**
     * Change default implementation for handling fault messages correctly
     */
    private fun webServiceMessageExtractor(): WebServiceMessageExtractor<Any> {
        return WebServiceMessageExtractor { response ->
            val unmarshaller: Unmarshaller = unmarshaller
                ?: throw IllegalStateException(
                    "No unmarshaller registered. Check configuration of WebServiceTemplate."
                )
            if (hasFault(response)) throw SoapFaultClientException(response as SoapMessage?)
            else MarshallingUtils.unmarshal(unmarshaller, response)
        }
    }

    /**
     * Checks if webservice response message contains fault
     */
    private fun hasFault(response: WebServiceMessage): Boolean {
        if (response is FaultAwareWebServiceMessage) {
            return response.hasFault()
        }
        return false
    }
}
