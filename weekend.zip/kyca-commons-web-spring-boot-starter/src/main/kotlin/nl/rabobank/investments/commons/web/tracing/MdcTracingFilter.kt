package nl.rabobank.investments.commons.web.tracing

import brave.Tracer
import brave.baggage.BaggageField
import org.apache.logging.log4j.util.Strings
import org.slf4j.LoggerFactory
import org.slf4j.MDC
import org.springframework.web.filter.OncePerRequestFilter
import java.io.IOException
import java.util.Objects
import javax.servlet.FilterChain
import javax.servlet.ServletException
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

class MdcTracingFilter(private val tracer: Tracer) : OncePerRequestFilter() {
    private val log = LoggerFactory.getLogger(javaClass)

    @Throws(ServletException::class, IOException::class)
    override fun doFilterInternal(
        request: HttpServletRequest,
        response: HttpServletResponse,
        filterChain: FilterChain
    ) {
        val sessionId = Objects.toString(request.getHeader(SESSION_ID_HEADER), Strings.EMPTY)
        try {
            log.debug("Adding sessionId: {}", sessionId)
            val extraFields: MutableMap<String, String> = HashMap()
            extraFields["sessionId"] = sessionId
            val span = tracer.currentSpan()
            extraFields.forEach { (key: String?, value: String?) ->
                span.tag(key, value)
                BaggageField.getByName(span.context(), key)?.updateValue(value)
                MDC.put(key, value)
            }
            filterChain.doFilter(request, response)
        } finally {
            log.debug("Clearing MDC")
            MDC.clear()
        }
    }

    companion object {
        const val SESSION_ID_HEADER = "x-session-id"
    }
}
