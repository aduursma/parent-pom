package nl.rabobank.investments.commons.web.autoconfigure

import org.springframework.boot.autoconfigure.AutoConfiguration
import org.springframework.boot.web.error.ErrorAttributeOptions
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes
import org.springframework.boot.web.servlet.error.ErrorAttributes
import org.springframework.context.annotation.Bean
import org.springframework.web.context.request.WebRequest

@AutoConfiguration
class ExceptionHandlingAutoConfiguration {

    @Bean
    fun commonsErrorAttributes(): ErrorAttributes {
        return object : DefaultErrorAttributes() {
            override fun getErrorAttributes(request: WebRequest, options: ErrorAttributeOptions): Map<String, Any> {
                val errorAttributes = super.getErrorAttributes(request, options)
                return filterErrorAttributes(errorAttributes, "message")
            }
        }
    }

    private fun filterErrorAttributes(
        errorAttributes: Map<String, Any>,
        vararg attributeNames: String
    ): Map<String, Any> {
        val resultErrorAttributes: MutableMap<String, Any> = HashMap()
        for (attributeName in attributeNames) {
            if (errorAttributes.containsKey(attributeName)) {
                resultErrorAttributes[attributeName] = errorAttributes[attributeName]!!
            }
        }
        return resultErrorAttributes
    }
}
