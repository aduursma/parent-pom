package nl.rabobank.investments.commons.web.rest.client

import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.http.HttpEntity
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpMethod
import org.springframework.http.MediaType
import org.springframework.http.ResponseEntity
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory
import org.springframework.stereotype.Component
import org.springframework.util.MultiValueMap
import org.springframework.web.client.RestTemplate
import java.io.IOException
import java.util.Locale

@Component
@SuppressWarnings("TooManyFunctions")
@Deprecated("Not in use - usage needs to be determined")
class RestClient(val restTemplateWithSSL: RestTemplate, val objectMapper: ObjectMapper) {

    operator fun <T> get(
        uri: String,
        type: Class<T>,
        unfilteredRequestHeaders: HttpHeaders,
        uriVariables: Map<String, Any>
    ): T? {
        val filteredRequestHeaders = filterHttpHeaders(unfilteredRequestHeaders)
        return restTemplateWithSSL.exchange(
            uri, HttpMethod.GET,
            HttpEntity<Any>(filteredRequestHeaders),
            type,
            uriVariables
        ).body
    }

    @Throws(IOException::class)
    fun <T> getList(
        uri: String,
        type: Class<T>,
        unfilteredRequestHeaders: HttpHeaders,
        uriVariables: Map<String, Any>
    ): List<T> {
        val filteredRequestHeaders = filterHttpHeaders(unfilteredRequestHeaders)
        val response = restTemplateWithSSL.exchange(
            uri, HttpMethod.GET,
            HttpEntity<Any>(filteredRequestHeaders),
            String::class.java,
            uriVariables
        )
        return objectMapper.readValue(
            response.body,
            objectMapper.typeFactory.constructCollectionType(MutableList::class.java, type)
        )
    }

    fun <T> post(uri: String, type: Class<T>, unfilteredRequestHeaders: HttpHeaders, requestBody: Any?): T? {
        return post(uri, type, unfilteredRequestHeaders, HashMap(), requestBody)
    }

    fun <T> post(
        uri: String,
        type: Class<T>,
        unfilteredRequestHeaders: HttpHeaders,
        uriVariables: Map<String, Any>,
        requestBody: Any?
    ): T? {
        val filteredRequestHeaders = filterHttpHeaders(unfilteredRequestHeaders)
        filteredRequestHeaders.contentType = MediaType.APPLICATION_JSON
        return restTemplateWithSSL.exchange(
            uri, HttpMethod.POST,
            HttpEntity(requestBody, filteredRequestHeaders),
            type,
            uriVariables
        ).body
    }

    @Throws(IOException::class)
    fun <T> postMultipartForm(
        uri: String,
        type: Class<T>,
        unfilteredRequestHeaders: HttpHeaders,
        uriVariables: Map<String, Any>,
        requestBody: MultiValueMap<String, Any>
    ): T? {
        val filteredRequestHeaders = filterHttpHeaders(unfilteredRequestHeaders)
        return restTemplateWithSSL.exchange(
            uri, HttpMethod.POST,
            HttpEntity(requestBody, filteredRequestHeaders),
            type,
            uriVariables
        ).body
    }

    fun <T> put(
        uri: String,
        type: Class<T>,
        unfilteredRequestHeaders: HttpHeaders,
        uriVariables: Map<String, Any>,
        requestBody: Any?
    ): T? {
        val filteredRequestHeaders = filterHttpHeaders(unfilteredRequestHeaders)
        return restTemplateWithSSL.exchange(
            uri,
            HttpMethod.PUT,
            HttpEntity(requestBody, filteredRequestHeaders),
            type,
            uriVariables
        ).body
    }

    fun patch(uri: String?, requestBody: Any, unfilteredRequestHeaders: HttpHeaders): ResponseEntity<Void> {
        val mediaType = MediaType("application", "merge-patch+json")
        val filteredRequestHeaders = filterHttpHeaders(unfilteredRequestHeaders)
        filteredRequestHeaders.contentType = mediaType

        /*This needs to be done to allow PATCHs, as the default HttpURLConnection does not support PATCHs*/
        restTemplateWithSSL.requestFactory = HttpComponentsClientHttpRequestFactory()
        return restTemplateWithSSL.exchange(
            uri!!, HttpMethod.PATCH,
            HttpEntity(requestBody, filteredRequestHeaders),
            Void::class.java
        )
    }

    fun patch(uri: String?, requestBody: Any): ResponseEntity<Void> {
        val httpHeaders = HttpHeaders()
        httpHeaders.contentType = MediaType("application", "json")
        return restTemplateWithSSL.exchange(
            uri!!, HttpMethod.PATCH,
            HttpEntity(requestBody, httpHeaders),
            Void::class.java
        )
    }

    fun delete(uri: String, unfilteredRequestHeaders: HttpHeaders, uriVariables: Map<String, Any?>) {
        val filteredRequestHeaders = filterHttpHeaders(unfilteredRequestHeaders)
        restTemplateWithSSL.exchange(
            uri, HttpMethod.DELETE,
            HttpEntity<Any>(filteredRequestHeaders),
            Void::class.java,
            uriVariables
        )
    }

    private fun filterHttpHeaders(unfilteredHttpHeaders: HttpHeaders): HttpHeaders {
        val filteredHttpHeaders = HttpHeaders()
        for ((headerName, headerValues) in unfilteredHttpHeaders) {
            if (isAllowedHttpHeader(headerName)) {
                filteredHttpHeaders.addAll(headerName, headerValues)
            }
        }
        return filteredHttpHeaders
    }

    private fun isAllowedHttpHeader(headerName: String): Boolean {
        return ALLOWED_HTTP_HEADERS.contains(headerName.lowercase(Locale.getDefault()))
    }

    companion object {
        private val ALLOWED_HTTP_HEADERS = listOf(
            "authorization", "x-api-key", "x-auth-user",
            "x-auth-employee", "x-auth-ticket", "x-auth-level", "x-rabo-xsrfp", "x-csrf-check", "cookie",
            "content-type", "rabobank-apikey", "x-requesting-system", "rabobank-scp-source-system-id",
            "rabobank-flow-id", "rabobank-scp-timestamp"
        )
    }
}
