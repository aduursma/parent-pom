package nl.rabobank.investments.commons.web.rest.exception

import java.time.LocalDateTime

class ErrorResponse {
    var timestamp: LocalDateTime? = null
    var status = 0
    var error: String? = null
    var errorCode: String? = null
    var message: String? = null
    var path: String? = null
}
