package nl.rabobank.investments.commons.web.autoconfigure

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.runner.ApplicationContextRunner

class ExceptionHandlingAutoConfigurationTest {

    private val contextRunner = ApplicationContextRunner()

    @Test
    fun `commonsErrorAttributes bean should be created`() {
        contextRunner
            .withUserConfiguration(
                ExceptionHandlingAutoConfiguration::class.java,
            )
            .run { context ->
                assertThat(context).hasBean("commonsErrorAttributes")
            }
    }
}
