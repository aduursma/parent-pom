package nl.rabobank.investments.commons.web.config

import com.fasterxml.jackson.databind.ObjectMapper
import io.mockk.every
import io.mockk.mockk
import java.security.Key
import java.security.KeyStore
import java.util.Collections
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean

@TestConfiguration
class FeignTestConfiguration {

    @Bean
    fun keyStore(): KeyStore {
        val keystore = mockk<KeyStore>()
        every { keystore.aliases() } returns Collections.emptyEnumeration()
        every { keystore.isKeyEntry("mykey") } returns true
        every { keystore.getKey("mykey", "notsecret".toCharArray()) } returns mockk<Key>()
        return keystore
    }

}
