package nl.rabobank.investments.commons.web.exception

import nl.rabobank.investments.commons.web.rest.exception.ErrorResponseUtil
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.http.HttpStatus
import java.time.LocalDateTime
import java.util.Arrays

class ErrorResponseUtilTest {

    @Test
    fun createErrorResponse() {
        val dateTimeJustBeforeTest = LocalDateTime.now()
        val errorResponse = ErrorResponseUtil.createErrorResponse(HttpStatus.INTERNAL_SERVER_ERROR, "abc")
        val dateTimeJustAfterTest = LocalDateTime.now()
        assertThat(errorResponse.error).isEqualTo("Internal Server Error")
        assertThat(errorResponse.errorCode).isNull()
        assertThat(errorResponse.status).isEqualTo(500)
        assertThat(errorResponse.path).isEqualTo("abc")
        assertThat(errorResponse.timestamp).isAfterOrEqualTo(dateTimeJustBeforeTest)
        assertThat(errorResponse.timestamp).isBeforeOrEqualTo(dateTimeJustAfterTest)
    }

    @Test
    fun createErrorResponseHeaders() {
        val errorResponseHeaders = ErrorResponseUtil.createErrorResponseHeaders()
        assertThat(errorResponseHeaders).hasSize(4)
        assertThat(errorResponseHeaders["Cache-control"])
            .isEqualTo(listOf("no-cache, no-store, max-age=0, must-revalidate"))
        assertThat(errorResponseHeaders["Pragma"]).isEqualTo(Arrays.asList("no-cache"))
        assertThat(errorResponseHeaders["X-Frame-Options"]).isEqualTo(Arrays.asList("SAMEORIGIN"))
        assertThat(errorResponseHeaders["X-XSS-Protection"]).isEqualTo(Arrays.asList("1; mode=block"))
    }
}
