package nl.rabobank.investments.commons.web.autoconfigure

import org.assertj.core.api.Assertions
import org.junit.jupiter.api.Test
import org.springframework.aop.interceptor.SimpleAsyncUncaughtExceptionHandler
import org.springframework.boot.test.context.runner.ApplicationContextRunner
import org.springframework.cloud.sleuth.instrument.async.LazyTraceExecutor

class TaskExecutorAutoConfigurationTest {

    private val contextRunner = ApplicationContextRunner()

    @Test
    fun `task executor config beans should be created`() {
        contextRunner
            .withUserConfiguration(
                TaskExecutorAutoConfiguration::class.java
            )
            .run { context ->
                val taskExecutor = context.getBean(TaskExecutorAutoConfiguration::class.java)
                Assertions.assertThat(
                    taskExecutor.asyncExecutor
                ).isInstanceOf(LazyTraceExecutor::class.java)
                Assertions.assertThat(
                    taskExecutor.asyncUncaughtExceptionHandler
                ).isInstanceOf(SimpleAsyncUncaughtExceptionHandler::class.java)
            }
    }
}
