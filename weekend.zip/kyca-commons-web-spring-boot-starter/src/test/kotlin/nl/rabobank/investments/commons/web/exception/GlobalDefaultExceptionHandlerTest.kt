package nl.rabobank.investments.commons.web.exception

import com.fasterxml.jackson.databind.ObjectMapper
import io.mockk.every
import io.mockk.impl.annotations.InjectMockKs
import io.mockk.impl.annotations.SpyK
import io.mockk.mockk
import nl.rabobank.investments.commons.web.rest.exception.ErrorResponse
import nl.rabobank.investments.commons.web.rest.exception.GlobalDefaultExceptionHandler
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.http.HttpStatus
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.web.HttpMediaTypeNotSupportedException
import org.springframework.web.client.HttpClientErrorException
import org.springframework.web.client.HttpStatusCodeException
import org.springframework.web.context.request.ServletWebRequest
import java.nio.charset.Charset
import java.util.concurrent.CompletionException
import javax.servlet.http.HttpServletRequest
import javax.validation.ConstraintViolationException

class GlobalDefaultExceptionHandlerTest {

    @SpyK
    private val objectMapper = ObjectMapper()

    @InjectMockKs
    private val globalDefaultExceptionHandler = GlobalDefaultExceptionHandler(objectMapper)

    @Test
    fun handleConstraintViolationException() {
        val request = mockk<HttpServletRequest>()
        every { request.requestURI } returns "abc"
        val responseEntity = globalDefaultExceptionHandler.handleGlobal(ConstraintViolationException(null), request)
        assertThat(responseEntity.statusCode).isEqualTo(HttpStatus.BAD_REQUEST)
        assertThat(responseEntity.body!!.path).isEqualTo("abc")
    }

    @Test
    fun handleHttpStatusCodeException_withErrorResponse() {
        val request = mockk<HttpServletRequest>()
        every { request.requestURI } returns "abc"
        val body =
            "{  \"error\": \"error\",  \"errorCode\": \"764\", " +
                "\"message\": \"error message\",  \"path\": \"/api/test\"}"
        val exception: HttpStatusCodeException = HttpClientErrorException(
            HttpStatus.UNAUTHORIZED, "Unauthorized",
            body.toByteArray(), Charset.defaultCharset()
        )
        val responseEntity = globalDefaultExceptionHandler.handleHttpStatusCodeException(
            exception, request
        )
        assertThat(responseEntity.statusCode).isEqualTo(HttpStatus.UNAUTHORIZED)
        assertThat(responseEntity.body!!.error).isEqualTo("error")
        assertThat(responseEntity.body!!.errorCode).isEqualTo("764")
        assertThat(responseEntity.body!!.message).isEqualTo("error message")
        assertThat(responseEntity.body!!.path).isEqualTo("/api/test")
    }

    @Test
    fun handleHttpStatusCodeException_noErrorResponse() {
        val request = mockk<HttpServletRequest>()
        every { request.requestURI } returns "abc"
        val body = "{  \"field1\": \"value1\"}"
        val exception: HttpStatusCodeException = HttpClientErrorException(
            HttpStatus.UNAUTHORIZED, "Unauthorized",
            body.toByteArray(), Charset.defaultCharset()
        )
        val responseEntity = globalDefaultExceptionHandler.handleHttpStatusCodeException(
            exception, request
        )
        assertThat(responseEntity.statusCode).isEqualTo(HttpStatus.UNAUTHORIZED)
        assertThat(responseEntity.body!!.error).isEqualTo("Unauthorized")
        assertThat(responseEntity.body!!.errorCode).isNull()
        assertThat(responseEntity.body!!.message).isEqualTo("401 Unauthorized, body: {  \"field1\": \"value1\"}")
        assertThat(responseEntity.body!!.path).isEqualTo("abc")
    }

    @Test
    fun handleCompletionException() {
        val request = mockk<HttpServletRequest>()
        every { request.requestURI } returns "abc"

        val exception = CompletionException("abc", Exception("def"))
        val responseEntity = globalDefaultExceptionHandler.handleCompletionException(exception, request)
        assertThat(responseEntity.statusCode).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        assertThat(responseEntity.body!!.path).isEqualTo("abc")
    }

    @Test
    fun handleIllegalArgumentException() {
        val request = mockk<HttpServletRequest>()
        every { request.requestURI } returns "abc"

        val exception = IllegalArgumentException("abc")
        val responseEntity = globalDefaultExceptionHandler.handleIllegalArgumentException(exception, request)
        assertThat(responseEntity.statusCode).isEqualTo(HttpStatus.BAD_REQUEST)
        assertThat(responseEntity.body!!.path).isEqualTo("abc")
    }

    @Test
    fun handleException() {
        val httpServletRequest = MockHttpServletRequest()
        httpServletRequest.requestURI = "abc"
        val request = ServletWebRequest(httpServletRequest)
        val responseEntity = globalDefaultExceptionHandler.handleException(
            HttpMediaTypeNotSupportedException(""), request
        )
        val errorResponse = responseEntity!!.body as ErrorResponse
        assertThat(errorResponse.status).isEqualTo(HttpStatus.UNSUPPORTED_MEDIA_TYPE.value())
        assertThat(errorResponse.path).isEqualTo("abc")
    }
}
