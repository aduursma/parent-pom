package nl.rabobank.investments.commons.web.client

import com.fasterxml.jackson.databind.ObjectMapper
import nl.rabobank.investments.commons.web.rest.client.RestClient
import nl.rabobank.investments.commons.web.rest.config.SecuredRestTemplateConfig
import nl.rabobank.investments.commons.web.rest.exception.GlobalDefaultExceptionHandler
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Disabled
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.junit.jupiter.api.extension.ExtendWith
import org.skyscreamer.jsonassert.JSONAssert
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock
import org.springframework.http.HttpHeaders
import org.springframework.http.HttpStatus
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource
import org.springframework.test.context.junit.jupiter.SpringExtension
import org.springframework.web.client.HttpClientErrorException
import org.springframework.web.client.HttpServerErrorException

data class TestRequest(var testProperty: String? = null)
data class TestResult(var testProperty: String? = null)

@ExtendWith(SpringExtension::class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.MOCK)
@ContextConfiguration(
    classes = [
        GlobalDefaultExceptionHandler::class,
        RestClient::class,
        SecuredRestTemplateConfig::class,
        ObjectMapper::class
    ]
)
@TestPropertySource(properties = ["a=b"])
@AutoConfigureWireMock(port = 0, files = ["classpath:/stubs"])
@Disabled
class RestClientTestDisabled {

    @Autowired
    private lateinit var restClient: RestClient

    @Test
    fun testGet_200() {
        val httpHeaders = HttpHeaders()
        httpHeaders["authorization"] = "testAuthorization"
        httpHeaders["x-api-key"] = "testXApiKey"
        httpHeaders["x-auth-user"] = "testXAuthUser"
        httpHeaders["x-auth-employee"] = "testXAuthEmployee"
        httpHeaders["x-auth-ticket"] = "testXAuthTicket"
        httpHeaders["x-auth-level"] = "testXAuthLevel"
        httpHeaders["x-rabo-xsrfp"] = "testXRaboXsrfp"
        httpHeaders["x-csrf-check"] = "testxCsrfCheck"
        httpHeaders["cookie"] = "testCookie"
        httpHeaders["rabobank-apikey"] = "testRabobankApikey"
        httpHeaders["x-requesting-system"] = "testXRequestingSystem"
        httpHeaders["rabobank-scp-source-system-id"] = "testRabobankScpSourceSystemId"
        httpHeaders["rabobank-flow-id"] = "testRabobankFlowId"
        httpHeaders["rabobank-scp-timestamp"] = "testRabobankScpTimestamp"

        val testResult =
            restClient.get("http://localhost:9876/api/test-get-200", TestResult::class.java, httpHeaders, HashMap())
        assertThat(testResult!!.testProperty).isEqualTo("testValue")
    }

    @Test
    fun testGet_400() {
        val thrown = assertThrows<HttpClientErrorException> {
            restClient.get(
                "http://localhost:9876/api/test-get-400",
                TestResult::class.java,
                HttpHeaders(),
                HashMap()
            )
        }
        assertThat(thrown.statusCode).isEqualTo(HttpStatus.BAD_REQUEST)
        assertThat(thrown.statusText).isEqualTo("Bad Request")
        JSONAssert.assertEquals(
            """{"error": "error", "message": "error message", "path": "/api/test"}""",
            thrown.responseBodyAsString,
            true
        )
    }

    @Test
    fun testGetList_200() {
        val testResults = restClient.getList(
            "http://localhost:9876/api/test-get-list-200",
            TestResult::class.java,
            HttpHeaders(),
            HashMap()
        )
        assertThat(testResults).hasSize(2)
        assertThat(testResults[0].testProperty).isEqualTo("testValue1")
        assertThat(testResults[1].testProperty).isEqualTo("testValue2")
    }

    @Test
    fun testPost_201() {
        val testRequest = TestRequest("abc")
        val testResult = restClient.post(
            "http://localhost:9876/api/test-post-201",
            TestResult::class.java,
            HttpHeaders(),
            testRequest
        )
        assertThat(testResult!!.testProperty).isEqualTo("testValue")
    }

    @Test
    fun testPost_422() {
        val testRequest = TestRequest("abc")
        val thrown = assertThrows<HttpClientErrorException> {
            restClient.post(
                "http://localhost:9876/api/test-post-422",
                TestResult::class.java,
                HttpHeaders(),
                testRequest
            )
        }
        assertThat(thrown.statusCode).isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
        assertThat(thrown.statusText).isEqualTo("Unprocessable Entity")
        JSONAssert.assertEquals(
            """{"error": "error", "message": "error message", "path": "/api/test"}""",
            thrown.responseBodyAsString,
            true
        )
    }

    @Test
    fun testPut_200() {
        val testRequest = TestRequest("abc")
        val testResult = restClient.put(
            "http://localhost:9876/api/test-put-200",
            TestResult::class.java,
            HttpHeaders(),
            HashMap(),
            testRequest
        )
        assertThat(testResult!!.testProperty).isEqualTo("testValue")
    }

    @Test
    fun testPut_500() {
        val testRequest = TestRequest("abc")
        val thrown = assertThrows<HttpServerErrorException> {
            restClient.put(
                "http://localhost:9876/api/test-put-500",
                TestResult::class.java,
                HttpHeaders(),
                HashMap(),
                testRequest
            )
        }
        assertThat(thrown.statusCode).isEqualTo(HttpStatus.INTERNAL_SERVER_ERROR)
        assertThat(thrown.statusText).isEqualTo("Server Error")
        assertThat(thrown.responseBodyAsString).isEmpty()
    }

    @Test
    fun testPatch_204() {
        val testRequest = TestRequest("abc")
        val response = restClient.patch("http://localhost:9876/api/test-patch-204", testRequest, HttpHeaders())
        assertThat(response.statusCode).isEqualTo(HttpStatus.NO_CONTENT)
    }
}
