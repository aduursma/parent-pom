package nl.rabobank.investments.commons.web.soap

import io.mockk.every
import io.mockk.mockk
import io.mockk.spyk
import nl.rabobank.investments.commons.soap.SoapConnector
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Disabled
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.springframework.oxm.Unmarshaller
import org.springframework.ws.client.core.WebServiceMessageCallback
import org.springframework.ws.client.core.WebServiceMessageExtractor
import org.springframework.ws.soap.SoapMessage
import org.springframework.ws.soap.client.SoapFaultClientException
import javax.xml.transform.Source

class SoapConnectorTest {
    private val soapConnector = spyk<SoapConnector>()

    @Test
    @Disabled
    fun testCallWebService() {
        val callback = mockk<WebServiceMessageCallback>()
        val messageExtractorArgumentCaptor = mutableListOf<WebServiceMessageExtractor<Any>>()
        every {
            soapConnector.webServiceTemplate.sendAndReceive(
                "url", callback, capture(messageExtractorArgumentCaptor)
            )
        } returns mockk()
        soapConnector.callWebService("url", callback)
        val responseMessage = mockk<SoapMessage>(relaxed = true)
        // unmarshaller is null - IllegalStateException should be thrown
        assertThat(
            assertThrows<IllegalStateException> {
                messageExtractorArgumentCaptor[0].extractData(responseMessage)
            }.message
        ).isEqualTo("No unmarshaller registered. Check configuration of WebServiceTemplate.")

        // message hasFault is true - SoapFaultClientException is thrown
        val unmarshaller = mockk<Unmarshaller>()
        every { soapConnector.unmarshaller } returns unmarshaller
        every { responseMessage.hasFault() } returns true
        assertThrows<SoapFaultClientException> {
            messageExtractorArgumentCaptor[0].extractData(responseMessage)
        }

        // message doesn't contains fault - normal processing
        val finalResponse = mockk<Any>()
        val payloadSource = mockk<Source>()
        every { responseMessage.hasFault() } returns false
        every { responseMessage.payloadSource } returns payloadSource
        every { unmarshaller.unmarshal(payloadSource) } returns finalResponse
        assertThat(messageExtractorArgumentCaptor[0].extractData(responseMessage)).isEqualTo(finalResponse)
    }
}
