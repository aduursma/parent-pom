package nl.rabobank.investments.commons.web.autoconfigure

import com.fasterxml.jackson.databind.ObjectMapper
import io.mockk.every
import io.mockk.mockk
import org.assertj.core.api.Assertions
import org.junit.jupiter.api.Disabled
import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.boot.test.context.runner.ApplicationContextRunner
import org.springframework.context.annotation.Bean
import org.springframework.web.client.RestTemplate
import org.zalando.logbook.autoconfigure.LogbookAutoConfiguration
import org.zalando.logbook.spring.LogbookClientHttpRequestInterceptor
import java.security.Key
import java.security.KeyStore
import java.util.Collections

class RestAutoConfigurationTest {

    private val contextRunner = ApplicationContextRunner()

    @Test
    @Disabled
    fun `rest config beans should be created`() {
        contextRunner
            .withPropertyValues(
                "ssl.keystore-password=notsecret"
            )
            .withUserConfiguration(
                RestTestConfiguration::class.java,
                LogbookAutoConfiguration::class.java,
                RestAutoConfiguration::class.java,
            )
            .run { context ->
                Assertions.assertThat(context).hasBean("restClient")
                Assertions.assertThat(context).hasBean("globalDefaultExceptionHandler")
                Assertions.assertThat(context).hasBean("restTemplate")
                Assertions.assertThat(
                    (context.getBean("restTemplate") as RestTemplate)
                        .interceptors.find {
                            it is LogbookClientHttpRequestInterceptor
                        }
                ).isNotNull
            }
    }
}

@TestConfiguration
class RestTestConfiguration {

    @Bean
    fun keyStore(): KeyStore {
        val keystore = mockk<KeyStore>()
        every { keystore.aliases() } returns Collections.enumeration(listOf("mykey"))
        every { keystore.isKeyEntry("mykey") } returns true
        every { keystore.getKey("mykey", "notsecret".toCharArray()) } returns mockk<Key>()
        return keystore
    }

    @Bean
    fun objectMapper(): ObjectMapper {
        return mockk()
    }
}
