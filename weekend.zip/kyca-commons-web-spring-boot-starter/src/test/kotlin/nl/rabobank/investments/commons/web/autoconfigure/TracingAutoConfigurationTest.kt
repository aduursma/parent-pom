package nl.rabobank.investments.commons.web.autoconfigure

import brave.Tracer
import brave.handler.MutableSpan
import brave.handler.SpanHandler
import brave.sampler.Sampler
import io.mockk.mockk
import org.assertj.core.api.Assertions
import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.boot.test.context.runner.ApplicationContextRunner
import org.springframework.context.annotation.Bean

class TracingAutoConfigurationTest {
    private val contextRunner = ApplicationContextRunner()

    @Test
    fun `task executor config beans should be created`() {
        contextRunner
            .withPropertyValues(
                "spring.application.name=test-application",
                "spring.application.version=1",
                "RABOPCF_LOCALDOMAIN=pcf-domain",
                "RABOPCF_LOCATION=pcf-location",
                "RABOPCF_LOCATION_SHORT=pcf-location-short",
                "RABOPCF_SYSTEM_ENV=pcf-system-env",
            )
            .withUserConfiguration(
                TracingTestConfiguration::class.java,
                TracingAutoConfiguration::class.java
            )
            .run { context ->
                Assertions.assertThat(context).hasBean("mdcTracingFilter")
                Assertions.assertThat(
                    context.getBean(Sampler::class.java)
                ).isInstanceOf(Sampler.ALWAYS_SAMPLE::class.java)
                val spanHandler = context.getBean(SpanHandler::class.java)
                val newSpan = MutableSpan()
                spanHandler.end(mockk(), newSpan, SpanHandler.Cause.FINISHED)
                Assertions.assertThat(newSpan.tag("service_name")).isEqualTo("test-application")
                Assertions.assertThat(newSpan.tag("service_version")).isEqualTo("1")
                Assertions.assertThat(newSpan.tag("pcf_local_domain")).isEqualTo("pcf-domain")
                Assertions.assertThat(newSpan.tag("pcf_location")).isEqualTo("pcf-location")
                Assertions.assertThat(newSpan.tag("pcf_location_short")).isEqualTo("pcf-location-short")
                Assertions.assertThat(newSpan.tag("pcf_system_env")).isEqualTo("pcf-system-env")
            }
    }
}

@TestConfiguration
class TracingTestConfiguration {

    @Bean
    fun trace(): Tracer {
        return mockk()
    }
}
