package nl.rabobank.investments.commons.web.autoconfigure

import com.fasterxml.jackson.databind.ObjectMapper
import feign.Feign
import nl.rabobank.investments.commons.web.config.FeignTestConfiguration
import org.assertj.core.api.Assertions
import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.runner.ApplicationContextRunner
import org.springframework.context.annotation.Import
import org.zalando.logbook.autoconfigure.LogbookAutoConfiguration

@Import(FeignTestConfiguration::class)
class FeignClientAutoConfigurationTest {

    private val contextRunner = ApplicationContextRunner()

    @Test
    fun `feign config beans should be created`() {
        contextRunner
            .withPropertyValues(
                "ssl.keystore-password=notsecret"
            )
            .withUserConfiguration(
                FeignTestConfiguration::class.java,
                LogbookAutoConfiguration::class.java,
                FeignClientAutoConfiguration::class.java,
                ObjectMapper::class.java
            )
            .run { context ->
                Assertions.assertThat(context).hasBean("getFeignClient")
                Assertions.assertThat(context).hasBean("feignLoggerLevel")
                Assertions.assertThat(context).hasBean("errorDecoder")
                Assertions.assertThat(
                    (context.getBean("getFeignClient") as Feign)
                ).isNotNull
            }
    }
}