package nl.rabobank.investments.commons.security.config

import nl.rabobank.investments.commons.security.TestConfiguration
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.runner.ApplicationContextRunner

class JwsConfigTest {

    private val contextRunner = ApplicationContextRunner()

    @Test
    fun givenJwsPropertiesArePresent_whenStartingContainer_thenJwsBeansShouldBeAvailable() {
        contextRunner
            .withPropertyValues(
                "security.jws.connection-timeout=5000",
                "security.jws.read-timeout=5000",
                "security.jws.url=http://localhost:9876/jwk",
                "security.employee-jws.connection-timeout=5000",
                "security.employee-jws.read-timeout=5000",
                "security.employee-jws.url=http://localhost:9876/jwk"
            )
            .withAllowBeanDefinitionOverriding(true)
            .withUserConfiguration(
                JwsConfig::class.java,
                TestConfiguration::class.java
            )
            .run { context ->
                assertThat(context).hasBean("customerAuthenticationConverter")
                assertThat(context).hasBean("employeeAuthenticationConverter")
                assertThat(context).hasBean("customerJwtDecoder")
                assertThat(context).hasBean("employeeJwtDecoder")
            }
    }
}
