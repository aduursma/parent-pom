package nl.rabobank.investments.commons.security.service

import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkStatic
import io.mockk.unmockkStatic
import io.mockk.verify
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.EMPLOYEE_AUTHORISATION_HEADER
import nl.rabobank.investments.commons.security.converter.EmployeeAuthenticationConverter
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.security.authentication.AbstractAuthenticationToken
import org.springframework.security.core.AuthenticatedPrincipal
import org.springframework.security.core.GrantedAuthority
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.core.context.SecurityContextImpl
import org.springframework.security.oauth2.jwt.Jwt
import org.springframework.security.oauth2.jwt.JwtDecoder
import org.springframework.security.oauth2.jwt.JwtException
import javax.servlet.http.HttpServletRequest

class EmployeeAuthenticationServiceTest {
    private val employeeJwtDecoder = mockk<JwtDecoder>()
    private val employeeAuthenticationConverter = mockk<EmployeeAuthenticationConverter>()
    private val jwt = mockk<Jwt>()
    private val authenticationToken = mockk<AbstractAuthenticationToken>()
    private val httpServletRequest = mockk<HttpServletRequest>()
    private val authenticatedPrincipal = mockk<AuthenticatedPrincipal>(relaxed = true)

    private val employeeAuthenticationService = EmployeeAuthenticationService(
        employeeJwtDecoder,
        employeeAuthenticationConverter
    )

    @BeforeEach
    fun beforeEach() {
        mockkStatic("org.springframework.security.core.context.SecurityContextHolder")
        every { SecurityContextHolder.getContext() } returns SecurityContextImpl()
    }

    @AfterEach
    fun afterEach() {
        unmockkStatic("org.springframework.security.core.context.SecurityContextHolder")
    }

    @Test
    fun `test canAuthenticate success`() {
        every { httpServletRequest.getHeader(EMPLOYEE_AUTHORISATION_HEADER) } returns "some value"
        assertThat(employeeAuthenticationService.canAuthenticate(httpServletRequest)).isTrue
    }

    @Test
    fun `test canAuthenticate failure`() {
        every { httpServletRequest.getHeader(EMPLOYEE_AUTHORISATION_HEADER) } returns ""
        assertThat(employeeAuthenticationService.canAuthenticate(httpServletRequest)).isFalse
    }

    @Test
    fun `test authenticate success`() {
        every { httpServletRequest.getHeader(EMPLOYEE_AUTHORISATION_HEADER) } returns "some value"
        every { employeeJwtDecoder.decode(any()) } returns jwt
        every { employeeAuthenticationConverter.convert(any()) } returns authenticationToken
        every { authenticationToken.isAuthenticated } returns true
        every { authenticationToken.authorities } returns ArrayList<GrantedAuthority>()
        every { authenticationToken.principal } returns authenticatedPrincipal

        employeeAuthenticationService.authenticate(httpServletRequest)

        assertThat(SecurityContextHolder.getContext().authentication).isNotNull
    }

    @Test
    fun `test authenticate failure when encrypted token is null or blank`() {
        every { httpServletRequest.getHeader(EMPLOYEE_AUTHORISATION_HEADER) } returns null

        employeeAuthenticationService.authenticate(httpServletRequest)

        verify(exactly = 0) { employeeAuthenticationConverter.convert(any()) }
    }

    @Test
    fun `test authenticate failure when jwt exception is thrown`() {
        every { httpServletRequest.getHeader(EMPLOYEE_AUTHORISATION_HEADER) } returns "some value"
        every { employeeJwtDecoder.decode(any()) } throws JwtException("any message")

        employeeAuthenticationService.authenticate(httpServletRequest)

        verify(exactly = 0) { SecurityContextHolder.getContext() }
    }

    @Test
    fun `test authenticate failure when authentication token is not authenticated`() {
        every { httpServletRequest.getHeader(EMPLOYEE_AUTHORISATION_HEADER) } returns "some value"
        every { employeeJwtDecoder.decode(any()) } returns jwt
        every { employeeAuthenticationConverter.convert(any()) } returns authenticationToken
        every { authenticationToken.isAuthenticated } returns false
        every { authenticationToken.authorities } returns ArrayList<GrantedAuthority>()
        every { authenticationToken.principal } returns authenticatedPrincipal

        employeeAuthenticationService.authenticate(httpServletRequest)

        verify(exactly = 0) { SecurityContextHolder.getContext() }
    }
}
