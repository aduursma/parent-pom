package nl.rabobank.investments.commons.security.authorization

import io.mockk.Called
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import nl.rabobank.investments.commons.agreement.domain.AgreementAuthorization
import nl.rabobank.investments.commons.security.authorization.customer.agreement.service.CustomerAgreementAuthorizationService
import nl.rabobank.investments.commons.security.authorization.customer.authhub.service.CustomerAuthorizationHubService
import nl.rabobank.investments.commons.security.authorization.employee.service.EmployeeAuthorizationService
import nl.rabobank.investments.commons.security.domain.ApplicationPrincipal
import nl.rabobank.investments.commons.security.domain.CustomerPrincipal
import nl.rabobank.investments.commons.security.domain.EmployeePrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.domain.Role
import nl.rabobank.investments.commons.security.domain.ValidationResult
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.security.core.context.SecurityContextHolder

class AuthorizationServiceTest {
    private val investmentArrangementNumber = "98765432"
    private val validationResult = ValidationResult(true, "Valid")
    private val employeeAuthorizationService: EmployeeAuthorizationService = mockk()
    private val customerAuthorizationHubService: CustomerAuthorizationHubService = mockk()
    private val customerAgreementAuthorizationService: CustomerAgreementAuthorizationService = mockk()
    private val authorizationService = AuthorizationService(
        employeeAuthorizationService, customerAuthorizationHubService, customerAgreementAuthorizationService
    )

    @Test
    fun checkAuthorizations_Employee() {
        val authentication = mockEmployeeAuth()
        val validationResult = authorizationService.checkAuthorizations(
            investmentArrangementNumber, AgreementAuthorization.VIEW_AGREEMENT, false
        )
        assertThat(validationResult).isEqualTo(validationResult)
        verifyEmployeeAuth(authentication)
        SecurityContextHolder.clearContext()
    }

    @Test
    fun checkAuthorizations_Customer() {
        val authentication = mockCustomerAuth()
        val validationResult = authorizationService.checkAuthorizations(
            investmentArrangementNumber, AgreementAuthorization.VIEW_AGREEMENT, false
        )
        assertThat(validationResult).isEqualTo(validationResult)
        verifyCustomerAuth(authentication)
        SecurityContextHolder.clearContext()
    }

    @Test
    fun checkAuthorizations_Customer_VIEW_KEC() {
        val authentication = mockCustomerAuth(isAuthHubService = true, authorization = AgreementAuthorization.VIEW_KEC)
        val validationResult = authorizationService.checkAuthorizations(
            investmentArrangementNumber, AgreementAuthorization.VIEW_KEC, false
        )
        assertThat(validationResult).isEqualTo(validationResult)
        verifyCustomerAuth(authentication, isAuthHubService = true, authorization = AgreementAuthorization.VIEW_KEC)
        SecurityContextHolder.clearContext()
    }

    @Test
    fun checkAuthorizations_Customer_EDIT_KEC() {
        val authentication = mockCustomerAuth(isAuthHubService = true, authorization = AgreementAuthorization.EDIT_KEC)
        val validationResult = authorizationService.checkAuthorizations(
            investmentArrangementNumber, AgreementAuthorization.EDIT_KEC, false
        )
        assertThat(validationResult).isEqualTo(validationResult)
        verifyCustomerAuth(authentication, isAuthHubService = true, authorization = AgreementAuthorization.EDIT_KEC)
        SecurityContextHolder.clearContext()
    }

    @Test
    fun checkAuthorizations_Application() {
        val authentication = PrincipalAuthentication(
            "token", ApplicationPrincipal("APP_NAME"), Role.APPLICATION
        ).apply { this.isAuthenticated = true }
        SecurityContextHolder.getContext().authentication = authentication
        val validationResult = authorizationService.checkAuthorizations(
            investmentArrangementNumber, AgreementAuthorization.VIEW_AGREEMENT, false
        )
        assertThat(validationResult.isValid).isTrue
        assertThat(validationResult.reason).isEqualTo("APPLICATION role is authorized")
        verify {
            employeeAuthorizationService wasNot Called
            customerAuthorizationHubService wasNot Called
        }
        SecurityContextHolder.clearContext()
    }

    @Test
    fun checkAuthorizations_UnknownRole_Invalid() {
        val authentication = mockk<PrincipalAuthentication>()
        every { authentication.isAuthenticated } returns true
        every { authentication.hasRole(any()) } returns false
        SecurityContextHolder.getContext().authentication = authentication
        val validationResult = authorizationService.checkAuthorizations(
            investmentArrangementNumber, AgreementAuthorization.VIEW_AGREEMENT, true
        )
        assertThat(validationResult.isValid).isFalse
        assertThat(validationResult.reason).isEqualTo(
            "No Valid CUSTOMER, EMPLOYEE and APPLICATION role for checking authorization of the user"
        )
        verify {
            employeeAuthorizationService wasNot Called
            customerAuthorizationHubService wasNot Called
        }
        SecurityContextHolder.clearContext()
    }

    @Test
    fun checkAuthorizations_NotAuthenticated_Invalid() {
        val authentication = PrincipalAuthentication(
            "token", ApplicationPrincipal("APP_NAME"), Role.EMPLOYEE
        ).apply { this.isAuthenticated = isAuthenticated }
        SecurityContextHolder.getContext().authentication = authentication
        val validationResult = authorizationService.checkAuthorizations(
            investmentArrangementNumber, AgreementAuthorization.VIEW_AGREEMENT, false
        )
        assertThat(validationResult.isValid).isFalse
        assertThat(validationResult.reason).isEqualTo("User is not authenticated")
        verify {
            employeeAuthorizationService wasNot Called
            customerAuthorizationHubService wasNot Called
        }
        SecurityContextHolder.clearContext()
    }

    private fun mockCustomerAuth(
        isAuthenticated: Boolean = true,
        isAuthHubService: Boolean = false,
        authorization: AgreementAuthorization = AgreementAuthorization.VIEW_AGREEMENT
    ): PrincipalAuthentication {
        val customerAuthentication = PrincipalAuthentication(
            "token", CustomerPrincipal(), Role.CUSTOMER
        ).apply { this.isAuthenticated = isAuthenticated }
        SecurityContextHolder.getContext().authentication = customerAuthentication
        if (isAuthHubService) {
            every {
                customerAuthorizationHubService.checkAuthorizations(
                    authorization, investmentArrangementNumber, customerAuthentication
                )
            } returns validationResult
        } else {
            every {
                customerAgreementAuthorizationService.checkAuthorizations(
                    authorization, investmentArrangementNumber, customerAuthentication
                )
            } returns validationResult
        }
        return customerAuthentication
    }
    private fun verifyCustomerAuth(
        authentication: PrincipalAuthentication,
        isAuthHubService: Boolean = false,
        authorization: AgreementAuthorization = AgreementAuthorization.VIEW_AGREEMENT
    ) {
        if (isAuthHubService) {
            verify {
                customerAuthorizationHubService.checkAuthorizations(
                    authorization, investmentArrangementNumber, authentication
                )
            }
        } else {
            customerAgreementAuthorizationService.checkAuthorizations(
                authorization, investmentArrangementNumber, authentication
            )
        }
    }

    private fun mockEmployeeAuth(isAuthenticated: Boolean = true): PrincipalAuthentication {
        val employeeAuthentication = PrincipalAuthentication(
            "token", EmployeePrincipal(), Role.EMPLOYEE
        ).apply { this.isAuthenticated = isAuthenticated }
        SecurityContextHolder.getContext().authentication = employeeAuthentication
        every {
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_AGREEMENT, investmentArrangementNumber, employeeAuthentication, false
            )
        } returns validationResult
        return employeeAuthentication
    }

    private fun verifyEmployeeAuth(authentication: PrincipalAuthentication) {
        verify {
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_AGREEMENT, investmentArrangementNumber, authentication
            )
        }
    }
}
