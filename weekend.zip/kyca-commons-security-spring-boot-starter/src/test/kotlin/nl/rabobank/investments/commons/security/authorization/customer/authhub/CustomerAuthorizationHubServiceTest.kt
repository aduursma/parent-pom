package nl.rabobank.investments.commons.security.authorization.customer.authhub

import io.mockk.Called
import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import nl.rabobank.investments.commons.agreement.domain.AgreementAuthorization
import nl.rabobank.investments.commons.security.authorization.customer.authhub.domain.Arrangement
import nl.rabobank.investments.commons.security.authorization.customer.authhub.domain.AuthorityConstants.CUSTOMER_AUTHORIZATION_CH_EF_01
import nl.rabobank.investments.commons.security.authorization.customer.authhub.domain.AuthorityConstants.CUSTOMER_AUTHORIZATION_GN_READ
import nl.rabobank.investments.commons.security.authorization.customer.authhub.domain.Authorization
import nl.rabobank.investments.commons.security.authorization.customer.authhub.repository.CustomerAuthorizationRepository
import nl.rabobank.investments.commons.security.authorization.customer.authhub.service.CustomerAuthorizationHubService
import nl.rabobank.investments.commons.security.domain.CustomerPrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows

private const val CUSTOMER_AUTHORIZATION_INITIATE_PURCHASE = "INITIATE_PURCHASE"

class CustomerAuthorizationHubServiceTest {

    private val customerAuthorizationRepository: CustomerAuthorizationRepository = mockk()
    private val customerAuthorizationHubService =
        CustomerAuthorizationHubService(customerAuthorizationRepository)
    private val principalAuthentication: PrincipalAuthentication =
        PrincipalAuthentication("token", CustomerPrincipal(), "CUSTOMER")

    @Test
    fun testcheckAuthorizationsTrue() {
        every {
            customerAuthorizationRepository.userAuthorization(principalAuthentication)
        } returns (authorization)
        val validationResult = customerAuthorizationHubService.checkAuthorizations(
            AgreementAuthorization.VIEW_AGREEMENT,
            "98765432",
            principalAuthentication
        )
        assertThat(validationResult.isValid).isTrue
        assertThat(validationResult.reason).isEqualTo("KAD-PA")
        verify { customerAuthorizationRepository.userAuthorization(principalAuthentication) }
    }

    @Test
    fun `agreement id not present in authorization is invalid`() {
        every {
            customerAuthorizationRepository.userAuthorization(principalAuthentication)
        } returns (authorization)
        val validationResult = customerAuthorizationHubService.checkAuthorizations(
            AgreementAuthorization.VIEW_AGREEMENT,
            "wrong-agreementid",
            principalAuthentication
        )
        assertThat(validationResult.isValid).isFalse
        assertThat(validationResult.reason).isEqualTo("KAD-PA")
        verify { customerAuthorizationRepository.userAuthorization(principalAuthentication) }
    }

    @Test
    fun `valid authorization for given agreementid is not sufficient is invalid`() {
        every {
            customerAuthorizationRepository.userCustomerAuthorization(principalAuthentication)
        } returns (authorization)
        val validationResult = customerAuthorizationHubService.checkAuthorizations(
            AgreementAuthorization.EDIT_AGREEMENT,
            "wrong-agreementid",
            principalAuthentication
        )
        assertThat(validationResult.isValid).isFalse
        assertThat(validationResult.reason).isEqualTo("KAD-PA")
        verify { customerAuthorizationRepository.userCustomerAuthorization(principalAuthentication) }
    }

    @Test
    fun `valid user authorization for given agreementid is present view_agreement`() {
        every { customerAuthorizationRepository.userAuthorization(principalAuthentication) } returns (authorization)
        val validationResult = customerAuthorizationHubService.checkAuthorizations(
            AgreementAuthorization.VIEW_AGREEMENT,
            "98765432",
            principalAuthentication
        )
        assertThat(validationResult.isValid).isTrue
        assertThat(validationResult.reason).isEqualTo("KAD-PA")
        verify { customerAuthorizationRepository.userAuthorization(principalAuthentication) }
    }

    @Test
    fun `valid user authorization for given agreementid is present view_kec`() {
        every { customerAuthorizationRepository.userAuthorization(principalAuthentication) } returns (authorization)
        val validationResult = customerAuthorizationHubService.checkAuthorizations(
            AgreementAuthorization.VIEW_KEC,
            "98765432",
            principalAuthentication
        )
        assertThat(validationResult.isValid).isTrue
        assertThat(validationResult.reason).isEqualTo("KAD-PA")
        verify { customerAuthorizationRepository.userAuthorization(principalAuthentication) }
    }

    @Test
    fun `valid user authorization for given agreementid is present edit_agreement`() {
        every {
            customerAuthorizationRepository.userCustomerAuthorization(principalAuthentication)
        } returns (authorization)
        val validationResult = customerAuthorizationHubService.checkAuthorizations(
            AgreementAuthorization.EDIT_AGREEMENT,
            "98765432",
            principalAuthentication
        )
        assertThat(validationResult.isValid).isFalse
        assertThat(validationResult.reason).isEqualTo("KAD-PA")
        verify { customerAuthorizationRepository.userCustomerAuthorization(principalAuthentication) }
    }

    @Test
    fun `valid user authorization for given agreementid is present edit_kec`() {
        every {
            customerAuthorizationRepository.userAuthorization(principalAuthentication)
        } returns (authorization)
        val validationResult = customerAuthorizationHubService.checkAuthorizations(
            AgreementAuthorization.EDIT_KEC,
            "98765432",
            principalAuthentication
        )
        assertThat(validationResult.isValid).isTrue
        assertThat(validationResult.reason).isEqualTo("KAD-PA")
        verify { customerAuthorizationRepository.userAuthorization(principalAuthentication) }
    }

    @Test
    fun `valid user authorization for given agreementid is present discontinue_agreement`() {
        every {
            customerAuthorizationRepository.userCustomerAuthorization(principalAuthentication)
        } returns (authorization)
        val validationResult = customerAuthorizationHubService.checkAuthorizations(
            AgreementAuthorization.DISCONTINUE_AGREEMENT,
            "98765432",
            principalAuthentication
        )
        assertThat(validationResult.isValid).isFalse
        assertThat(validationResult.reason).isEqualTo("KAD-PA")
        verify { customerAuthorizationRepository.userCustomerAuthorization(principalAuthentication) }
    }

    @Test
    fun `valid user authorization for given agreementid is present other NotImplementedError`() {
        assertThat(
            assertThrows<NotImplementedError> {
                customerAuthorizationHubService.checkAuthorizations(
                    AgreementAuthorization.VIEW_TRADING_BLOCK,
                    "98765432",
                    principalAuthentication
                )
            }.message
        ).isEqualTo("Authorization: VIEW_TRADING_BLOCK not supported")
        verify { customerAuthorizationRepository wasNot Called }
    }

    @Test
    fun `invalid user authorization for given agreementid when it is not present`() {
        every { customerAuthorizationRepository.userAuthorization(principalAuthentication) } returns (authorization)
        val validationResult = customerAuthorizationHubService.checkAuthorizations(
            AgreementAuthorization.VIEW_AGREEMENT,
            "99999999",
            principalAuthentication
        )
        assertThat(validationResult.isValid).isFalse
        assertThat(validationResult.reason).isEqualTo("KAD-PA")
        verify { customerAuthorizationRepository.userAuthorization(principalAuthentication) }
    }

    @Test
    fun `invalid user authorization for given agreementid when is present but correct authorization not present`() {
        every {
            customerAuthorizationRepository.userCustomerAuthorization(principalAuthentication)
        } returns (authorization)
        val validationResult = customerAuthorizationHubService.checkAuthorizations(
            AgreementAuthorization.EDIT_AGREEMENT,
            "98765432",
            principalAuthentication
        )
        assertThat(validationResult.isValid).isFalse
        assertThat(validationResult.reason).isEqualTo("KAD-PA")
        verify { customerAuthorizationRepository.userCustomerAuthorization(principalAuthentication) }
    }

    @Test
    fun `valid authorization at customer level`() {
        every {
            customerAuthorizationRepository.userCustomerAuthorization(principalAuthentication)
        } returns (authorization)
        val validationResult = customerAuthorizationHubService
            .checkCustomerLevelAuthorizations(CUSTOMER_AUTHORIZATION_INITIATE_PURCHASE, principalAuthentication)
        assertThat(validationResult.isValid).isTrue
        assertThat(validationResult.reason).isEqualTo("Customer-Authorization: INITIATE_PURCHASE")
        verify { customerAuthorizationRepository.userCustomerAuthorization(principalAuthentication) }
    }

    @Test
    fun `inValid authorization at customer level`() {
        every {
            customerAuthorizationRepository.userCustomerAuthorization(principalAuthentication)
        } returns (authorization)
        val validationResult = customerAuthorizationHubService
            .checkCustomerLevelAuthorizations(CUSTOMER_AUTHORIZATION_GN_READ, principalAuthentication)
        assertThat(validationResult.isValid).isFalse
        assertThat(validationResult.reason).isEqualTo("Customer-Authorization: GN_READ")
        verify { customerAuthorizationRepository.userCustomerAuthorization(principalAuthentication) }
    }

    private val arrangement = Arrangement(
        "98765432", "04",
        listOf(CUSTOMER_AUTHORIZATION_GN_READ, CUSTOMER_AUTHORIZATION_CH_EF_01)
    )
    private val authorization = Authorization(
        sessionId = "sessionId",
        relationId = "relationId",
        authorizedUserId = "authUserId",
        distributionAgreementId = 4,
        edoUserId = "edoUserId",
        authorizations = listOf(CUSTOMER_AUTHORIZATION_INITIATE_PURCHASE),
        arrangements = listOf(arrangement)
    )
}
