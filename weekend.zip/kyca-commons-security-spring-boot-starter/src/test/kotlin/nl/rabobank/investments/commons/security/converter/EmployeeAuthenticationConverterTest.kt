package nl.rabobank.investments.commons.security.converter

import brave.Span
import brave.Tracer
import io.mockk.every
import io.mockk.mockk
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_APPLICATION_PROFILE
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_DISPLAY_NAME
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_EMPLOYEE_UNIQUE_NAME
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_RABOBANK_ID
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_RABO_DN
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_ROLE
import nl.rabobank.investments.commons.security.domain.EmployeePrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.security.oauth2.jwt.Jwt

class EmployeeAuthenticationConverterTest {

    private val tracer = mockk<Tracer>()
    private val jwtSource = mockk<Jwt>()
    private val span = mockk<Span>(relaxed = true)
    private val employeeAuthenticationConverter = EmployeeAuthenticationConverter(tracer)

    @Test
    fun `conversion of jwt source to principal authentication success`() {
        val claims: MutableMap<String, Any> = HashMap()
        claims[CLAIM_RABOBANK_ID] = "1234567890"
        claims[CLAIM_DISPLAY_NAME] = "Snow, GOT (Jon)"
        claims[CLAIM_RABO_DN] =
            "rabobankid=1234567890,organizationID=3000351915,o=Rabobank,c=NL"
        claims[CLAIM_ROLE] = "adfs-role1"

        every { jwtSource.tokenValue } returns "tokenValue"
        every { jwtSource.claims } returns claims
        every { tracer.currentSpan() } returns span

        val authentication = employeeAuthenticationConverter.convert(jwtSource)
        assertThat(authentication).isInstanceOf(PrincipalAuthentication::class.java)
        assertThat((authentication as PrincipalAuthentication).hasAuthority("ROLE_EMPLOYEE")).isTrue
        assertThat((authentication).hasAuthority("ROLE_adfs-role1")).isTrue
        val employeePrincipal = (authentication).principal as EmployeePrincipal
        assertThat(employeePrincipal.organisationId).isEqualTo("3000351915")
    }

    @Test
    fun `conversion of jwt source to principal authentication success when CLAIM_RABO_DN not available`() {
        val claims: MutableMap<String, Any> = HashMap()
        claims[CLAIM_DISPLAY_NAME] = "Snow, GOT (Jon)"
        claims[CLAIM_ROLE] = "adfs-role1"
        claims[CLAIM_EMPLOYEE_UNIQUE_NAME] = "employer-12345"

        every { jwtSource.tokenValue } returns "tokenValue"
        every { jwtSource.claims } returns claims
        every { tracer.currentSpan() } returns span

        val authentication = employeeAuthenticationConverter.convert(jwtSource)
        assertThat(authentication).isInstanceOf(PrincipalAuthentication::class.java)
        assertThat((authentication as PrincipalAuthentication).hasAuthority("ROLE_EMPLOYEE")).isTrue
        assertThat((authentication).hasAuthority("ROLE_adfs-role1")).isTrue
        val employeePrincipal = (authentication).principal as EmployeePrincipal
        assertThat(employeePrincipal.organisationId).isNull()
        assertThat(employeePrincipal.rabobankId).isNull()
        assertThat(employeePrincipal.employeeUniqueName).isEqualTo("employer-12345")
    }

    @Test
    fun `conversion of jwt source to principal authentication success when CLAIM_APPLICATION_PROFILE present`() {
        val claims: MutableMap<String, Any> = HashMap()
        claims[CLAIM_RABOBANK_ID] = "1234567890"
        claims[CLAIM_DISPLAY_NAME] = "Snow, GOT (Jon)"
        claims[CLAIM_RABO_DN] =
            "rabobankid=1234567890,organizationID=3000351915,o=Rabobank,c=NL"
        claims[CLAIM_APPLICATION_PROFILE] = "xyz;adfs-role1"

        every { jwtSource.tokenValue } returns "tokenValue"
        every { jwtSource.claims } returns claims
        every { tracer.currentSpan() } returns span

        val authentication = employeeAuthenticationConverter.convert(jwtSource)
        assertThat(authentication).isInstanceOf(PrincipalAuthentication::class.java)
        assertThat((authentication as PrincipalAuthentication).hasAuthority("ROLE_EMPLOYEE")).isTrue
        assertThat((authentication).hasAuthority("ROLE_adfs-role1")).isTrue
    }
}
