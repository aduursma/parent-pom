package nl.rabobank.investments.commons.security.authorization.customer.authhub.repository

import io.mockk.every
import io.mockk.mockk
import nl.rabobank.authorisationhub.users.api.client.AHUsersAPIClient
import nl.rabobank.authorisationhub.users.api.model.Arrangement
import nl.rabobank.authorisationhub.users.api.model.Customer
import nl.rabobank.authorisationhub.users.api.model.User
import nl.rabobank.investments.commons.security.domain.CustomerPrincipal
import nl.rabobank.investments.commons.security.domain.EmployeePrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import org.assertj.core.api.Assertions
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.web.server.ResponseStatusException

class CustomerAuthorizationRepositoryTest {

    private val ahUsersAPIClient: AHUsersAPIClient = mockk()
    private val siebelRelationId = "siebelRelationId"
    private val customerAuthorizationRepository = CustomerAuthorizationRepository(ahUsersAPIClient)
    private lateinit var customer: Customer

    @BeforeEach
    fun setup() {
        // resetting customer before each call
        this.customer = testCustomer
    }

    @Test
    fun testAuthorizationSuccess() {
        every {
            ahUsersAPIClient.getUserCustomerAuthorisations(
                siebelRelationId, siebelRelationId, "xAuthToken", null
            )
        } returns customer

        val authorization = customerAuthorizationRepository.userCustomerAuthorization(customerAuthentication)
        Assertions.assertThat(authorization.authorizations).containsExactly("INITIATE_PURCHASE")
        Assertions.assertThat(authorization.arrangements).size().isEqualTo(1)
        val arrangement = authorization.arrangements.toList()[0]
        Assertions.assertThat(arrangement.administrationCode).isEqualTo("04")
        Assertions.assertThat(arrangement.number).isEqualTo("98765432")
        Assertions.assertThat(arrangement.authorizations.toList()).containsExactly("GN_READ", "GN_MODIFY")
    }

    @Test
    fun testEmptyArrangementsAndAgreement() {
        val customer = Customer.newBuilder().build()
        every {
            ahUsersAPIClient.getUserCustomerAuthorisations(
                siebelRelationId, siebelRelationId, "xAuthToken", null
            )
        } returns customer
        val authorization = customerAuthorizationRepository.userCustomerAuthorization(
            customerAuthentication
        )
        Assertions.assertThat(authorization.authorizations).isEmpty()
        Assertions.assertThat(authorization.arrangements).isEmpty()
    }

    @Test
    fun testRoleNotCustomerIsForbidden() {
        Assertions.assertThatExceptionOfType(ResponseStatusException::class.java).isThrownBy {
            customerAuthorizationRepository.userCustomerAuthorization(
                PrincipalAuthentication(
                    "xAuthToken", EmployeePrincipal(), "EMPLOYEE"
                )
            )
        }.withMessageContaining("403 FORBIDDEN")
    }

    @Test
    fun testUserAuthorizationSuccess() {
        every {
            ahUsersAPIClient.getUserAuthorisations(siebelRelationId, "xAuthToken", null)
        } returns testUser

        val authorization = customerAuthorizationRepository.userAuthorization(customerAuthentication)
        // only authorizations where userId == customerId
        Assertions.assertThat(authorization.authorizations).containsExactly("INITIATE_PURCHASE")
        Assertions.assertThat(authorization.authorizations).containsExactly("INITIATE_PURCHASE")
        // arrangements of all customer
        Assertions.assertThat(authorization.arrangements).size().isEqualTo(2)
        val arrangement = authorization.arrangements.toList()[0]
        Assertions.assertThat(arrangement.administrationCode).isEqualTo("04")
        Assertions.assertThat(arrangement.number).isEqualTo("98765432")
        Assertions.assertThat(arrangement.authorizations.toList()).containsExactly("GN_READ", "GN_MODIFY")

        val arrangement2 = authorization.arrangements.toList()[1]
        Assertions.assertThat(arrangement2.administrationCode).isEqualTo("04")
        Assertions.assertThat(arrangement2.number).isEqualTo("11111111")
        Assertions.assertThat(arrangement2.authorizations.toList()).containsExactly("GN_READ", "GN_MODIFY", "CH_EF_01")
    }

    @Test
    fun `testUserAuthorization - doesn't break when response is null`() {
        every {
            ahUsersAPIClient.getUserAuthorisations(siebelRelationId, "xAuthToken", null)
        } returns null

        val authorization = customerAuthorizationRepository.userAuthorization(customerAuthentication)
        Assertions.assertThat(authorization.authorizations).isEmpty()
        Assertions.assertThat(authorization.arrangements).isEmpty()
    }

    @Test
    fun testRoleNotCustomerIsForbiddenForUserAuthorization() {
        Assertions.assertThatExceptionOfType(ResponseStatusException::class.java).isThrownBy {
            customerAuthorizationRepository.userAuthorization(
                PrincipalAuthentication(
                    "xAuthToken", EmployeePrincipal(), "EMPLOYEE"
                )
            )
        }.withMessageContaining("403 FORBIDDEN")
    }

    private val testCustomer =
        Customer.newBuilder().setId(siebelRelationId).addAllAuthorisations(listOf("INITIATE_PURCHASE")).addArrangements(
            Arrangement.newBuilder().setAdministrationCode("04").setNumber("98765432")
                .addAllAuthorisations(listOf("GN_READ", "GN_MODIFY")).build()
        ).build()

    private val testUser = User.newBuilder().addAllCustomers(
        listOf(
            Customer.newBuilder().setId(siebelRelationId).addAllAuthorisations(listOf("INITIATE_PURCHASE"))
                .addArrangements(
                    Arrangement.newBuilder().setAdministrationCode("04").setNumber("98765432")
                        .addAllAuthorisations(listOf("GN_READ", "GN_MODIFY")).build()
                ).build(),
            Customer.newBuilder().setId("extraCustomer").addAllAuthorisations(listOf("SIGN_AGREEMENT")).addArrangements(
                Arrangement.newBuilder().setAdministrationCode("04").setNumber("11111111")
                    .addAllAuthorisations(listOf("GN_READ", "GN_MODIFY", "CH_EF_01")).build()
            ).build(),
            Customer.newBuilder().setId("nullAuthorizations").build()

        )
    ).build()

    private val customerAuthentication = PrincipalAuthentication(
        "xAuthToken",
        CustomerPrincipal().apply {
            siebelCustomerRelationId = siebelRelationId
            siebelUserRelationId = siebelRelationId
            edoAgreementId = "98765432"
            edoKlid = "KLID$edoAgreementId$siebelRelationId"
            edoUserId = siebelRelationId
            authUserId = siebelUserRelationId
        },
        "CUSTOMER"
    )
}
