package nl.rabobank.investments.commons.security

object TestConstants {
    const val ROLE_APPLICATION = "ROLE_APPLICATION"
    const val ROLE_EMPLOYEE = "ROLE_EMPLOYEE"
    const val ROLE_CUSTOMER = "ROLE_CUSTOMER"
}
