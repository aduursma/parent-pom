package nl.rabobank.investments.commons.security.service

import io.mockk.every
import io.mockk.mockk
import nl.rabobank.investments.commons.security.TestConfiguration
import nl.rabobank.investments.commons.security.config.JwsConfig
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CUSTOMER_AUTHORISATION_HEADER
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.USER_TYPE_CUSTOMER
import nl.rabobank.investments.commons.security.domain.CustomerPrincipal
import nl.rabobank.investments.commons.security.testutil.JwsTestWriter
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource
import org.springframework.test.context.junit.jupiter.SpringExtension
import javax.servlet.http.HttpServletRequest

@ExtendWith(SpringExtension::class)
@ContextConfiguration(
    classes = [
        CustomerAuthenticationService::class,
        JwsConfig::class,
        TestConfiguration::class
    ]
)
@TestPropertySource(
    properties = [
        "security.jws.connection-timeout=5000",
        "security.jws.read-timeout=5000",
        "security.jws.url=http://localhost:9876/jwk",
        "security.employee-jws.connection-timeout=5000",
        "security.employee-jws.read-timeout=5000",
        "security.employee-jws.url=http://localhost:9876/jwk"
    ]
)
class CustomerAuthenticationServiceSpringContextTest {

    @Autowired
    private lateinit var authorisationService: CustomerAuthenticationService

    @BeforeEach
    fun setup() {
        SecurityContextHolder.getContext().authentication = null
    }

    @Test
    fun isAuthorised() {
        val httpServletRequest = mockk<HttpServletRequest>(relaxed = true)
        every { httpServletRequest.getHeader(CUSTOMER_AUTHORISATION_HEADER) } returns xAuthUser()

        authorisationService.authenticate(httpServletRequest)
        val authentication = SecurityContextHolder.getContext().authentication
        val customerPrincipal = authentication.principal as CustomerPrincipal
        assertThat(customerPrincipal.siebelUserRelationId).isEqualTo("123")
        assertThat(customerPrincipal.siebelCustomerRelationId).isEqualTo("456")
    }

    private fun xAuthUser(): String {
        return JwsTestWriter.createJwtToken(customer)
    }
}

private val customer = CustomerPrincipal().apply {
    siebelUserRelationId = "123"
    siebelCustomerRelationId = "456"
    authUserType = USER_TYPE_CUSTOMER
}
