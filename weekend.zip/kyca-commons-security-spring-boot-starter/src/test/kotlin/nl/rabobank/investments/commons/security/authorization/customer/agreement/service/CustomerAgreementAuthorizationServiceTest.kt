package nl.rabobank.investments.commons.security.authorization.customer.agreement.service

import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import nl.rabobank.investments.commons.agreement.domain.AgreementAuthorization
import nl.rabobank.investments.commons.agreement.repository.AgreementRepository
import nl.rabobank.investments.commons.security.domain.CustomerPrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test

class CustomerAgreementAuthorizationServiceTest {
    private val investmentArrangementNumber = "98765432"
    private val xAuthToken = "auth-token"
    private val agreementRepository: AgreementRepository = mockk()
    private val customerPrincipal = mockk<CustomerPrincipal>()
    private val authentication = PrincipalAuthentication(
        xAuthToken, customerPrincipal, "CUSTOMER"
    )
    private val customerAgreementAuthorizationService = CustomerAgreementAuthorizationService(
        agreementRepository
    )

    @Test
    fun checkAuthorizations_Success() {
        every {
            agreementRepository.getCustomerAuthorizations(
                investmentArrangementNumber, xAuthToken
            )
        } returns listOf(AgreementAuthorization.VIEW_AGREEMENT, AgreementAuthorization.EDIT_AGREEMENT)
        val validationResult = customerAgreementAuthorizationService.checkAuthorizations(
            AgreementAuthorization.VIEW_AGREEMENT,
            investmentArrangementNumber,
            authentication
        )
        assertThat(validationResult.isValid).isTrue
        assertThat(validationResult.reason).isEqualTo("Customer authorization: VIEW_AGREEMENT")
        verify {
            agreementRepository.getCustomerAuthorizations(investmentArrangementNumber, xAuthToken)
        }
    }

    @Test
    fun checkAuthorizations_Failure() {
        every {
            agreementRepository.getCustomerAuthorizations(
                investmentArrangementNumber, xAuthToken
            )
        } returns listOf(AgreementAuthorization.VIEW_AGREEMENT, AgreementAuthorization.EDIT_AGREEMENT)
        val validationResult = customerAgreementAuthorizationService.checkAuthorizations(
            AgreementAuthorization.VIEW_KEC,
            investmentArrangementNumber,
            authentication
        )
        assertThat(validationResult.isValid).isFalse
        assertThat(validationResult.reason).isEqualTo("Customer authorization: VIEW_KEC")
        verify {
            agreementRepository.getCustomerAuthorizations(investmentArrangementNumber, xAuthToken)
        }
    }
}
