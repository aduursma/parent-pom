package nl.rabobank.investments.commons.security.autoconfigure

import brave.Span
import brave.Tracer
import brave.propagation.TraceContext
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.SerializationFeature
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule
import com.fasterxml.jackson.module.kotlin.jacksonObjectMapper
import io.mockk.every
import io.mockk.mockk
import nl.rabobank.investments.commons.agreement.config.AgreementAutoConfiguration
import org.assertj.core.api.Assertions
import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.boot.test.context.runner.ApplicationContextRunner
import org.springframework.cloud.openfeign.FeignAutoConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.security.oauth2.jwt.JwtDecoder
import org.springframework.web.client.RestTemplate
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate

class SecurityAutoConfigurationSpringContextTest {

    private val contextRunner = ApplicationContextRunner()

    @Test
    fun `when properties present we should be able to load all beans`() {
        contextRunner
            .withPropertyValues(
                "security.jws.connection-timeout=5000",
                "security.jws.read-timeout=5000",
                "security.jws.url=http://localhost:9876/jwk",
                "security.employee-jws.connection-timeout=5000",
                "security.employee-jws.read-timeout=5000",
                "security.employee-jws.url=http://localhost:9876/jwk",
                "authorisationHubUsers.server=http://localhost:9876",
                "ssl.keystoreBase64=keystoreBase64",
                "ssl.keystorePassword=keystorePassword",
                "ssl.truststoreBase64=truststoreBase64",
                "ssl.truststorePassword=truststorePassword",
                "investments-agreement-service.uri=http://localhost:9876/api/agreement"
            )
            .withAllowBeanDefinitionOverriding(true)
            .withUserConfiguration(
                SecurityAutoConfiguration::class.java,
                AgreementAutoConfiguration::class.java,
                SecurityTestConfiguration::class.java,
                FeignAutoConfiguration::class.java
            )
            .run { context ->
                // beans defined in JwsConfiguration
                Assertions.assertThat(context).hasBean("customerAuthenticationConverter")
                Assertions.assertThat(context).hasBean("employeeAuthenticationConverter")
                Assertions.assertThat(context).hasBean("customerJwtDecoder")
                Assertions.assertThat(context).hasBean("employeeJwtDecoder")
                // beans defined in SecurityConfiguration
                Assertions.assertThat(context).hasBean("keyStore")
                Assertions.assertThat(context).hasBean("trustStore")
                Assertions.assertThat(context).hasBean("privateKey")
                Assertions.assertThat(context).hasBean("certificate")
                // services and components
                Assertions.assertThat(context).hasBean("appAuthenticationService")
                Assertions.assertThat(context).hasBean("customerAuthenticationService")
                Assertions.assertThat(context).hasBean("employeeAuthenticationService")
                Assertions.assertThat(context).hasBean("securityFilter")
                Assertions.assertThat(context).hasBean("unauthorizedEntryPoint")
                Assertions.assertThat(context).hasBean("corsConfigurationSource")
                Assertions.assertThat(context).hasBean("customerAuthorizationHubService")
                Assertions.assertThat(context).hasBean("customerAgreementAuthorizationService")
                Assertions.assertThat(context).hasBean("employeeAuthorizationService")
                Assertions.assertThat(context).hasBean("customerAuthorizationRepository")
            }
    }
}

@TestConfiguration
class SecurityTestConfiguration {

    @Bean
    fun tracer(): Tracer {
        val span = mockk<Span>(relaxed = true)
        val context = TraceContext.newBuilder().traceId(12L).spanId(34L).build()
        every { span.context() } returns context

        val tracer = mockk<Tracer>()
        every { tracer.currentSpan() } returns span
        every { tracer.newTrace() } returns span
        return tracer
    }

    @Bean
    fun keyStore(): KeyStore {
        return mockk()
    }

    @Bean
    fun trustStore(): KeyStore {
        return mockk()
    }

    @Bean
    fun privateKey(): PrivateKey {
        return mockk()
    }

    @Bean
    fun certificate(): X509Certificate {
        return mockk()
    }

    @Bean
    fun objectMapper(): ObjectMapper = jacksonObjectMapper().registerModule(JavaTimeModule())
        .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)

    @Bean
    fun employeeJwtDecoder(): JwtDecoder = mockk()

    @Bean
    fun customerJwtDecoder(): JwtDecoder = mockk()

    @Bean
    fun restTemplate(): RestTemplate = mockk()
}
