package nl.rabobank.investments.commons.security.authorization.employee.service

import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import io.split.client.SplitClient
import nl.rabobank.investments.commons.agreement.domain.AgreementAuthorization
import nl.rabobank.investments.commons.agreement.domain.ProductCode
import nl.rabobank.investments.commons.agreement.repository.AgreementRepository
import nl.rabobank.investments.commons.ff.util.SplitUtils
import nl.rabobank.investments.commons.security.domain.CustomerPrincipal
import nl.rabobank.investments.commons.security.domain.EmployeePrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.domain.Role
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.assertThrows
import org.springframework.http.HttpStatus
import org.springframework.web.server.ResponseStatusException

private const val SPLIT_322_VERIFICATION_ALLOWED = "investments-sales-322-verification-allowed"
private const val SPLIT_332_VERIFICATION_ALLOWED = "investments-sales-332-verification-allowed"

class EmployeeAuthorizationServiceTest {
    private val investmentArrangementNumberIVB = "98765432"
    private val investmentArrangementNumberRBBA = "23456789"
    private val employeeName = "TestEmployee"
    private val employeePrincipal = EmployeePrincipal().apply {
        employeePrincipalName = employeeName
        parentOrganisationId = "parentOrganisationId"
        employeeUniqueName = "employeeUniqueName"
    }
    private val investmentsAgreementRepository = mockk<AgreementRepository>()
    private val splitClient = mockk<SplitClient>()
    private val employeeAuthorizationService = EmployeeAuthorizationService(
        investmentsAgreementRepository,
        SplitUtils(splitClient)
    )
    private val principalWithPBAuthorizations = PrincipalAuthentication(
        "token", employeePrincipal, Role.EMPLOYEE,
        listOf(
            "InvsalesmedPBAGRMENTSVIEW",
            "InvsalesmedPBAGRMENTSEDIT",
            "InvsaleshighPBAGRMENTSDISCN",
            "InvsalesmedPBKECVIEW",
            "InvsalesmedPBKECVIEW",
            "InvsalesmedPBKECEDIT",
            "InvsalesmedPBTRADBLOCKVIEW",
            "InvsalesmedPBTRADBLOCKEDIT"
        )
    )
    private val principalWithNPBAuthorizations = PrincipalAuthentication(
        "token", employeePrincipal, Role.EMPLOYEE,
        listOf(
            "InvsalesmedNPBAGRMENTSVIEW", "InvsalesmedNPBAGRMENTSEDIT",
            "InvsaleshighNPBAGRMENTSDISCN", "InvsalesmedNPBKECVIEW", "InvsalesmedNPBKECEDIT",
            "InvsalesmedNPBTRADBLOCKVIEW", "InvsalesmedNPBTRADBLOCKEDIT"
        )
    )
    private val principalWithVerifyAuthorization = PrincipalAuthentication(
        "token", employeePrincipal, Role.EMPLOYEE,
        listOf(
            "InvsalesmedVerify"
        )
    )
    private val principalWithoutAuthorizations = PrincipalAuthentication(
        "token",
        employeePrincipal,
        Role.EMPLOYEE
    )

    @BeforeEach
    fun setup() {
        every {
            investmentsAgreementRepository.getProductType(investmentArrangementNumberIVB, false)
        } returns ProductCode.IVB
        every {
            investmentsAgreementRepository.getProductType(investmentArrangementNumberRBBA, false)
        } returns ProductCode.RBBA
    }

    @Test
    fun testPBAuthorizationsSuccess() {
        // agreement view - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_AGREEMENT,
                investmentArrangementNumberIVB,
                principalWithPBAuthorizations
            ).isValid
        ).isTrue
        // agreement edit - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.EDIT_AGREEMENT,
                investmentArrangementNumberIVB,
                principalWithPBAuthorizations
            ).isValid
        ).isTrue
        // agreement discontinue - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.DISCONTINUE_AGREEMENT,
                investmentArrangementNumberIVB,
                principalWithPBAuthorizations
            ).isValid
        ).isTrue
        // kec view - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_KEC,
                investmentArrangementNumberIVB,
                principalWithPBAuthorizations
            ).isValid
        ).isTrue
        // kec edit - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.EDIT_KEC,
                investmentArrangementNumberIVB,
                principalWithPBAuthorizations
            ).isValid
        ).isTrue

        // trading block view - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_TRADING_BLOCK,
                investmentArrangementNumberIVB,
                principalWithPBAuthorizations
            ).isValid
        ).isTrue
        // trading block edit - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.EDIT_TRADING_BLOCK,
                investmentArrangementNumberIVB,
                principalWithPBAuthorizations
            ).isValid
        ).isTrue

        verify(exactly = 7) { investmentsAgreementRepository.getProductType(investmentArrangementNumberIVB, false) }
        verify(exactly = 0) { splitClient.getTreatment(investmentArrangementNumberIVB, SPLIT_322_VERIFICATION_ALLOWED) }
        verify(exactly = 0) { splitClient.getTreatment(investmentArrangementNumberIVB, SPLIT_332_VERIFICATION_ALLOWED) }
    }

    @Test
    fun testNPBAuthorizationsSuccess() {
        // agreement view - npb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_AGREEMENT,
                investmentArrangementNumberRBBA,
                principalWithNPBAuthorizations
            ).isValid
        ).isTrue
        // agreement edit - npb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.EDIT_AGREEMENT,
                investmentArrangementNumberRBBA,
                principalWithNPBAuthorizations
            ).isValid
        ).isTrue
        // agreement discontinue - npb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.DISCONTINUE_AGREEMENT,
                investmentArrangementNumberRBBA,
                principalWithNPBAuthorizations
            ).isValid
        ).isTrue
        // kec view - npb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_KEC, investmentArrangementNumberRBBA, principalWithNPBAuthorizations
            ).isValid
        ).isTrue
        // kec edit - npb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.EDIT_KEC, investmentArrangementNumberRBBA, principalWithNPBAuthorizations
            ).isValid
        ).isTrue

        // trading block view - npb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_TRADING_BLOCK,
                investmentArrangementNumberRBBA,
                principalWithNPBAuthorizations
            ).isValid
        ).isTrue
        // trading block edit - npb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.EDIT_TRADING_BLOCK,
                investmentArrangementNumberRBBA,
                principalWithNPBAuthorizations
            ).isValid
        ).isTrue
        verifyNPBAuthorization()
    }

    private fun verifyNPBAuthorization() {
        verify(exactly = 7) { investmentsAgreementRepository.getProductType(investmentArrangementNumberRBBA, false) }
        verify(exactly = 0) {
            splitClient.getTreatment(
                investmentArrangementNumberRBBA,
                SPLIT_322_VERIFICATION_ALLOWED
            )
        }
        verify(exactly = 0) {
            splitClient.getTreatment(
                investmentArrangementNumberRBBA,
                SPLIT_332_VERIFICATION_ALLOWED
            )
        }
    }

    @Test
    fun `test verify role with splits 322 and 332 enabled`() {
        setSplitTreatmentMock("on")
        // agreement view - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_AGREEMENT,
                investmentArrangementNumberIVB,
                principalWithVerifyAuthorization
            ).isValid
        ).isTrue
        // agreement edit - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.EDIT_AGREEMENT,
                investmentArrangementNumberIVB,
                principalWithVerifyAuthorization
            ).isValid
        ).isTrue
        // agreement discontinue - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.DISCONTINUE_AGREEMENT,
                investmentArrangementNumberIVB,
                principalWithVerifyAuthorization
            ).isValid
        ).isTrue
        // kec view - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_KEC,
                investmentArrangementNumberIVB,
                principalWithVerifyAuthorization
            ).isValid
        ).isTrue
        // kec edit - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.EDIT_KEC, investmentArrangementNumberIVB, principalWithVerifyAuthorization
            ).isValid
        ).isTrue

        // trading block view - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_TRADING_BLOCK,
                investmentArrangementNumberIVB,
                principalWithVerifyAuthorization
            ).isValid
        ).isTrue
        // trading block edit - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.EDIT_TRADING_BLOCK,
                investmentArrangementNumberIVB,
                principalWithVerifyAuthorization
            ).isValid
        ).isTrue
        verifyTestWithSplitsEnabled()
    }

    private fun verifyTestWithSplitsEnabled() {
        verify(exactly = 0) { investmentsAgreementRepository.getProductType(investmentArrangementNumberIVB, false) }
        verify(exactly = 6) {
            splitClient.getTreatment(
                employeeName,
                SPLIT_322_VERIFICATION_ALLOWED,
                mapOf("investmentArrangementNumber" to investmentArrangementNumberIVB)
            )
        }
        verify(exactly = 1) {
            splitClient.getTreatment(
                employeeName,
                SPLIT_332_VERIFICATION_ALLOWED,
                mapOf("investmentArrangementNumber" to investmentArrangementNumberIVB)
            )
        }
    }

    @Test
    fun `test verify role with splits 322 and 332 disabled`() {
        setSplitTreatmentMock("off")
        // agreement view - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_AGREEMENT,
                investmentArrangementNumberIVB,
                principalWithVerifyAuthorization
            ).isValid
        ).isFalse
        // agreement edit - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.EDIT_AGREEMENT,
                investmentArrangementNumberIVB,
                principalWithVerifyAuthorization
            ).isValid
        ).isFalse
        // agreement discontinue - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.DISCONTINUE_AGREEMENT,
                investmentArrangementNumberIVB,
                principalWithVerifyAuthorization
            ).isValid
        ).isFalse
        // kec view - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_KEC,
                investmentArrangementNumberIVB,
                principalWithVerifyAuthorization
            ).isValid
        ).isFalse
        // kec edit - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.EDIT_KEC, investmentArrangementNumberIVB, principalWithVerifyAuthorization
            ).isValid
        ).isFalse

        // trading block view - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_TRADING_BLOCK,
                investmentArrangementNumberIVB,
                principalWithVerifyAuthorization
            ).isValid
        ).isFalse
        // trading block edit - pb
        assertThat(
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.EDIT_TRADING_BLOCK,
                investmentArrangementNumberIVB,
                principalWithVerifyAuthorization
            ).isValid
        ).isFalse
        verifyTestWithSplitsDisabled()
    }

    private fun verifyTestWithSplitsDisabled() {
        verify(exactly = 0) { investmentsAgreementRepository.getProductType(investmentArrangementNumberIVB, false) }
        verify(exactly = 6) {
            splitClient.getTreatment(
                employeeName,
                SPLIT_322_VERIFICATION_ALLOWED,
                mapOf("investmentArrangementNumber" to investmentArrangementNumberIVB)
            )
        }
        verify(exactly = 1) {
            splitClient.getTreatment(
                employeeName,
                SPLIT_332_VERIFICATION_ALLOWED,
                mapOf("investmentArrangementNumber" to investmentArrangementNumberIVB)
            )
        }
    }
    @Test
    fun testAuthorizationsNotAuthorizedValidationFailed() {
        every {
            investmentsAgreementRepository.getProductType(
                investmentArrangementNumberIVB,
                false
            )
        } returns ProductCode.IVB
        // agreement view - pb
        val response = employeeAuthorizationService.checkAuthorizations(
            AgreementAuthorization.VIEW_AGREEMENT,
            investmentArrangementNumberIVB,
            principalWithoutAuthorizations
        )
        assertThat(response.isValid).isFalse
        assertThat(response.reason).isEqualTo("Employee Authorization for role: InvsalesmedPBAGRMENTSVIEW")
    }

    @Test
    fun `test invalid authorizations - not implemented roles `() {
        every {
            investmentsAgreementRepository.getProductType(
                investmentArrangementNumberIVB,
                false
            )
        } returns ProductCode.IVB
        val response = employeeAuthorizationService.checkAuthorizations(
            AgreementAuthorization.VIEW_SUSTAINABILITY,
            investmentArrangementNumberIVB,
            principalWithoutAuthorizations
        )
        assertThat(response.isValid).isFalse
        assertThat(response.reason).isEqualTo("Role not implemented: VIEW_SUSTAINABILITY")
    }

    @Test
    fun testAuthorizationsFailureNotCustomerRole() {
        val customerPrincipal = PrincipalAuthentication(
            "token",
            CustomerPrincipal(),
            Role.CUSTOMER
        )
        // agreement view - pb
        val exception = assertThrows<ResponseStatusException> {
            employeeAuthorizationService.checkAuthorizations(
                AgreementAuthorization.VIEW_AGREEMENT,
                investmentArrangementNumberIVB,
                customerPrincipal
            )
        }
        assertThat(exception.status).isEqualTo(HttpStatus.FORBIDDEN)
        assertThat(exception.message).contains("Logged in user is not EMPLOYEE")
    }

    private fun setSplitTreatmentMock(result: String) {
        every {
            splitClient.getTreatment(
                employeeName,
                SPLIT_322_VERIFICATION_ALLOWED,
                mapOf("investmentArrangementNumber" to investmentArrangementNumberIVB)
            )
        } returns result
        every {
            splitClient.getTreatment(
                employeeName,
                SPLIT_332_VERIFICATION_ALLOWED,
                mapOf("investmentArrangementNumber" to investmentArrangementNumberIVB)
            )
        } returns result
    }
}
