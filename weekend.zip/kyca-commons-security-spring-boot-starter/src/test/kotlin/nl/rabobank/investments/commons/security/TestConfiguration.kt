package nl.rabobank.investments.commons.security

import brave.Span
import brave.Tracer
import brave.propagation.TraceContext
import com.fasterxml.jackson.databind.ObjectMapper
import com.nimbusds.jwt.JWTParser
import io.mockk.every
import io.mockk.mockk
import nl.rabobank.investments.commons.security.testutil.JwsTestWriter
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.context.annotation.Bean
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder
import org.springframework.security.oauth2.jwt.JwtDecoder

@TestConfiguration
class TestConfiguration {

    val jwtDecoder = JwtDecoder { token ->
        val jwt = JWTParser.parse(token)
        JwsTestWriter.createJwt(token, jwt)
    }

    @Bean
    fun tracer(): Tracer {
        val span = mockk<Span>(relaxed = true)
        val context = TraceContext.newBuilder().traceId(12L).spanId(34L).build()
        every { span.context() } returns context

        val tracer = mockk<Tracer>()
        every { tracer.currentSpan() } returns span
        every { tracer.newTrace() } returns span
        return tracer
    }

    @Bean
    fun objectMapper(): ObjectMapper {
        return Jackson2ObjectMapperBuilder.json().build()
    }

    @Bean
    fun employeeJwtDecoder(): JwtDecoder = jwtDecoder

    @Bean
    fun customerJwtDecoder(): JwtDecoder = jwtDecoder
}
