package nl.rabobank.investments.commons.security.domain

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test

class PrincipalAuthenticationTest {

    @Test
    fun verifyGrantedAuthorityConcatenation() {
        val grantedAuthority = PrincipalAuthentication.roleAuthority("CUSTOMER")
        assertThat(grantedAuthority.authority).isEqualTo("ROLE_CUSTOMER")
    }

    @Test
    fun verifyGrantedAuthoritiesConcatenation() {
        val grantedAuthorities = ArrayList(
            PrincipalAuthentication.grantedAuthorities(listOf("CUSTOMER", "EMPLOYEE"), listOf("FUN_NEW", "FUN_MOD"))
        )
        assertThat(grantedAuthorities[0].authority).isEqualTo("ROLE_CUSTOMER")
        assertThat(grantedAuthorities[1].authority).isEqualTo("ROLE_EMPLOYEE")
        assertThat(grantedAuthorities[2].authority).isEqualTo("FUN_NEW")
        assertThat(grantedAuthorities[3].authority).isEqualTo("FUN_MOD")
    }
}
