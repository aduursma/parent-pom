package nl.rabobank.investments.commons.security.service

import brave.Span
import brave.Tracer
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkObject
import io.mockk.mockkStatic
import io.mockk.unmockkStatic
import io.mockk.verify
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLIENT_CERTIFICATE_HEADER
import nl.rabobank.investments.commons.security.domain.ApplicationPrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.util.CertificateUtil
import nl.rabobank.investments.commons.security.util.LoggingUtil
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.core.env.Environment
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.core.context.SecurityContextImpl
import java.security.Principal
import java.security.cert.CertificateException
import java.security.cert.X509Certificate
import javax.security.auth.x500.X500Principal
import javax.servlet.http.HttpServletRequest

class AppAuthenticationServiceTest {
    private val tracer = mockk<Tracer>()
    private val environment = mockk<Environment>()
    private val httpServletRequest = mockk<HttpServletRequest>()
    private val x509Certificate = mockk<X509Certificate>()
    private val x500Principal = mockk<X500Principal>()
    private val principal = mockk<Principal>()
    private val span = mockk<Span>(relaxed = true)

    private val appAuthenticationService = AppAuthenticationService(tracer, environment)

    @BeforeEach
    fun beforeEach() {
        mockkStatic("org.springframework.security.core.context.SecurityContextHolder")
        every { SecurityContextHolder.getContext() } returns SecurityContextImpl()
    }

    @AfterEach
    fun afterEach() {
        unmockkStatic("org.springframework.security.core.context.SecurityContextHolder")
    }

    @Test
    fun `test canAuthenticate success`() {
        every { httpServletRequest.getHeader(CLIENT_CERTIFICATE_HEADER) } returns "some value"
        assertThat(appAuthenticationService.canAuthenticate(httpServletRequest)).isTrue
    }

    @Test
    fun `test canAuthenticate failure`() {
        every { httpServletRequest.getHeader(CLIENT_CERTIFICATE_HEADER) } returns ""
        assertThat(appAuthenticationService.canAuthenticate(httpServletRequest)).isFalse
    }

    @Test
    fun `test authenticate success`() {
        mockkObject(CertificateUtil)
        mockkObject(LoggingUtil)
        every { httpServletRequest.getHeader(CLIENT_CERTIFICATE_HEADER) } returns "some value"
        every { CertificateUtil.certificateFromBytes(any()) } returns x509Certificate
        every { x509Certificate.subjectX500Principal } returns x500Principal
        every { x500Principal.name } returns "CN=kyca-devtest.investments.rabobank.nl,"
        every { x509Certificate.issuerDN } returns principal
        every { principal.name } returns "rabobank.nl"
        every {
            environment.getProperty("application.authorities.kyca-devtest.investments.rabobank.nl")
        } returns "APP_OFFER_SERVICE"
        every { tracer.currentSpan() } returns span

        appAuthenticationService.authenticate(httpServletRequest)

        assertThat(SecurityContextHolder.getContext().authentication).isInstanceOf(PrincipalAuthentication::class.java)
        verify(exactly = 1) { LoggingUtil.addTraceLogging(tracer, any<ApplicationPrincipal>()) }
    }

    @Test
    fun `test authenticate failure when client certificate string is null or empty `() {
        every { httpServletRequest.getHeader(CLIENT_CERTIFICATE_HEADER) } returns ""

        appAuthenticationService.authenticate(httpServletRequest)

        verify(exactly = 0) { LoggingUtil.addTraceLogging(tracer, any<ApplicationPrincipal>()) }
    }

    @Test
    fun `test authenticate success when application authorities property is empty`() {
        mockkObject(CertificateUtil)
        mockkObject(LoggingUtil)
        every { httpServletRequest.getHeader(CLIENT_CERTIFICATE_HEADER) } returns "some value"
        every { CertificateUtil.certificateFromBytes(any()) } returns x509Certificate
        every { x509Certificate.subjectX500Principal } returns x500Principal
        every { x500Principal.name } returns "CN=kyca-devtest.investments.rabobank.nl,"
        every { x509Certificate.issuerDN } returns principal
        every { principal.name } returns "rabobank.nl"
        every { environment.getProperty("application.authorities.kyca-devtest.investments.rabobank.nl") } returns ""
        every { tracer.currentSpan() } returns span

        appAuthenticationService.authenticate(httpServletRequest)

        verify(exactly = 1) { LoggingUtil.addTraceLogging(tracer, any<ApplicationPrincipal>()) }
    }

    @Test
    fun `test authenticate failure when issuer distinguished name does not contain rabobank`() {
        mockkObject(CertificateUtil)
        mockkObject(LoggingUtil)
        every { httpServletRequest.getHeader(CLIENT_CERTIFICATE_HEADER) } returns "some value"
        every { CertificateUtil.certificateFromBytes(any()) } returns x509Certificate
        every { x509Certificate.subjectX500Principal } returns x500Principal
        every { x500Principal.name } returns "CN=kyca-devtest.investments.rabobank.nl,"
        every { x509Certificate.issuerDN } returns principal
        every { principal.name } returns "bla bla"
        every {
            environment.getProperty("application.authorities.kyca-devtest.investments.rabobank.nl")
        } returns "APP_OFFER_SERVICE"

        appAuthenticationService.authenticate(httpServletRequest)

        verify(exactly = 0) { LoggingUtil.addTraceLogging(tracer, any<ApplicationPrincipal>()) }
    }

    @Test
    fun `test authenticate failure when certificate exception is thrown by certificate util`() {
        mockkObject(CertificateUtil)
        mockkObject(LoggingUtil)
        every { httpServletRequest.getHeader(CLIENT_CERTIFICATE_HEADER) } returns "some value"
        every { CertificateUtil.certificateFromBytes(any()) } throws CertificateException()

        appAuthenticationService.authenticate(httpServletRequest)

        verify(exactly = 0) { LoggingUtil.addTraceLogging(tracer, any<ApplicationPrincipal>()) }
    }
}
