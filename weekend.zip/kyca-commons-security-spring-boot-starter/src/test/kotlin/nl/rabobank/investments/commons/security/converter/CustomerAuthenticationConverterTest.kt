package nl.rabobank.investments.commons.security.converter

import brave.Span
import brave.Tracer
import com.fasterxml.jackson.databind.ObjectMapper
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkObject
import io.mockk.verify
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.USER_TYPE_CUSTOMER
import nl.rabobank.investments.commons.security.domain.CustomerPrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.util.LoggingUtil
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.security.oauth2.jwt.Jwt

class CustomerAuthenticationConverterTest {

    private val objectMapper = mockk<ObjectMapper>()
    private val tracer = mockk<Tracer>()
    private val jwtSource = mockk<Jwt>()
    private val span = mockk<Span>(relaxed = true)

    private val customerAuthenticationConverter = CustomerAuthenticationConverter(objectMapper, tracer)

    @Test
    fun `conversion of jwt source to principal authentication success`() {
        val customerPrincipal = CustomerPrincipal()
        customerPrincipal.authUserType = USER_TYPE_CUSTOMER
        customerPrincipal.authUserId = "authUserId"
        customerPrincipal.authUserLevel = "authUserLevel"
        customerPrincipal.siebelCustomerRelationId = "siebelCustomerRelationId"
        customerPrincipal.siebelUserRelationId = "siebelUserRelationId"
        customerPrincipal.edoKlid = "edoKlid"
        mockkObject(LoggingUtil)
        every {
            objectMapper.convertValue(any<Map<String, Any>>(), any<Class<CustomerPrincipal>>())
        } returns customerPrincipal
        every { jwtSource.claims } returns emptyMap()
        every { jwtSource.tokenValue } returns "tokenValue"
        every { tracer.currentSpan() } returns span

        assertThat(customerAuthenticationConverter.convert(jwtSource)).isInstanceOf(PrincipalAuthentication::class.java)
        verify(exactly = 1) { LoggingUtil.addTraceLogging(tracer, any<MutableMap<String, String>>()) }
    }

    @Test
    fun `jwt source conversion success when only customerPrincipal authUserType set`() {
        val customerPrincipal = CustomerPrincipal()
        customerPrincipal.authUserType = USER_TYPE_CUSTOMER
        mockkObject(LoggingUtil)
        every {
            objectMapper.convertValue(any<Map<String, Any>>(), any<Class<CustomerPrincipal>>())
        } returns customerPrincipal
        every { jwtSource.claims } returns emptyMap()
        every { jwtSource.tokenValue } returns "tokenValue"
        every { tracer.currentSpan() } returns span

        assertThat(customerAuthenticationConverter.convert(jwtSource)).isInstanceOf(PrincipalAuthentication::class.java)
        verify(exactly = 1) { LoggingUtil.addTraceLogging(tracer, any<MutableMap<String, String>>()) }
    }

    @Test
    fun `jwt source conversion failure when customerPrincipal authUserType not of type customer`() {
        val customerPrincipal = CustomerPrincipal()
        mockkObject(LoggingUtil)
        every {
            objectMapper.convertValue(any<Map<String, Any>>(), any<Class<CustomerPrincipal>>())
        } returns customerPrincipal
        every { jwtSource.claims } returns emptyMap()

        assertThat(customerAuthenticationConverter.convert(jwtSource)).isNull()
        verify(exactly = 0) { LoggingUtil.addTraceLogging(tracer, any<MutableMap<String, String>>()) }
    }
}
