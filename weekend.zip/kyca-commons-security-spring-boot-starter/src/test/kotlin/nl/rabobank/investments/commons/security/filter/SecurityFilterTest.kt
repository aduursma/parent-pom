package nl.rabobank.investments.commons.security.filter

import io.mockk.every
import io.mockk.mockk
import io.mockk.verify
import nl.rabobank.investments.commons.security.service.AppAuthenticationService
import nl.rabobank.investments.commons.security.service.CustomerAuthenticationService
import nl.rabobank.investments.commons.security.service.EmployeeAuthenticationService
import org.junit.jupiter.api.Test
import javax.servlet.FilterChain
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

class SecurityFilterTest {
    private val request = mockk<HttpServletRequest>()
    private val response = mockk<HttpServletResponse>()
    private val filterChain = mockk<FilterChain>()
    private val employeeAuthenticationService = mockk<EmployeeAuthenticationService>()
    private val customerAuthenticationService = mockk<CustomerAuthenticationService>()
    private val appAuthenticationService = mockk<AppAuthenticationService>()
    private val securityFilter = SecurityFilter(employeeAuthenticationService, customerAuthenticationService,
        appAuthenticationService)

    @Test
    fun `test doFilterInternal`() {
        every { employeeAuthenticationService.canAuthenticate(request) } returns true
        every { employeeAuthenticationService.authenticate(request) } returns Unit
        every { customerAuthenticationService.canAuthenticate(request) } returns false
        every { appAuthenticationService.canAuthenticate(request) } returns false
        every { filterChain.doFilter(request, response) } returns Unit

        securityFilter.doFilterInternal(request, response, filterChain)

        verify(exactly = 1) { employeeAuthenticationService.authenticate(request) }
        verify(exactly = 0) { customerAuthenticationService.authenticate(request) }
        verify(exactly = 0) { appAuthenticationService.authenticate(request) }
        verify(exactly = 1) { filterChain.doFilter(request, response) }
    }
}
