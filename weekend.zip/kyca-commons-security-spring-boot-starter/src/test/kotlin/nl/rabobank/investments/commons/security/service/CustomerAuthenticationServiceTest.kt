package nl.rabobank.investments.commons.security.service

import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkStatic
import io.mockk.unmockkStatic
import io.mockk.verify
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CUSTOMER_AUTHORISATION_HEADER
import nl.rabobank.investments.commons.security.converter.CustomerAuthenticationConverter
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.AfterEach
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.security.authentication.AbstractAuthenticationToken
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.core.context.SecurityContextImpl
import org.springframework.security.oauth2.jwt.Jwt
import org.springframework.security.oauth2.jwt.JwtDecoder
import org.springframework.security.oauth2.jwt.JwtException
import javax.servlet.http.HttpServletRequest

class CustomerAuthenticationServiceTest {

    private val customerJwtDecoder = mockk<JwtDecoder>()
    private val customerAuthenticationConverter = mockk<CustomerAuthenticationConverter>()
    private val jwt = mockk<Jwt>()
    private val authenticationToken = mockk<AbstractAuthenticationToken>()
    private val httpServletRequest = mockk<HttpServletRequest>()

    private val customerAuthenticationService = CustomerAuthenticationService(
        customerJwtDecoder,
        customerAuthenticationConverter
    )

    @BeforeEach
    fun beforeEach() {
        mockkStatic("org.springframework.security.core.context.SecurityContextHolder")
        every { SecurityContextHolder.getContext() } returns SecurityContextImpl()
    }

    @AfterEach
    fun afterEach() {
        unmockkStatic("org.springframework.security.core.context.SecurityContextHolder")
    }

    @Test
    fun `test canAuthenticate success`() {
        every { httpServletRequest.getHeader(CUSTOMER_AUTHORISATION_HEADER) } returns "some value"
        assertThat(customerAuthenticationService.canAuthenticate(httpServletRequest)).isTrue
    }

    @Test
    fun `test canAuthenticate failure`() {
        every { httpServletRequest.getHeader(CUSTOMER_AUTHORISATION_HEADER) } returns ""
        assertThat(customerAuthenticationService.canAuthenticate(httpServletRequest)).isFalse
    }

    @Test
    fun `test authenticate success`() {
        every { httpServletRequest.getHeader(CUSTOMER_AUTHORISATION_HEADER) } returns "some value"
        every { customerJwtDecoder.decode(any()) } returns jwt
        every { customerAuthenticationConverter.convert(any()) } returns authenticationToken
        every { authenticationToken.isAuthenticated } returns true

        customerAuthenticationService.authenticate(httpServletRequest)

        assertThat(SecurityContextHolder.getContext().authentication).isNotNull
    }

    @Test
    fun `test authenticate failure when encrypted token is null or blank`() {
        every { httpServletRequest.getHeader(CUSTOMER_AUTHORISATION_HEADER) } returns null

        customerAuthenticationService.authenticate(httpServletRequest)

        verify(exactly = 0) { customerAuthenticationConverter.convert(any()) }
    }

    @Test
    fun `test authenticate failure when jwt exception is thrown`() {
        every { httpServletRequest.getHeader(CUSTOMER_AUTHORISATION_HEADER) } returns "some value"
        every { customerJwtDecoder.decode(any()) } throws JwtException("any message")

        customerAuthenticationService.authenticate(httpServletRequest)

        verify(exactly = 0) { SecurityContextHolder.getContext() }
    }

    @Test
    fun `test authenticate failure when authentication token is null`() {
        every { httpServletRequest.getHeader(CUSTOMER_AUTHORISATION_HEADER) } returns "some value"
        every { customerJwtDecoder.decode(any()) } returns jwt
        every { customerAuthenticationConverter.convert(any()) } returns null

        customerAuthenticationService.authenticate(httpServletRequest)

        verify(exactly = 0) { SecurityContextHolder.getContext() }
    }

    @Test
    fun `test authenticate failure when authentication token is not authenticated`() {
        every { httpServletRequest.getHeader(CUSTOMER_AUTHORISATION_HEADER) } returns "some value"
        every { customerJwtDecoder.decode(any()) } returns jwt
        every { customerAuthenticationConverter.convert(any()) } returns authenticationToken
        every { authenticationToken.isAuthenticated } returns false

        customerAuthenticationService.authenticate(httpServletRequest)

        verify(exactly = 0) { SecurityContextHolder.getContext() }
    }
}
