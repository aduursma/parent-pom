package nl.rabobank.investments.commons.security.service

import io.mockk.every
import io.mockk.mockk
import nl.rabobank.investments.commons.security.TestConfiguration
import nl.rabobank.investments.commons.security.TestConstants.ROLE_CUSTOMER
import nl.rabobank.investments.commons.security.TestConstants.ROLE_EMPLOYEE
import nl.rabobank.investments.commons.security.config.JwsConfig
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_DISPLAY_NAME
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_RABOBANK_ID
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_RABO_DN
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_ROLE
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.EMPLOYEE_AUTHORISATION_HEADER
import nl.rabobank.investments.commons.security.domain.EmployeePrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.testutil.JwsTestWriter
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.test.context.ContextConfiguration
import org.springframework.test.context.TestPropertySource
import org.springframework.test.context.junit.jupiter.SpringExtension
import javax.servlet.http.HttpServletRequest

@ExtendWith(SpringExtension::class)
@ContextConfiguration(
    classes = [
        EmployeeAuthenticationService::class,
        JwsConfig::class,
        TestConfiguration::class
    ]
)
@TestPropertySource(
    properties = [
        "security.jws.connection-timeout=5000",
        "security.jws.read-timeout=5000",
        "security.jws.url=http://localhost:9876/jwk",
        "security.employee-jws.connection-timeout=5000",
        "security.employee-jws.read-timeout=5000",
        "security.employee-jws.url=http://localhost:9876/jwk"
    ]
)
class EmployeeAuthenticationServiceSpringContextTest {

    @Autowired
    private lateinit var authenticationService: EmployeeAuthenticationService

    @BeforeEach
    fun setup() {
        SecurityContextHolder.getContext().authentication = null
    }

    @Test
    fun isAuthorised_adGroupArray() {
        val httpServletRequest = mockk<HttpServletRequest>()
        every { httpServletRequest.getHeader(EMPLOYEE_AUTHORISATION_HEADER) } returns xAuthEmployee_adGroupArray()

        authenticationService.authenticate(httpServletRequest)
        val authentication = SecurityContextHolder.getContext().authentication as PrincipalAuthentication
        val employee = authentication.principal as EmployeePrincipal
        assertThat(employee.name).isEqualTo("Snow, GOT (Jon)")
        assertThat(employee.rabobankId).isEqualTo("1234567890")
        assertThat(employee.organisationId).isEqualTo("3000351915")
        assertThat(authentication.authorities).hasSize(3)
        assertThat(authentication.hasAuthority("ROLE_adfs-role1")).isTrue
        assertThat(authentication.hasAuthority("ROLE_adfs-role2")).isTrue
        assertThat(authentication.hasAuthority("ROLE_adfs-role3")).isFalse
        assertThat(authentication.hasAuthority(ROLE_CUSTOMER)).isFalse
        assertThat(authentication.hasAuthority(ROLE_EMPLOYEE)).isTrue
    }

    @Test
    fun isAuthorised_adGroupString() {
        val httpServletRequest = mockk<HttpServletRequest>()
        every { httpServletRequest.getHeader(EMPLOYEE_AUTHORISATION_HEADER) } returns xAuthEmployee_adGroupString()

        authenticationService.authenticate(httpServletRequest)
        val authentication = SecurityContextHolder.getContext().authentication as PrincipalAuthentication
        val employee = authentication.principal as EmployeePrincipal
        assertThat(employee.name).isEqualTo("Snow, GOT (Jon)")
        assertThat(employee.rabobankId).isEqualTo("1234567890")
        assertThat(employee.organisationId).isEqualTo("3000351915")
        assertThat(authentication.authorities).hasSize(2)
        assertThat(authentication.hasAuthority("ROLE_adfs-role1")).isTrue
        assertThat(authentication.hasAuthority("ROLE_adfs-role2")).isFalse
        assertThat(authentication.hasAuthority(ROLE_CUSTOMER)).isFalse
        assertThat(authentication.hasAuthority(ROLE_EMPLOYEE)).isTrue
    }

    @Test
    fun isAuthorised_adGroupString_withRi() {
        val httpServletRequest = mockk<HttpServletRequest>()

        val xAuthEmployeeToken =
            JwsTestWriter.createJwtToken(
                xAuthEmployeeTokenWithRIFields(System.currentTimeMillis(), System.currentTimeMillis() + 60 * 60 * 1000)
            )
        every { httpServletRequest.getHeader(EMPLOYEE_AUTHORISATION_HEADER) } returns xAuthEmployeeToken

        authenticationService.authenticate(httpServletRequest)
        val authentication = SecurityContextHolder.getContext().authentication as PrincipalAuthentication
        val employee = authentication.principal as EmployeePrincipal
        assertThat(employee.name).isEqualTo("Puk, P (Piet)")
        assertThat(employee.rabobankId).isEqualTo("3000522385")
        assertThat(employee.organisationId).isNull()
        assertThat(authentication.authorities).hasSize(3)
        assertThat(authentication.hasAuthority("ROLE_AAA")).isTrue
        assertThat(authentication.hasAuthority("ROLE_BBB")).isTrue
        assertThat(authentication.hasAuthority("ROLE_CCC")).isFalse
        assertThat(authentication.hasAuthority(ROLE_CUSTOMER)).isFalse
        assertThat(authentication.hasAuthority(ROLE_EMPLOYEE)).isTrue
    }

    private fun xAuthEmployee_adGroupArray(): String {
        val claims: MutableMap<String, Any> = HashMap()
        claims["upn"] = "jon.snow.3000@rabobank.nl"
        claims["unique_name"] = "RABONETEU\\SnowGOT"
        claims["auth_time"] = "2019-03-20T09:35:43.617Z"
        claims[CLAIM_RABOBANK_ID] = "1234567890"
        claims[CLAIM_DISPLAY_NAME] = "Snow, GOT (Jon)"
        claims[CLAIM_RABO_DN] =
            "rabobankid=1234567890,organizationID=3000351915,o=Rabobank,c=NL"
        claims["http://schemas.rabobankinternational.com/identity/claims/raboDepartment"] = "SYS AB CD North"
        val roles = arrayOf("adfs-role1", "adfs-role2")
        claims[CLAIM_ROLE] = roles
        return JwsTestWriter.createJwtToken(claims)
    }

    private fun xAuthEmployee_adGroupString(): String {
        val claims: MutableMap<String, Any> = HashMap()
        claims["upn"] = "jon.snow.3000@rabobank.nl"
        claims["unique_name"] = "RABONETEU\\SnowGOT"
        claims["auth_time"] = "2019-03-20T09:35:43.617Z"
        claims[CLAIM_RABOBANK_ID] = "1234567890"
        claims[CLAIM_DISPLAY_NAME] = "Snow, GOT (Jon)"
        claims[CLAIM_RABO_DN] =
            "rabobankid=1234567890,organizationID=3000351915,o=Rabobank,c=NL"
        claims["http://schemas.rabobankinternational.com/identity/claims/raboDepartment"] = "SYS AB CD North"
        claims["role"] = "adfs-role1"
        return JwsTestWriter.createJwtToken(claims)
    }
}

fun xAuthEmployeeTokenWithRIFields(issuedAt: Long, expiresAt: Long): String {
    return """
        {
          "sub": "12345678",
          "role": [
            "AAA",
            "BBB"
          ],
          "iss": "urn:federation:ri-adfs",
          "sid": "S-1-5-21-1214440339-329068152-725345543-123456",
          "http://schemas.rabobankinternational.com/org/claims/riDepartment": "OPS Beleggen Fnct. Beheer Transacties",
          "http://schemas.rabobankinternational.com/identity/claims/riInitials": "PP",
          "pwd_url": "https://fs.rabobank.com/adfs/portal/updatepassword/",
          "auth_time": "2021-03-26T13:46:37.376Z",
          "exp": $expiresAt,
          "iat": $issuedAt,
          "email": "Piet.Puk@rabobank.nl",
          "jti": "35abc620-bf08-43fc-83b5-e7b0c8b9553e",
          "scp": "openid",
          "ver": "1.0",
          "apptype": "Confidential",
          "given_name": "Piet",
          "aud": "microsoft:identityserver:Employee-Edge-Router employeeapp",
          "upn": "Piet.Puk@rabobank.nl",
          "unique_name": "RABONETEU\\FeberAR",
          "http://schemas.rabobankinternational.com/identity/claims/riDisplayName": "Puk, P (Piet)",
          "appid": "Employee-Edge-Router employeeapp",
          "authmethod": "http://schemas.microsoft.com/ws/2008/06/identity/authenticationmethod/windows",
          "http://schemas.rabobankinternational.com/identity/claims/riRaboID": "3000522385",
          "family_name": "Puk"
        }
        """
}
