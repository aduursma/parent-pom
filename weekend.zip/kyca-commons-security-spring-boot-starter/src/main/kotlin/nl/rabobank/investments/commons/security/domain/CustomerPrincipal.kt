package nl.rabobank.investments.commons.security.domain

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import org.springframework.security.core.AuthenticatedPrincipal
import java.util.ArrayList

@JsonIgnoreProperties(ignoreUnknown = true)
class CustomerPrincipal : AuthenticatedPrincipal {
    var authTicket: String? = null
    var authSessionId: String? = null
    var authUserId: String? = null
    var authUserType: String? = null
    var authUserLevel: String? = null
    var siebelCustomerRelationId: String? = null
    var siebelUserRelationId: String? = null
    var edoKlid: String? = null
    var edoAgreementId: String? = null
    var edoUserId: String? = null
    var sources: List<String> = ArrayList()

    override fun getName(): String {
        return ""
    }
}
