package nl.rabobank.investments.commons.security.domain

data class ValidationResult(
    val isValid: Boolean,
    val reason: String?
)
