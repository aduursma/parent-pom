package nl.rabobank.investments.commons.security.testutil

import com.nimbusds.jose.JOSEException
import com.nimbusds.jose.JWSAlgorithm
import com.nimbusds.jose.JWSHeader
import com.nimbusds.jose.JWSSigner
import com.nimbusds.jose.crypto.RSASSASigner
import com.nimbusds.jwt.JWT
import com.nimbusds.jwt.JWTClaimsSet
import com.nimbusds.jwt.SignedJWT
import nl.rabobank.investments.commons.security.domain.CustomerPrincipal
import org.apache.commons.io.IOUtils
import org.springframework.security.oauth2.jwt.Jwt
import java.security.KeyFactory
import java.security.interfaces.RSAPrivateKey
import java.security.spec.PKCS8EncodedKeySpec
import java.time.ZonedDateTime
import java.util.Base64
import java.util.Date

object JwsTestWriter {
    private const val EXPIRATION_TIME_SIGNATURE = 120
    private const val KEY_ID = "edge-router-v1"
    private var RSA_PRIVATE_KEY: RSAPrivateKey? = null

    fun createJwtTokenForCustomer(relationId: String?): String {
        val claimsSet = JWTClaimsSet.Builder()
            .issueTime(Date())
            .expirationTime(Date.from(ZonedDateTime.now().plusSeconds(EXPIRATION_TIME_SIGNATURE.toLong()).toInstant()))
            .claim("authUserId", "X051873984000001143")
            .claim("authUserType", "CUSTOMER")
            .claim("authUserLevel", "2")
            .claim("authTicket", "23fadf2309aoiijassegg")
            .claim("siebelCustomerRelationId", relationId)
            .claim("siebelUserRelationId", relationId)
            .claim("edoKlid", relationId)
            .claim("edoAgreementId", "000001143")
            .claim("edoUserId", "51873984")
            .claim("sources", listOf("RASS", "TA"))
            .build()
        val signedJWT = createSignedJWT(claimsSet)
        val signer: JWSSigner = RSASSASigner(RSA_PRIVATE_KEY)
        try {
            signedJWT.sign(signer)
        } catch (e: JOSEException) {
            throw IllegalArgumentException(e)
        }
        return signedJWT.serialize()
    }

    fun createJwtToken(claims: Map<String, Any>): String {
        val claimsBuilder = JWTClaimsSet.Builder()
            .issueTime(Date())
            .expirationTime(Date.from(ZonedDateTime.now().plusSeconds(EXPIRATION_TIME_SIGNATURE.toLong()).toInstant()))
        for ((key, value) in claims) {
            claimsBuilder.claim(key, value)
        }
        val signedJWT = createSignedJWT(claimsBuilder.build())
        val signer: JWSSigner = RSASSASigner(RSA_PRIVATE_KEY)
        try {
            signedJWT.sign(signer)
        } catch (e: JOSEException) {
            throw IllegalArgumentException(e)
        }
        return signedJWT.serialize()
    }

    fun createJwtToken(claimsJson: String): String {
        val claimsSet = JWTClaimsSet.parse(claimsJson)
        val signedJWT = createSignedJWT(claimsSet)
        val signer: JWSSigner = RSASSASigner(RSA_PRIVATE_KEY)
        try {
            signedJWT.sign(signer)
        } catch (e: JOSEException) {
            throw IllegalArgumentException(e)
        }
        return signedJWT.serialize()
    }

    fun createJwt(token: String, parsedJwt: JWT): Jwt? {
        val headers: Map<String, Any> = LinkedHashMap(parsedJwt.header.toJSONObject())
        val claims = parsedJwt.jwtClaimsSet.claims
        return Jwt.withTokenValue(token)
            .headers { h: MutableMap<String, Any> ->
                h.putAll(
                    headers
                )
            }
            .claims { c: MutableMap<String?, Any?> ->
                c.putAll(
                    claims.mapValues {
                        if (it.value is Date) {
                            (it.value as Date).toInstant()
                        } else it.value
                    }
                )
            }
            .build()
    }

    fun createJwtToken(customerPrincipal: CustomerPrincipal): String {
        return createSignedJWT(customerPrincipal).serialize()
    }

    private fun createSignedJWT(customerPrincipal: CustomerPrincipal): SignedJWT {
        val claimsSet = JWTClaimsSet.Builder()
            .issueTime(Date())
            .expirationTime(Date.from(ZonedDateTime.now().plusSeconds(EXPIRATION_TIME_SIGNATURE.toLong()).toInstant()))
            .claim("authUserId", customerPrincipal.authUserId)
            .claim("authUserType", customerPrincipal.authUserType)
            .claim("authUserLevel", customerPrincipal.authUserLevel)
            .claim("authTicket", customerPrincipal.authTicket)
            .claim("siebelCustomerRelationId", customerPrincipal.siebelCustomerRelationId)
            .claim("siebelUserRelationId", customerPrincipal.siebelUserRelationId)
            .claim("edoKlid", customerPrincipal.edoKlid)
            .claim("edoAgreementId", customerPrincipal.edoAgreementId)
            .claim("edoUserId", customerPrincipal.edoUserId)
            .claim("sources", customerPrincipal.sources)
            .build()
        val signedJWT = createSignedJWT(claimsSet)
        val signer: JWSSigner = RSASSASigner(RSA_PRIVATE_KEY)
        try {
            signedJWT.sign(signer)
        } catch (e: JOSEException) {
            throw IllegalArgumentException(e)
        }
        return signedJWT
    }

    private fun createSignedJWT(jwtClaimsSet: JWTClaimsSet): SignedJWT {
        return SignedJWT(
            JWSHeader.Builder(JWSAlgorithm.RS512)
                .keyID(KEY_ID)
                .build(),
            jwtClaimsSet
        )
    }

    init {
        val keyBytes = Base64.getDecoder().decode(IOUtils.resourceToByteArray("/edge-router-stub-private-key"))
        val spec = PKCS8EncodedKeySpec(keyBytes)
        val kf = KeyFactory.getInstance("RSA")
        RSA_PRIVATE_KEY = kf.generatePrivate(spec) as RSAPrivateKey
    }
}
