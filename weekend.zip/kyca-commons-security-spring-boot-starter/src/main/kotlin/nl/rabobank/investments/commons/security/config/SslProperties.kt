package nl.rabobank.investments.commons.security.config

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.boot.context.properties.ConstructorBinding

@ConstructorBinding
@ConfigurationProperties(prefix = "ssl")
data class SslProperties(
    val keystoreBase64: String,
    val keystorePassword: String,
    val truststoreBase64: String,
    val truststorePassword: String
)
