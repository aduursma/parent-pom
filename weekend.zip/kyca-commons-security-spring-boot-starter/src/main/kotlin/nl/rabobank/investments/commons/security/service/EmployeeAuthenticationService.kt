package nl.rabobank.investments.commons.security.service

import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.EMPLOYEE_AUTHORISATION_HEADER
import nl.rabobank.investments.commons.security.converter.EmployeeAuthenticationConverter
import org.apache.commons.lang3.StringUtils
import org.slf4j.LoggerFactory
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.oauth2.jwt.JwtDecoder
import org.springframework.security.oauth2.jwt.JwtException
import org.springframework.stereotype.Service
import javax.servlet.http.HttpServletRequest

@Service
class EmployeeAuthenticationService(
    private val employeeJwtDecoder: JwtDecoder,
    private val employeeAuthenticationConverter: EmployeeAuthenticationConverter
) : AuthenticationService {

    private val log = LoggerFactory.getLogger(javaClass)

    override fun canAuthenticate(httpServletRequest: HttpServletRequest): Boolean {
        return !StringUtils.isEmpty(httpServletRequest.getHeader(EMPLOYEE_AUTHORISATION_HEADER))
    }

    override fun authenticate(httpServletRequest: HttpServletRequest) {
        try {
            val jwtToken = getEncryptedToken(httpServletRequest)
            if (jwtToken.isNullOrBlank()) {
                return
            }

            val authentication = employeeAuthenticationConverter.convert(employeeJwtDecoder.decode(jwtToken))
            if (authentication.isAuthenticated) {
                SecurityContextHolder.getContext().authentication = authentication
            }
            if (log.isDebugEnabled) {
                log.debug("Parsed x-auth-employee token, employee: {}", authentication.principal.toString())
                log.debug("Employee authorities: {}", authentication.authorities)
            }
        } catch (e: JwtException) {
            log.error(e.message, e)
        }
    }

    private fun getEncryptedToken(request: HttpServletRequest): String? {
        val token = request.getHeader(EMPLOYEE_AUTHORISATION_HEADER)
        if (token == null) {
            log.warn("The required HTTP header '{}' is missing", EMPLOYEE_AUTHORISATION_HEADER)
        }
        return token
    }
}
