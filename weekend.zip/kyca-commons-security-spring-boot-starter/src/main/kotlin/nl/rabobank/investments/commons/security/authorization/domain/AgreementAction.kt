package nl.rabobank.investments.commons.security.authorization.domain

enum class AgreementAction {
    VIEW,
    EDIT,
    DISCONTINUE,
    VIEW_KEC,
    EDIT_KEC
}
