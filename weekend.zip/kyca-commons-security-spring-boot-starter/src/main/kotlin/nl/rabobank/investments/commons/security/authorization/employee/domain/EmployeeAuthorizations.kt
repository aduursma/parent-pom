package nl.rabobank.investments.commons.security.authorization.employee.domain

enum class EmployeeAuthorizations(val role: String) {
    AGREEMENTS_VIEW_PB("InvsalesmedPBAGRMENTSVIEW"),
    AGREEMENTS_EDIT_PB("InvsalesmedPBAGRMENTSEDIT"),
    AGREEMENTS_DISCONTINUE_PB("InvsaleshighPBAGRMENTSDISCN"),

    TRADING_BLOCK_VIEW_PB("InvsalesmedPBTRADBLOCKVIEW"),
    TRADING_BLOCK_EDIT_PB("InvsalesmedPBTRADBLOCKEDIT"),

    KEC_VIEW_PB("InvsalesmedPBKECVIEW"),
    KEC_EDIT_PB("InvsalesmedPBKECEDIT"),

    AGREEMENTS_VIEW_NPB("InvsalesmedNPBAGRMENTSVIEW"),
    AGREEMENTS_EDIT_NPB("InvsalesmedNPBAGRMENTSEDIT"),
    AGREEMENTS_DISCONTINUE_NPB("InvsaleshighNPBAGRMENTSDISCN"),

    TRADING_BLOCK_VIEW_NPB("InvsalesmedNPBTRADBLOCKVIEW"),
    TRADING_BLOCK_EDIT_NPB("InvsalesmedNPBTRADBLOCKEDIT"),

    KEC_VIEW_NPB("InvsalesmedNPBKECVIEW"),
    KEC_EDIT_NPB("InvsalesmedNPBKECEDIT"),
    VERIFY("InvsalesmedVerify")
}
