package nl.rabobank.investments.commons.security.domain

object Role {
    const val APPLICATION = "APPLICATION"
    const val EMPLOYEE = "EMPLOYEE"
    const val CUSTOMER = "CUSTOMER"
}
