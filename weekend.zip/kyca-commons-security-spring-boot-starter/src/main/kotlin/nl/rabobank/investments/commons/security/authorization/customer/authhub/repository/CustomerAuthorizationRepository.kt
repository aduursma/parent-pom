package nl.rabobank.investments.commons.security.authorization.customer.authhub.repository

import nl.rabobank.authorisationhub.users.api.client.AHUsersAPIClient
import nl.rabobank.investments.commons.security.authorization.customer.authhub.domain.Arrangement
import nl.rabobank.investments.commons.security.authorization.customer.authhub.domain.Authorization
import nl.rabobank.investments.commons.security.domain.CustomerPrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import org.slf4j.LoggerFactory
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Repository
import org.springframework.web.server.ResponseStatusException

@Repository
class CustomerAuthorizationRepository(
    private val ahUsersAPIClient: AHUsersAPIClient
) {

    private val log = LoggerFactory.getLogger(javaClass)

    /**
     * If role is CUSTOMER then returns its Authorization else throw Forbidden exception
     */
    fun userCustomerAuthorization(authentication: PrincipalAuthentication): Authorization {
        if (authentication.hasRole("CUSTOMER")) {
            val customerPrincipal = authentication.principal as CustomerPrincipal
            val xAuthUser = authentication.credentials as String
            val customer = ahUsersAPIClient.getUserCustomerAuthorisations(
                customerPrincipal.siebelUserRelationId,
                customerPrincipal.siebelCustomerRelationId,
                xAuthUser,
                null
            )
            return Authorization(
                sessionId = customerPrincipal.authSessionId,
                arrangements = translateArrangements(customer.arrangementsList),
                authorizations = customer.authorisationsList,
                relationId = customerPrincipal.siebelCustomerRelationId,
                distributionAgreementId = customerPrincipal.edoAgreementId?.toInt(),
                edoUserId = customerPrincipal.edoUserId,
                authorizedUserId = customerPrincipal.authUserId
            )
        } else {
            log.error("Authorization retrieval request received but user is not Customer: ${authentication.principal} ")
            throw ResponseStatusException(HttpStatus.FORBIDDEN, "User  is not CUSTOMER")
        }
    }

    fun userAuthorization(authentication: PrincipalAuthentication): Authorization {
        if (authentication.hasRole("CUSTOMER")) {
            val customerPrincipal = authentication.principal as CustomerPrincipal
            val xAuthUser = authentication.credentials as String
            val userAuthorisations =
                ahUsersAPIClient.getUserAuthorisations(customerPrincipal.siebelUserRelationId, xAuthUser, null)
            val authorizationsForCustomer = userAuthorisations?.customersList
                ?.filter { cust -> cust.id == customerPrincipal.siebelCustomerRelationId }
                ?.map { cust -> cust.authorisationsList }?.flatten().orEmpty()

            val allArrangements =
                userAuthorisations?.customersList?.mapNotNull { cust -> cust.arrangementsList }?.flatten().orEmpty()
            return Authorization(
                sessionId = customerPrincipal.authSessionId,
                arrangements = translateArrangements(allArrangements),
                authorizations = authorizationsForCustomer,
                relationId = customerPrincipal.siebelCustomerRelationId,
                distributionAgreementId = customerPrincipal.edoAgreementId?.toInt(),
                edoUserId = customerPrincipal.edoUserId,
                authorizedUserId = customerPrincipal.authUserId
            )
        } else {
            log.error("Authorization retrieval request received but user is not Customer: ${authentication.principal} ")
            throw ResponseStatusException(HttpStatus.FORBIDDEN, "User  is not CUSTOMER")
        }
    }

    private fun translateArrangements(
        arrangements: List<nl.rabobank.authorisationhub.users.api.model.Arrangement>
    ): Collection<Arrangement> {
        return arrangements.map { arrangement: nl.rabobank.authorisationhub.users.api.model.Arrangement ->
            Arrangement(
                number = arrangement.number,
                administrationCode = arrangement.administrationCode,
                authorizations = arrangement.authorisationsList
            )
        }
    }
}
