package nl.rabobank.investments.commons.security.authorization.employee.service

import nl.rabobank.investments.commons.agreement.domain.AgreementAuthorization
import nl.rabobank.investments.commons.agreement.domain.ProductCode
import nl.rabobank.investments.commons.agreement.repository.AgreementRepository
import nl.rabobank.investments.commons.ff.util.SplitUtils
import nl.rabobank.investments.commons.security.authorization.employee.domain.EmployeeAuthorizations
import nl.rabobank.investments.commons.security.domain.EmployeePrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.domain.ValidationResult
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Service
import org.springframework.web.server.ResponseStatusException

val ADVISED_PRODUCTS = listOf(
    ProductCode.IVB, ProductCode.IVB2, ProductCode.RAB, ProductCode.RBBE
)

@Service
class EmployeeAuthorizationService(
    private val agreementRepository: AgreementRepository,
    @Autowired(required = false) private val splitUtils: SplitUtils?
) {

    fun checkAuthorizations(
        authorization: AgreementAuthorization,
        investmentArrangementNumber: String,
        principalAuthentication: PrincipalAuthentication,
        useActive: Boolean = false
    ): ValidationResult {

        if (principalAuthentication.principal !is EmployeePrincipal)
            throw ResponseStatusException(HttpStatus.FORBIDDEN, "Logged in user is not EMPLOYEE")
        if (principalAuthentication.hasRole(EmployeeAuthorizations.VERIFY.role) ||
            principalAuthentication.hasAuthority(EmployeeAuthorizations.VERIFY.role)
        ) {
            return canVerify(principalAuthentication.name, authorization, investmentArrangementNumber)
        }
        val productType = agreementRepository.getProductType(investmentArrangementNumber, useActive)
        val advisedProduct = isAdvisedProduct(productType)

        return when (authorization) { // if not EmployeeAuthorizations.VERIFY
            AgreementAuthorization.VIEW_AGREEMENT -> isAuthorized(
                advisedProduct, EmployeeAuthorizations.AGREEMENTS_VIEW_PB,
                EmployeeAuthorizations.AGREEMENTS_VIEW_NPB, principalAuthentication
            )
            AgreementAuthorization.EDIT_AGREEMENT -> isAuthorized(
                advisedProduct, EmployeeAuthorizations.AGREEMENTS_EDIT_PB,
                EmployeeAuthorizations.AGREEMENTS_EDIT_NPB, principalAuthentication
            )
            AgreementAuthorization.DISCONTINUE_AGREEMENT -> isAuthorized(
                advisedProduct, EmployeeAuthorizations.AGREEMENTS_DISCONTINUE_PB,
                EmployeeAuthorizations.AGREEMENTS_DISCONTINUE_NPB, principalAuthentication
            )
            AgreementAuthorization.VIEW_KEC -> isAuthorized(
                advisedProduct, EmployeeAuthorizations.KEC_VIEW_PB,
                EmployeeAuthorizations.KEC_VIEW_NPB, principalAuthentication
            )
            AgreementAuthorization.EDIT_KEC -> isAuthorized(
                advisedProduct, EmployeeAuthorizations.KEC_EDIT_PB,
                EmployeeAuthorizations.KEC_EDIT_NPB, principalAuthentication
            )
            AgreementAuthorization.VIEW_TRADING_BLOCK -> isAuthorized(
                advisedProduct, EmployeeAuthorizations.TRADING_BLOCK_VIEW_PB,
                EmployeeAuthorizations.TRADING_BLOCK_VIEW_NPB, principalAuthentication
            )
            AgreementAuthorization.EDIT_TRADING_BLOCK -> isAuthorized(
                advisedProduct, EmployeeAuthorizations.TRADING_BLOCK_EDIT_PB,
                EmployeeAuthorizations.TRADING_BLOCK_EDIT_NPB, principalAuthentication
            )
            else ->
                ValidationResult(false, "Role not implemented: $authorization")
        }
    }

    private val isAuthorized = { advisedProduct: Boolean,
        advisedAuthorization: EmployeeAuthorizations,
        nonAdvisedAuthorization: EmployeeAuthorizations,
        authentication: PrincipalAuthentication ->
        if (advisedProduct)
            ValidationResult(
                authentication.hasRole(advisedAuthorization.role) ||
                    authentication.hasAuthority(advisedAuthorization.role),
                "Employee Authorization for role: ${advisedAuthorization.role}"
            )
        else
            ValidationResult(
                authentication.hasRole(nonAdvisedAuthorization.role) ||
                    authentication.hasAuthority(nonAdvisedAuthorization.role),
                "Employee Authorization for role: ${nonAdvisedAuthorization.role}"
            )
    }

    private val canVerify = { userLoginName: String,
        authorization: AgreementAuthorization,
        investmentArrangementNumber: String ->
        val isVerificationAllowed = when (authorization) {
            AgreementAuthorization.DISCONTINUE_AGREEMENT -> {
                splitUtils?.investmentSales332VerificationAllowed(userLoginName, investmentArrangementNumber)
            }
            else -> {
                splitUtils?.investmentSales322VerificationAllowed(userLoginName, investmentArrangementNumber)
            }
        }
        ValidationResult(
            isVerificationAllowed ?: false,
            "Employee Authorization for role: ${EmployeeAuthorizations.VERIFY.role}"
        )
    }

    private fun isAdvisedProduct(productType: ProductCode) = ADVISED_PRODUCTS.contains(productType)
}
