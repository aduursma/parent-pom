package nl.rabobank.investments.commons.security.autoconfigure

import org.springframework.boot.autoconfigure.AutoConfiguration
import org.springframework.context.annotation.ComponentScan

@AutoConfiguration
@ComponentScan(value = ["nl.rabobank.investments.commons.security", "nl.rabobank.authorisationhub.users.api.client"])
class SecurityAutoConfiguration
