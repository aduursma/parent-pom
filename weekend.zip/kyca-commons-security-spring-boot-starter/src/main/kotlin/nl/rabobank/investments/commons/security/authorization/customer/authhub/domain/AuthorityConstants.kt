package nl.rabobank.investments.commons.security.authorization.customer.authhub.domain

object AuthorityConstants {
    const val CUSTOMER_AUTHORIZATION_GN_READ = "GN_READ"
    const val CUSTOMER_AUTHORIZATION_GN_MODIFY = "GN_CHANGE"
    const val CUSTOMER_AUTHORIZATION_CH_EF_01 = "CH_EF_01"
}
