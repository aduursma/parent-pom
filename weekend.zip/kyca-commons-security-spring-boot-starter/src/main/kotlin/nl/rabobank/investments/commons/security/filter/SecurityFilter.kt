package nl.rabobank.investments.commons.security.filter

import nl.rabobank.investments.commons.security.service.AppAuthenticationService
import nl.rabobank.investments.commons.security.service.CustomerAuthenticationService
import nl.rabobank.investments.commons.security.service.EmployeeAuthenticationService
import org.springframework.stereotype.Component
import org.springframework.web.filter.OncePerRequestFilter
import java.io.IOException
import javax.servlet.FilterChain
import javax.servlet.ServletException
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse

@Component
class SecurityFilter(
    val employeeAuthenticationService: EmployeeAuthenticationService,
    val customerAuthenticationService: CustomerAuthenticationService,
    val appAuthenticationService: AppAuthenticationService
) : OncePerRequestFilter() {

    @Throws(IOException::class, ServletException::class)
    public override fun doFilterInternal(
        request: HttpServletRequest,
        response: HttpServletResponse,
        filterChain: FilterChain
    ) {
        val authenticationServices = listOf(
            employeeAuthenticationService,
            customerAuthenticationService,
            appAuthenticationService
        )
        authenticationServices.find { it.canAuthenticate(request) }?.authenticate(request)
        filterChain.doFilter(request, response)
    }
}
