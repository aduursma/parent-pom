package nl.rabobank.investments.commons.security.util

import org.springframework.core.io.ClassPathResource
import java.io.ByteArrayInputStream
import java.io.IOException
import java.security.KeyStore
import java.security.KeyStoreException
import java.security.NoSuchAlgorithmException
import java.security.cert.CertificateException
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.util.Base64

object CertificateUtil {

    @Throws(CertificateException::class)
    fun certificateFromBytes(certificateBytes: ByteArray): X509Certificate {
        val certificateFactory = CertificateFactory.getInstance("X.509")
        return certificateFactory.generateCertificate(ByteArrayInputStream(certificateBytes)) as X509Certificate
    }

    @Throws(IOException::class, KeyStoreException::class, NoSuchAlgorithmException::class, CertificateException::class)
    fun getCertificateBase64(keyStoreFile: String, keyStorePassword: String, alias: String): String {
        val certificate = getCertificate(keyStoreFile, keyStorePassword, alias)
        return Base64.getEncoder().encodeToString(certificate.encoded)
    }

    @Throws(IOException::class, KeyStoreException::class, NoSuchAlgorithmException::class, CertificateException::class)
    fun getCertificate(keyStoreFile: String, keyStorePassword: String, alias: String): X509Certificate {
        val keyStore = KeyStore.getInstance("JKS")
        ClassPathResource(keyStoreFile).inputStream.use { keyStore.load(it, keyStorePassword.toCharArray()) }
        return keyStore.getCertificate(alias) as X509Certificate
    }
}
