package nl.rabobank.investments.commons.security.authorization.customer.authhub.domain

data class Authorization(
    val sessionId: String?,
    val relationId: String?,
    val authorizedUserId: String?,
    val distributionAgreementId: Int?,
    val edoUserId: String?,
    val authorizations: Collection<String>,
    val arrangements: Collection<Arrangement>
)
