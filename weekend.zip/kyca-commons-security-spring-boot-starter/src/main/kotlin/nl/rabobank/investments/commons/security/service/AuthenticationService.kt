package nl.rabobank.investments.commons.security.service

import javax.servlet.http.HttpServletRequest

interface AuthenticationService {
    fun canAuthenticate(httpServletRequest: HttpServletRequest): Boolean
    fun authenticate(httpServletRequest: HttpServletRequest)
}
