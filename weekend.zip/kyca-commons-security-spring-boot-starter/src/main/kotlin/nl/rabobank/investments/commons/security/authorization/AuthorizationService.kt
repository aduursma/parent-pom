package nl.rabobank.investments.commons.security.authorization

import nl.rabobank.investments.commons.agreement.domain.AgreementAuthorization
import nl.rabobank.investments.commons.security.authorization.customer.agreement.service.CustomerAgreementAuthorizationService
import nl.rabobank.investments.commons.security.authorization.customer.authhub.service.CustomerAuthorizationHubService
import nl.rabobank.investments.commons.security.authorization.employee.service.EmployeeAuthorizationService
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.domain.Role
import nl.rabobank.investments.commons.security.domain.ValidationResult
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.stereotype.Service

@Service
class AuthorizationService(
    private val employeeAuthorizationService: EmployeeAuthorizationService,
    private val customerAuthorizationHubService: CustomerAuthorizationHubService,
    private val customerAgreementAuthorizationService: CustomerAgreementAuthorizationService
) {

    fun checkAuthorizations(
        investmentArrangementNumber: String,
        authorization: AgreementAuthorization,
        useActive: Boolean = false
    ): ValidationResult {
        val authentication = SecurityContextHolder.getContext().authentication as PrincipalAuthentication
        return if (authentication.isAuthenticated) {
            when {
                authentication.hasRole(Role.CUSTOMER) -> checkAuthorizationsForCustomer(
                    authorization, investmentArrangementNumber, authentication
                )
                authentication.hasRole(Role.EMPLOYEE) ->
                    employeeAuthorizationService.checkAuthorizations(
                        authorization, investmentArrangementNumber, authentication, useActive
                    )

                authentication.hasRole(Role.APPLICATION) -> ValidationResult(
                    isValid = true,
                    reason = "APPLICATION role is authorized"
                )

                else -> ValidationResult(
                    isValid = false,
                    reason = "No Valid CUSTOMER, EMPLOYEE and APPLICATION role for checking authorization of the user"
                )
            }
        } else {
            ValidationResult(false, "User is not authenticated")
        }
    }

    private fun checkAuthorizationsForCustomer(
        authorization: AgreementAuthorization,
        investmentArrangementNumber: String,
        authentication: PrincipalAuthentication
    ): ValidationResult {
        return when (authorization) {
            AgreementAuthorization.VIEW_KEC, AgreementAuthorization.EDIT_KEC ->
                customerAuthorizationHubService.checkAuthorizations(
                    authorization, investmentArrangementNumber, authentication
                )
            else -> {
                customerAgreementAuthorizationService.checkAuthorizations(
                    authorization, investmentArrangementNumber, authentication
                )
            }
        }
    }
}
