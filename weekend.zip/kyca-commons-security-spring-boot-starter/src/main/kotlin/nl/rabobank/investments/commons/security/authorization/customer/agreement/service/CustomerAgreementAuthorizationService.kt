package nl.rabobank.investments.commons.security.authorization.customer.agreement.service

import nl.rabobank.investments.commons.agreement.domain.AgreementAuthorization
import nl.rabobank.investments.commons.agreement.repository.AgreementRepository
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.domain.ValidationResult
import org.springframework.stereotype.Service

@Service
class CustomerAgreementAuthorizationService(
    private val agreementRepository: AgreementRepository
) {

    fun checkAuthorizations(
        authorization: AgreementAuthorization,
        investmentArrangementNumber: String,
        authentication: PrincipalAuthentication
    ): ValidationResult {
        val authorizations = agreementRepository.getCustomerAuthorizations(
            investmentArrangementNumber, authentication.credentials!!.toString()
        )
        return ValidationResult(
            authorizations.contains(authorization),
            "Customer authorization: $authorization"
        )
    }
}
