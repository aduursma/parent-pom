package nl.rabobank.investments.commons.security.converter

import brave.Tracer
import com.fasterxml.jackson.databind.ObjectMapper
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.USER_TYPE_CUSTOMER
import nl.rabobank.investments.commons.security.domain.CustomerPrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.domain.Role
import nl.rabobank.investments.commons.security.util.LoggingUtil
import org.springframework.core.convert.converter.Converter
import org.springframework.security.authentication.AbstractAuthenticationToken
import org.springframework.security.oauth2.jwt.Jwt

class CustomerAuthenticationConverter(
    val objectMapper: ObjectMapper,
    val tracer: Tracer
) : Converter<Jwt, AbstractAuthenticationToken> {

    override fun convert(source: Jwt): AbstractAuthenticationToken? {
        val customerPrincipal = objectMapper.convertValue(source.claims, CustomerPrincipal::class.java)
        if (USER_TYPE_CUSTOMER != customerPrincipal.authUserType) {
            return null
        }
        addTraceLogging(customerPrincipal)
        return PrincipalAuthentication(source.tokenValue, customerPrincipal, Role.CUSTOMER).apply {
            isAuthenticated = true
        }
    }

    private fun addTraceLogging(customerPrincipal: CustomerPrincipal) {
        val extraFields: MutableMap<String, String> = HashMap()
        extraFields["auth_user_id"] = customerPrincipal.authUserId ?: ""
        extraFields["auth_user_type"] = customerPrincipal.authUserType ?: ""
        extraFields["auth_user_level"] = customerPrincipal.authUserLevel ?: ""
        extraFields["siebel_customer_relation_id"] = customerPrincipal.siebelCustomerRelationId ?: ""
        extraFields["siebel_user_relation_id"] = customerPrincipal.siebelUserRelationId ?: ""
        extraFields["edo_klid"] = customerPrincipal.edoKlid ?: ""
        LoggingUtil.addTraceLogging(tracer, extraFields)
    }
}
