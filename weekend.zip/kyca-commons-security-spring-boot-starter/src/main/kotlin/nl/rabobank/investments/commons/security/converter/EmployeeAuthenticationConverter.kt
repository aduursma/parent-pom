package nl.rabobank.investments.commons.security.converter

import brave.Tracer
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_APPLICATION_PROFILE
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_DISPLAY_NAME
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_EMPLOYEE_UNIQUE_NAME
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_RABOBANK_ID
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_RABO_DN
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_RI_DISPLAY_NAME
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLAIM_ROLE
import nl.rabobank.investments.commons.security.domain.EmployeePrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.domain.Role
import nl.rabobank.investments.commons.security.util.LoggingUtil
import org.apache.commons.lang3.StringUtils
import org.slf4j.LoggerFactory
import org.springframework.core.convert.converter.Converter
import org.springframework.security.authentication.AbstractAuthenticationToken
import org.springframework.security.oauth2.jwt.Jwt
import java.util.stream.Collectors

const val RABODN_ORGANIZATIONID = "organizationID"
const val RWA_FUNCTION_INDEX = 1

class EmployeeAuthenticationConverter(val tracer: Tracer) : Converter<Jwt, AbstractAuthenticationToken> {
    private val log = LoggerFactory.getLogger(javaClass)

    override fun convert(source: Jwt): AbstractAuthenticationToken {
        val authentication = mapClaimsToAuthentication(source.tokenValue, source.claims).apply {
            isAuthenticated = true
        }
        addTraceLogging(authentication.principal as EmployeePrincipal)
        return authentication
    }

    private fun mapClaimsToAuthentication(jwtToken: String?, claims: Map<String, Any>): PrincipalAuthentication {
        val rwaFunctions: MutableList<String?> = ArrayList()
        val employeePrincipal = EmployeePrincipal()
        employeePrincipal.employeePrincipalName = getDisplayName(claims)
        employeePrincipal.rabobankId = getRaboID(claims)
        employeePrincipal.employeeUniqueName = claims[CLAIM_EMPLOYEE_UNIQUE_NAME] as String?
        val raboDNObject = claims[CLAIM_RABO_DN]
        if (raboDNObject != null) {
            val raboDN = (raboDNObject as String).split(",")
                .stream()
                .map { kv: String -> kv.split("=").toTypedArray() }
                .collect(
                    Collectors.toMap(
                        { kv: Array<String> -> kv[0] },
                        { kv: Array<String> -> kv[1] },
                        { d1: String, _: String? -> d1 }
                    )
                )
            employeePrincipal.organisationId = raboDN[RABODN_ORGANIZATIONID]
        }
        val rwaFunctionClaim = claims[CLAIM_APPLICATION_PROFILE]
        if (rwaFunctionClaim != null) {
            val claimElements = getClaimElements(claims, CLAIM_APPLICATION_PROFILE)
            claimElements.forEach {
                val rwaProperties = StringUtils.split(it, ";")
                rwaFunctions.add("ROLE_${rwaProperties[RWA_FUNCTION_INDEX]}")
            }
        } else {
            val claimElements = getClaimElements(claims, CLAIM_ROLE)
            claimElements.forEach {
                rwaFunctions.add("ROLE_$it")
            }
        }
        return PrincipalAuthentication(jwtToken!!, employeePrincipal, Role.EMPLOYEE, rwaFunctions)
    }

    private fun getDisplayName(claims: Map<String, Any>): String? {
        return (claims[CLAIM_DISPLAY_NAME] ?: claims[CLAIM_RI_DISPLAY_NAME]) as String?
    }

    private fun getRaboID(claims: Map<String, Any>): String? {
        return claims[CLAIM_RABOBANK_ID] as String?
    }

    private fun getClaimElements(claims: Map<String, Any>, claimName: String): List<String> {
        return when (claims[claimName]) {
            null -> emptyList()
            is String -> listOf(claims[claimName] as String)
            else -> claims[claimName] as List<String>
        }
    }

    private fun addTraceLogging(employeePrincipal: EmployeePrincipal) {
        log.debug("Adding RWA trace logging")
        val extraFields = mutableMapOf<String, String>()
        extraFields["organisation_id"] = employeePrincipal.organisationId ?: ""
        extraFields["rabo_id"] = employeePrincipal.rabobankId ?: ""
        LoggingUtil.addTraceLogging(tracer, extraFields)
    }
}
