package nl.rabobank.investments.commons.security.service

import brave.Tracer
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CLIENT_CERTIFICATE_HEADER
import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.USER_TYPE_APPLICATION
import nl.rabobank.investments.commons.security.domain.ApplicationPrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.util.CertificateUtil.certificateFromBytes
import nl.rabobank.investments.commons.security.util.LoggingUtil.addTraceLogging
import org.apache.commons.lang3.StringUtils
import org.slf4j.LoggerFactory
import org.springframework.core.env.Environment
import org.springframework.security.core.AuthenticationException
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.stereotype.Service
import java.security.cert.CertificateException
import java.util.stream.Collectors
import javax.servlet.http.HttpServletRequest

private const val INVALID_CERTIFICATE =
    "Client certificate provided has an invalid format and cannot be used. Issue: {}"

@Service
class AppAuthenticationService(
    val tracer: Tracer,
    val environment: Environment
) : AuthenticationService {
    private val log = LoggerFactory.getLogger(javaClass)

    private val certificateBegin = "-----BEGIN CERTIFICATE-----" + System.lineSeparator()
    private val certificateEnd = System.lineSeparator() + "-----END CERTIFICATE-----"

    override fun canAuthenticate(httpServletRequest: HttpServletRequest): Boolean {
        return !StringUtils.isEmpty(httpServletRequest.getHeader(CLIENT_CERTIFICATE_HEADER))
    }

    override fun authenticate(httpServletRequest: HttpServletRequest) {
        try {
            var clientCertificateStr = httpServletRequest.getHeader(CLIENT_CERTIFICATE_HEADER)
            if (clientCertificateStr.isNullOrBlank()) {
                return
            }
            clientCertificateStr = "$certificateBegin$clientCertificateStr$certificateEnd"
            val clientCertificate = certificateFromBytes(clientCertificateStr.toByteArray())
            val commonName = getCommonName(clientCertificate.subjectX500Principal.name)
            val issuerDistinguishedName = clientCertificate.issuerDN.name
            val authorities = getAuthorities(commonName)

            if (log.isDebugEnabled) {
                log.debug("Common name: $commonName, authorities: ${authorities.joinToString()}")
            }

            if (!issuerDistinguishedName.contains("rabobank", true)) {
                log.error("Certificate not issued by Rabobank!")
                return
            }

            // The token is valid and the user is an allowed application.
            val applicationPrincipal = ApplicationPrincipal(commonName)
            val authentication = PrincipalAuthentication(
                null, applicationPrincipal,
                USER_TYPE_APPLICATION, authorities
            )
            authentication.isAuthenticated = true
            SecurityContextHolder.getContext().authentication = authentication
            addTraceLogging(tracer, authentication.principal as ApplicationPrincipal)
        } catch (e: AuthenticationException) {
            log.error(INVALID_CERTIFICATE, e.javaClass.simpleName, e)
        } catch (e: CertificateException) {
            log.error(INVALID_CERTIFICATE, e.javaClass.simpleName, e)
        } catch (e: IllegalArgumentException) {
            log.error(INVALID_CERTIFICATE, e.javaClass.simpleName, e)
        }
    }

    private fun getCommonName(name: String): String {
        return StringUtils.substringBetween(name, "CN=", ",")
    }

    private fun getAuthorities(commonName: String): Collection<String?> {
        val authoritiesStr = environment.getProperty("application.authorities.$commonName")
        return if (StringUtils.isNotEmpty(authoritiesStr)) {
            val authorities = authoritiesStr!!.split(",")
            authorities.stream().map { a: String -> "ROLE_$a" }.collect(Collectors.toUnmodifiableList())
        } else {
            ArrayList()
        }
    }
}
