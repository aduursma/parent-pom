package nl.rabobank.investments.commons.security.util

import brave.Tracer
import brave.baggage.BaggageField
import nl.rabobank.investments.commons.security.domain.ApplicationPrincipal
import org.slf4j.MDC
import java.util.Objects

object LoggingUtil {

    fun addTraceLogging(tracer: Tracer, extraFields: MutableMap<String, String>) {
        val span = tracer.currentSpan()
        extraFields.forEach { (key: String?, value: String?) ->
            span.tag(key, value)
            BaggageField.getByName(span.context(), key)?.updateValue(value)
            MDC.put(key, value)
        }
    }

    fun addTraceLogging(tracer: Tracer, applicationPrincipal: ApplicationPrincipal) {
        val extraFields: MutableMap<String, String> = HashMap()
        extraFields["name"] = Objects.toString(applicationPrincipal.name, org.apache.logging.log4j.util.Strings.EMPTY)
        addTraceLogging(tracer, extraFields)
    }
}
