package nl.rabobank.investments.commons.security.config

import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import java.io.ByteArrayInputStream
import java.security.KeyStore
import java.security.PrivateKey
import java.security.cert.X509Certificate
import java.util.Base64

@Configuration
@EnableConfigurationProperties(value = [SslProperties::class])
class SecurityConfig(private val sslProperties: SslProperties) {

    @Bean
    fun keyStore(): KeyStore {
        return KeyStore.getInstance("jks").apply {
            val keyStoreBytes = Base64.getDecoder().decode(sslProperties.keystoreBase64)
            load(ByteArrayInputStream(keyStoreBytes), sslProperties.keystorePassword.toCharArray())
        }
    }

    @Bean
    fun trustStore(): KeyStore {
        return KeyStore.getInstance("jks").apply {
            val trustStoreBytes = Base64.getDecoder().decode(sslProperties.truststoreBase64)
            load(ByteArrayInputStream(trustStoreBytes), sslProperties.truststorePassword.toCharArray())
        }
    }

    @Bean
    fun privateKey(keyStore: KeyStore): PrivateKey {
        val firstAlias = keyStore.aliases().nextElement()
        return keyStore.getKey(firstAlias, sslProperties.keystorePassword.toCharArray()) as PrivateKey
    }

    @Bean
    fun certificate(keyStore: KeyStore): X509Certificate {
        val firstAlias = keyStore.aliases().nextElement()
        return keyStore.getCertificate(firstAlias) as X509Certificate
    }
}
