package nl.rabobank.investments.commons.security.domain

enum class CustomerType {
    NATURAL_PERSON,
    ORGANISATION
}
