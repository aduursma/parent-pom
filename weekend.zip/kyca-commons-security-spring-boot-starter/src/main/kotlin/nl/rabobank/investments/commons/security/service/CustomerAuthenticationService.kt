package nl.rabobank.investments.commons.security.service

import nl.rabobank.investments.commons.security.constants.AuthenticationConstants.CUSTOMER_AUTHORISATION_HEADER
import nl.rabobank.investments.commons.security.converter.CustomerAuthenticationConverter
import org.apache.commons.lang3.StringUtils
import org.slf4j.LoggerFactory
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.oauth2.jwt.JwtDecoder
import org.springframework.security.oauth2.jwt.JwtException
import org.springframework.stereotype.Service
import javax.servlet.http.HttpServletRequest

@Service
class CustomerAuthenticationService(
    private val customerJwtDecoder: JwtDecoder,
    private val customerAuthenticationConverter: CustomerAuthenticationConverter
) : AuthenticationService {

    private val log = LoggerFactory.getLogger(javaClass)

    override fun canAuthenticate(httpServletRequest: HttpServletRequest): Boolean {
        return !StringUtils.isEmpty(httpServletRequest.getHeader(CUSTOMER_AUTHORISATION_HEADER))
    }

    override fun authenticate(httpServletRequest: HttpServletRequest) {
        try {
            val encryptedToken = getEncryptedToken(httpServletRequest)
            if (encryptedToken.isNullOrBlank()) {
                return
            }

            val authentication = customerAuthenticationConverter.convert(customerJwtDecoder.decode(encryptedToken))
            if (authentication != null && authentication.isAuthenticated) {
                SecurityContextHolder.getContext().authentication = authentication
            }
        } catch (e: JwtException) {
            log.error(e.message, e)
        }
    }

    private fun getEncryptedToken(request: HttpServletRequest): String? {
        val token = request.getHeader(CUSTOMER_AUTHORISATION_HEADER)
        if (token == null) {
            log.warn("The required HTTP header '{}' is missing", CUSTOMER_AUTHORISATION_HEADER)
        }
        return token
    }
}
