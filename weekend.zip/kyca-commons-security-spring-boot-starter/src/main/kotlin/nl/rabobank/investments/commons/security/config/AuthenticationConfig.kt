package nl.rabobank.investments.commons.security.config

import nl.rabobank.investments.commons.security.filter.SecurityFilter
import org.springframework.beans.factory.annotation.Value
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean
import org.springframework.boot.autoconfigure.security.servlet.PathRequest
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Import
import org.springframework.core.annotation.Order
import org.springframework.http.HttpMethod
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity
import org.springframework.security.config.annotation.web.builders.HttpSecurity
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity
import org.springframework.security.config.http.SessionCreationPolicy
import org.springframework.security.web.SecurityFilterChain
import org.springframework.security.web.header.writers.StaticHeadersWriter
import org.springframework.security.web.servletapi.SecurityContextHolderAwareRequestFilter
import org.springframework.web.cors.CorsConfiguration
import org.springframework.web.cors.CorsConfigurationSource
import org.springframework.web.cors.UrlBasedCorsConfigurationSource

const val CONFIGURATION_ORDER = -2
const val API_ENDPOINT_PATTERN = "/api/**"

@Configuration
@Order(CONFIGURATION_ORDER)
@EnableWebSecurity
@EnableGlobalMethodSecurity(securedEnabled = true, jsr250Enabled = true)
@Import(JwsConfig::class)
class AuthenticationConfig(
    private val authenticationEntryPoint: UnauthorizedEntryPoint,
    private val securityFilter: SecurityFilter
) {

    @Bean
    fun filterChain(http: HttpSecurity): SecurityFilterChain {
        authorizeRequests(http)
        configureResponseHeaders(http)
        return http.build()
    }

    @Throws(Exception::class)
    private fun authorizeRequests(http: HttpSecurity) {
        http
            .cors()
            .and()
            .csrf().disable()
            .sessionManagement()
            .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            .and()
            .authorizeRequests()
            .antMatchers(HttpMethod.OPTIONS, API_ENDPOINT_PATTERN).permitAll()
            .antMatchers(API_ENDPOINT_PATTERN).authenticated()
            .antMatchers("/api-docs/**").permitAll()
            .antMatchers("/ops/**").permitAll()
            .antMatchers("/actuator/**").permitAll()
            .antMatchers("/graphql/**").authenticated() // graphql used by agreement service
            .antMatchers("/goals/**").authenticated() // goal monitor service
            .antMatchers("/investments-information/**").authenticated() // aggregator service
            .antMatchers("/financial-information/**").authenticated() // financial information service
            .antMatchers("/playground").permitAll()
            .antMatchers("/vendor/playground/**/*").permitAll()
            .antMatchers("/graphiql/**").permitAll()
            .requestMatchers(PathRequest.toStaticResources().atCommonLocations()).permitAll()
            .anyRequest().denyAll()
            .and()
            .addFilterBefore(securityFilter, SecurityContextHolderAwareRequestFilter::class.java)
            .exceptionHandling().authenticationEntryPoint(authenticationEntryPoint)
    }

    @Bean
    @ConditionalOnMissingBean(type = ["org.springframework.web.cors.CorsConfigurationSource"])
    fun corsConfigurationSource(@Value("\${cors.origins}") corsOrigins: String): CorsConfigurationSource {
        val corsConfiguration = CorsConfiguration().apply {
            allowedOrigins = corsOrigins.split(",")
            allowedMethods = listOf("DELETE", "GET", "POST", "PUT", "PATCH")
        }

        return UrlBasedCorsConfigurationSource().apply {
            registerCorsConfiguration(API_ENDPOINT_PATTERN, corsConfiguration)
        }
    }

    @Throws(Exception::class)
    private fun configureResponseHeaders(http: HttpSecurity) {
        http.headers()
            .frameOptions().sameOrigin()
            .addHeaderWriter(StaticHeadersWriter("Server", "Unknown"))
            .addHeaderWriter(StaticHeadersWriter("X-Powered-By", "Unknown"))
    }
}
