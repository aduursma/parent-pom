package nl.rabobank.investments.commons.security.authorization.customer.authhub.domain

data class Arrangement(
    val number: String,
    val administrationCode: String,
    val authorizations: Collection<String>
)
