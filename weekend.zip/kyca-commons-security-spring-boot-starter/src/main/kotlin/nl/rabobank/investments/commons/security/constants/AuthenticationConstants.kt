package nl.rabobank.investments.commons.security.constants

object AuthenticationConstants {
    const val API_KEY_HEADER = "x-api-key"
    const val CUSTOMER_AUTHORISATION_HEADER = "x-auth-user"
    const val EMPLOYEE_AUTHORISATION_HEADER = "x-auth-employee"
    const val CLIENT_CERTIFICATE_HEADER = "x-forwarded-client-cert"
    const val USER_TYPE_APPLICATION = "APPLICATION"
    const val USER_TYPE_CUSTOMER = "CUSTOMER"
    const val CLAIM_APPLICATION_PROFILE =
        "http://schemas.rabobankinternational.com/identity/claims/ApplicationProfileFull"
    const val CLAIM_ROLE = "role"
    const val CLAIM_EMPLOYEE_UNIQUE_NAME = "unique_name"
    const val CLAIM_DISPLAY_NAME = "http://schemas.rabobankinternational.com/identity/claims/DisplayName"
    const val CLAIM_RI_DISPLAY_NAME = "http://schemas.rabobankinternational.com/identity/claims/riDisplayName"
    const val CLAIM_RABOBANK_ID = "http://schemas.rabobankinternational.com/identity/claims/riRaboID"
    const val CLAIM_RABO_DN = "http://schemas.rabobankinternational.com/identity/claims/raboDN"
}
