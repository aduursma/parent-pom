package nl.rabobank.investments.commons.security.config

import org.springframework.http.MediaType
import org.springframework.security.core.AuthenticationException
import org.springframework.security.web.AuthenticationEntryPoint
import org.springframework.stereotype.Component
import java.io.IOException
import javax.servlet.ServletException
import javax.servlet.http.HttpServletRequest
import javax.servlet.http.HttpServletResponse
import javax.servlet.http.HttpServletResponse.SC_UNAUTHORIZED

@Component
class UnauthorizedEntryPoint : AuthenticationEntryPoint {
    @Throws(IOException::class, ServletException::class)
    override fun commence(request: HttpServletRequest, response: HttpServletResponse, authEx: AuthenticationException) {
        val body = """{"status":$SC_UNAUTHORIZED,"error":"Unauthorized","path":"${request.requestURI}"}"""
        response.status = SC_UNAUTHORIZED
        response.contentType = "${MediaType.APPLICATION_JSON_VALUE};charset=UTF-8"
        response.writer.println(body)
    }
}
