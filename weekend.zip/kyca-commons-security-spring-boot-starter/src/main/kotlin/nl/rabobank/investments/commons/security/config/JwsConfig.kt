package nl.rabobank.investments.commons.security.config

import brave.Tracer
import com.fasterxml.jackson.databind.ObjectMapper
import com.nimbusds.jose.jwk.source.RemoteJWKSet
import com.nimbusds.jose.proc.JWSAlgorithmFamilyJWSKeySelector
import com.nimbusds.jose.proc.SecurityContext
import com.nimbusds.jose.util.DefaultResourceRetriever
import com.nimbusds.jwt.proc.DefaultJWTClaimsVerifier
import com.nimbusds.jwt.proc.DefaultJWTProcessor
import nl.rabobank.investments.commons.security.converter.CustomerAuthenticationConverter
import nl.rabobank.investments.commons.security.converter.EmployeeAuthenticationConverter
import org.springframework.beans.factory.annotation.Value
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.security.oauth2.jwt.JwtDecoder
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder
import java.net.URL

private const val MAX_CLOCK_SKEW_IN_SECONDS = 30

@Configuration
class JwsConfig {

    @Bean
    fun customerAuthenticationConverter(objectMapper: ObjectMapper, tracer: Tracer): CustomerAuthenticationConverter {
        return CustomerAuthenticationConverter(objectMapper, tracer)
    }

    @Bean
    fun employeeAuthenticationConverter(tracer: Tracer): EmployeeAuthenticationConverter {
        return EmployeeAuthenticationConverter(tracer)
    }

    @Bean
    fun customerJwtDecoder(
        @Value("\${security.jws.connection-timeout}") connectionTimeout: Int,
        @Value("\${security.jws.read-timeout}") readTimeout: Int,
        @Value("\${security.jws.url}") jwkUrl: String
    ): JwtDecoder {
        return jwtDecoder(connectionTimeout, readTimeout, jwkUrl)
    }

    @Bean
    fun employeeJwtDecoder(
        @Value("\${security.employee-jws.connection-timeout}") connectionTimeout: Int,
        @Value("\${security.employee-jws.read-timeout}") readTimeout: Int,
        @Value("\${security.employee-jws.url}") jwkUrl: String
    ): JwtDecoder {
        return jwtDecoder(connectionTimeout, readTimeout, jwkUrl)
    }

    private fun jwtDecoder(connectionTimeout: Int, readTimeout: Int, jwkUrl: String): JwtDecoder {
        val resourceRetriever = DefaultResourceRetriever(connectionTimeout, readTimeout)
        val keySource = RemoteJWKSet<SecurityContext>(URL(jwkUrl), resourceRetriever)

        return NimbusJwtDecoder(
            DefaultJWTProcessor<SecurityContext>().apply {
                jwsKeySelector = JWSAlgorithmFamilyJWSKeySelector.fromJWKSource(keySource)
                (jwtClaimsSetVerifier as DefaultJWTClaimsVerifier).maxClockSkew = MAX_CLOCK_SKEW_IN_SECONDS
            }
        )
    }
}
