package nl.rabobank.investments.commons.security.authorization.customer.authhub.service

import nl.rabobank.investments.commons.agreement.domain.AgreementAuthorization
import nl.rabobank.investments.commons.security.authorization.customer.authhub.domain.Arrangement
import nl.rabobank.investments.commons.security.authorization.customer.authhub.domain.AuthorityConstants
import nl.rabobank.investments.commons.security.authorization.customer.authhub.domain.Authorization
import nl.rabobank.investments.commons.security.authorization.customer.authhub.repository.CustomerAuthorizationRepository
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.domain.ValidationResult
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Service
import java.util.function.Predicate

private const val VALIDATION_MESSAGE_KAD_PA = "KAD-PA"
private const val ADMIN_CODE_SECURITIES_ACCOUNT = "04"

@Service
class CustomerAuthorizationHubService(
    private val customerAuthorizationRepository: CustomerAuthorizationRepository
) {

    private val log = LoggerFactory.getLogger(javaClass)
    fun checkAuthorizations(
        authorization: AgreementAuthorization,
        investmentArrangementNumber: String,
        authentication: PrincipalAuthentication
    ): ValidationResult {
        return when (authorization) {
            AgreementAuthorization.VIEW_AGREEMENT,
            AgreementAuthorization.VIEW_KEC,
            AgreementAuthorization.EDIT_KEC ->
                checkUserAuthorizationForAction(
                    investmentArrangementNumber,
                    determineCustomerAuthorization(authorization),
                    authentication
                )
            else -> checkAuthorizationForAction(
                investmentArrangementNumber,
                determineCustomerAuthorization(authorization),
                authentication
            )
        }
    }

    private fun determineCustomerAuthorization(authorization: AgreementAuthorization) = when (authorization) {
        AgreementAuthorization.VIEW_AGREEMENT -> AuthorityConstants.CUSTOMER_AUTHORIZATION_GN_READ
        AgreementAuthorization.EDIT_AGREEMENT -> AuthorityConstants.CUSTOMER_AUTHORIZATION_GN_MODIFY
        AgreementAuthorization.DISCONTINUE_AGREEMENT -> AuthorityConstants.CUSTOMER_AUTHORIZATION_GN_MODIFY
        AgreementAuthorization.VIEW_KEC -> AuthorityConstants.CUSTOMER_AUTHORIZATION_GN_READ
        AgreementAuthorization.EDIT_KEC -> AuthorityConstants.CUSTOMER_AUTHORIZATION_CH_EF_01
        else -> throw NotImplementedError("Authorization: $authorization not supported")
    }

    private fun checkAuthorizationForAction(
        securityAccountNumber: String,
        actionName: String,
        authentication: PrincipalAuthentication
    ): ValidationResult {
        log.debug(
            "SecurityAccountNumber: $securityAccountNumber action: $actionName", securityAccountNumber
        )
        val authorization: Authorization =
            customerAuthorizationRepository.userCustomerAuthorization(authentication)
        val securitiesAccount = authorization.arrangements.stream().filter { arrangement ->
            hasSecuritiesAccount(securityAccountNumber).test(arrangement)
        }.findAny()
        return securitiesAccount.map { item: Arrangement ->
            ValidationResult(
                item.authorizations.contains(actionName),
                VALIDATION_MESSAGE_KAD_PA
            )
        }
            .orElse(ValidationResult(false, VALIDATION_MESSAGE_KAD_PA))
    }

    private fun checkUserAuthorizationForAction(
        securityAccountNumber: String,
        actionName: String,
        authentication: PrincipalAuthentication
    ): ValidationResult {
        log.info("SecurityAccountNumber: $securityAccountNumber action: $actionName", securityAccountNumber)
        val authorization: Authorization =
            customerAuthorizationRepository.userAuthorization(authentication)
        val securitiesAccount = authorization.arrangements.stream().filter { arrangement ->
            hasSecuritiesAccount(securityAccountNumber).test(arrangement)
        }.findAny()
        return securitiesAccount.map { item: Arrangement ->
            ValidationResult(
                item.authorizations.contains(actionName),
                VALIDATION_MESSAGE_KAD_PA
            )
        }
            .orElse(ValidationResult(false, VALIDATION_MESSAGE_KAD_PA))
    }

    fun checkCustomerLevelAuthorizations(
        authorizationName: String,
        authentication: PrincipalAuthentication
    ): ValidationResult {
        val authorization: Authorization =
            customerAuthorizationRepository.userCustomerAuthorization(authentication) // getPCFAuthorization
        return if (authorization.authorizations.contains(authorizationName)) {
            ValidationResult(true, "Customer-Authorization: $authorizationName")
        } else ValidationResult(false, "Customer-Authorization: $authorizationName")
    }

    private fun hasSecuritiesAccount(securitiesAccountNumber: String): Predicate<Arrangement> {
        return Predicate { agreement: Arrangement ->
            log.debug("Agreement id={} adminCode={}", agreement.number, agreement.administrationCode)
            agreement.number == securitiesAccountNumber &&
                isSecuritiesAccount(agreement.administrationCode)
        }
    }

    private fun isSecuritiesAccount(administrationCode: String): Boolean {
        return ADMIN_CODE_SECURITIES_ACCOUNT == administrationCode
    }
}
