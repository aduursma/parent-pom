[![Build Status](https://dev.azure.com/raboweb/Investments/_apis/build/status/expedite-commons-security-spring-boot-starter?repoName=expedite-commons-security-spring-boot-starter&branchName=master)](https://dev.azure.com/raboweb/Investments/_build/latest?definitionId=24449&repoName=expedite-commons-security-spring-boot-starter&branchName=master)

# Introduction
This project is a Spring Boot starter for adding security to your Spring Boot application.

# Getting Started
Just add this project as a dependency to the Maven project you want to have security enabled for, replacing the version number with the actual latest version number.

```
<parent>
    <groupId>nl.rabobank.investments.sales</groupId>
    <artifactId>kyca-commons-security-spring-boot-starter</artifactId>
    <version>...</version>
</parent>
```
