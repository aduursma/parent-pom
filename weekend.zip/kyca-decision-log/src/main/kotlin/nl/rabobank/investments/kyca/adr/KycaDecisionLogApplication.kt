package nl.rabobank.investments.kyca.adr

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class KycaDecisionLogApplication

@Suppress("SpreadOperator")
fun main(args: Array<String>) {
    SpringApplication.run(KycaDecisionLogApplication::class.java, *args)
}
