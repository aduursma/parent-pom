package nl.rabobank.investments.commons.logging.logbook

import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties(prefix = "logging.logbook.filter")
data class LogBookFilterConfigProperties(
    val fieldNames: List<String> = emptyList()
)
