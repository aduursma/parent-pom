package nl.rabobank.investments.commons.logging.logbook.autoconfigure

import nl.rabobank.investments.commons.logging.logbook.LogBookFilterConfigProperties
import org.springframework.boot.autoconfigure.AutoConfiguration
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Bean
import org.zalando.logbook.BodyFilter
import org.zalando.logbook.json.JacksonJsonFieldBodyFilter

private const val MASK_STRING = "XXX"

@AutoConfiguration
@EnableConfigurationProperties(LogBookFilterConfigProperties::class)
class LogBookAutoConfiguration(val logBookFilterConfigProperties: LogBookFilterConfigProperties?) {

    @Bean
    @ConditionalOnProperty("logging.logbook.filter.field-names")
    fun fieldNameBodyFilter(): BodyFilter {
        return JacksonJsonFieldBodyFilter(logBookFilterConfigProperties!!.fieldNames, MASK_STRING)
    }
}
