package nl.rabobank.investments.commons.logging.masker

import com.fasterxml.jackson.core.JsonStreamContext
import net.logstash.logback.mask.ValueMasker
import java.util.regex.Matcher
import java.util.regex.Pattern

private const val MASK_STRING = "$1****$2"
private const val XML_TAG_PATTERN = "(?is)(<[^>]*?{FIELD_NAME}.*?>).*?(<\\/[^>]*?{FIELD_NAME}.*?>)"

class XmlCustomValueMasker : ValueMasker {
    private var patterns = mutableListOf<Pattern>()
    var fieldNames: String? = null
        set(value) {
            field = value
            setPattern(fieldNames)
        }

    private fun setPattern(fieldNames: String?) {
        patterns.addAll(
            fieldNames?.split(",")?.map {
                Pattern.compile(XML_TAG_PATTERN.replace("{FIELD_NAME}", it))
            } ?: emptyList()
        )
    }

    override fun mask(context: JsonStreamContext?, value: Any?): Any? {
        var replaced = value
        if (replaced is CharSequence) {
            patterns.forEach {
                val matcher: Matcher = it.matcher(replaced as CharSequence)
                replaced = matcher.replaceAll(MASK_STRING)
            }
        }
        return if (replaced != value) replaced
        else null
    }
}
