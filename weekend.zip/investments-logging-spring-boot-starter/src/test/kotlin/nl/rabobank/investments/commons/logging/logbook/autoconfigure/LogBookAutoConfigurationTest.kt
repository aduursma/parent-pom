package nl.rabobank.investments.commons.logging.logbook.autoconfigure

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.runner.ApplicationContextRunner

class LogBookAutoConfigurationTest {
    private val contextRunner = ApplicationContextRunner()

    @Test
    fun `test fieldNameBodyFilter bean is created when field-names property is present`() {
        contextRunner
            .withPropertyValues("logging.logbook.filter.field-names:iban")
            .withUserConfiguration(
                LogBookAutoConfiguration::class.java
            ).run {
                assertThat(it).hasBean("fieldNameBodyFilter")
                assertThat(it).hasBean("logBookAutoConfiguration")
            }
    }

    @Test
    fun `test fieldNameBodyFilter bean is not created when field-names property is absent`() {
        contextRunner
            .withUserConfiguration(
                LogBookAutoConfiguration::class.java
            ).run {
                assertThat(it).doesNotHaveBean("fieldNameBodyFilter")
                assertThat(it).hasBean("logBookAutoConfiguration")
            }
    }
}
