package nl.rabobank.investments.commons.logging.masker

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test

class XmlCustomValueMaskerTest {
    private val fieldsToMask = "iban,account,email"
    private val xmlCustomValueMasker = XmlCustomValueMasker().apply {
        fieldNames = fieldsToMask
    }

    @Test
    fun `test xml tags which contains given fieldnames is masked`() {
        val maskedValue = xmlCustomValueMasker.mask(null, xmlstringWithFieldsToMask).toString()
        assertThat(maskedValue).contains("<ns3:id>11111111</ns3:id>")
        assertThat(maskedValue).contains("<ns3:iban>****</ns3:iban>")
        assertThat(maskedValue).contains("<ns3:emailId>****</ns3:emailId>")
        assertThat(maskedValue).contains("<ns3:testAccountNumber>****</ns3:testAccountNumber>")
        assertThat(xmlCustomValueMasker.fieldNames).isEqualTo(fieldsToMask)
    }

    @Test
    fun `test xml tag as a parent object can be masked `() {
        val xmlCustomValueMasker = XmlCustomValueMasker().apply {
            fieldNames = "address"
        }
        val maskedValue = xmlCustomValueMasker.mask(null, xmlstringWithoutFieldsToMask).toString()
        assertThat(maskedValue).contains("<ns3:address>****</ns3:address>")
    }

    @Test
    fun `test when no field names matches to fields to mask should return null`() {
        val maskedValue = xmlCustomValueMasker.mask(null, xmlstringWithoutFieldsToMask)
        assertThat(maskedValue).isNull()
    }

    @Test
    fun `test when no field names are configured to mask returns null`() {
        val xmlCustomValueMasker = XmlCustomValueMasker().apply {
            fieldNames = null
        }
        val maskedValue = xmlCustomValueMasker.mask(null, xmlstringWithFieldsToMask)
        assertThat(maskedValue).isNull()
    }

    @Test
    fun `test mask null value`() {
        val maskedValue = xmlCustomValueMasker.mask(null, null)
        assertThat(maskedValue).isNull()
    }

    @Test
    fun `test xml tags when fields to mask is not available in the message`() {
        val maskedValue = xmlCustomValueMasker.mask(null, null)
        assertThat(maskedValue).isNull()
    }

    private val xmlstringWithFieldsToMask = """
        <ns3:customer>
            <ns3:id>11111111</ns3:id>
            <ns3:iban>NL00RABO10001000</ns3:iban>
            <ns3:emailId>abc@test.com</ns3:emailId>
            <ns3:testAccountNumber>10001000</ns3:testAccountNumber>
        </ns3:customer>
    """.trimIndent()

    private val xmlstringWithoutFieldsToMask = """
        <ns3:customer>
            <ns3:address>
                <ns3:id>11111111</ns3:id>
                <ns3:street>Street 1</ns3:street>
                <ns3:zip>1111 AA</ns3:zip>
                <ns3:city>Utrecht</ns3:city>
                <ns3:country>Netherlands</ns3:country>
            </ns3:address>
        </ns3:customer>
    """.trimIndent()
}
