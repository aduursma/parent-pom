[![Build Status](https://dev.azure.com/raboweb/Investments/_apis/build/status/investments-logging-spring-boot-starter?repoName=investments-logging-spring-boot-starter&branchName=master)](https://dev.azure.com/raboweb/Investments/_build/latest?definitionId=24492&repoName=investments-logging-spring-boot-starter&branchName=master)

# Introduction
This project is a Spring Boot starter for logging access log and application log events to STDOUT.

The PCF environments are configured to send all logs to STDOUT and STDERR to Splunk.

Depending on the environment the logs will be written to one of the following indexes:

* azu_investments_n (DevTest)
* azu_investments_p (Production)

# Getting Started
Just add this project as a dependency to the Maven project you want to be able to log to Splunk, replacing the version number with the actual latest version number.

```
<parent>
    <groupId>nl.rabobank.investments.sales</groupId>
    <artifactId>investments-logging-spring-boot-starter</artifactId>
    <version>...</version>
</parent>
```

#Masking
As this library can be used to log request and responses, at times there would be requirement to mask sensitive information. This library supports masking using two patterns.
1. Masking fields logged by [LogBook](https://github.com/zalando/logbook#filtering). Logbook supports configuring body filters, and we have configured JacksonJsonFieldBodyFilter. 
   Usage: set property `logging.logbook.filter.field-names` with the list of field names to mask. It'll mask all the fields before sending to logger and is **case sensitive**.
   Example: logging.logbook.filter.field-names=iban,accountNumber. 
2. Masking fields using logback.xml. We use logstash encoder to log in json format. Masking can be achieved by two ways
   1. Using field names: property `logging.logback.filter.field-names` will mask all xml tags which **contains** the string. It accepts a comma seperated string and is **case insensitive**
   Example1: `logging.logback.filter.field-names=iban,accountNumber` will mask tags containing the fields like below.
   ```xml
   <customer>
      <account>
         <id>1</id>
         <settlementAccountNumber>****</settlementAccountNumber>
         <iban>****</iban>
      </account>
   </customer>
   ```
      Example2: logging.logback.filter.field-names=account will mask the whole parent object like below.
   ```xml
   <customer>
      <account>****</account>
   </customer>
   ```
   2. Using patterns to identify field values: `logging.logback.filter.field-patterns` - this should contain comma seperated list of regex patterns which will mask all matching string. Should be used when pattern of the value is known like email address, dutch Iban number.
          Example: `logging.logback.filter.field-patterns=[A-Za-z]{2}\\d{2}[A-Za-z]{4}\\d{10}` this will mask any dutch Iban number for example NLXXRABO1111111111.

