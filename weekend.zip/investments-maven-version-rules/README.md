[![Build Status](https://dev.azure.com/raboweb/Investments/_apis/build/status/investments-maven-version-rules?repoName=investments-maven-version-rules&branchName=master)](https://dev.azure.com/raboweb/Investments/_build/latest?definitionId=24550&repoName=investments-maven-version-rules&branchName=master)


# Introduction 
This project contains the Maven version rules we use for displaying outdated dependencies and plugins and updating them. 

# Getting Started
In any of our Maven projects you can use the command below to display outdated dependencies and plugins to the console:

```
mvn -U -Pcheck-for-updates validate
```

The console output is also written to the `outdated-dependencies.txt` file in the `target` directory of your project. 
