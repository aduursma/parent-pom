[![Build Status](https://dev.azure.com/raboweb/Investments/_apis/build/status/expedite-commons-test?repoName=expedite-commons-test&branchName=master)](https://dev.azure.com/raboweb/Investments/_build/latest?definitionId=23074&repoName=expedite-commons-test&branchName=master)


# Introduction
This project contains the general configuration and setup of our test cases.

# Getting Started
Just add this project as a dependency to the Maven project you want to have the general test cases configuration and setup available for, replacing the version number with the actual latest version number.

```
<parent>
    <groupId>nl.rabobank.investments.sales</groupId>
    <artifactId>kyca-commons-test</artifactId>
    <version>...</version>
</parent>
```
