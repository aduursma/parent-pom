package nl.rabobank.investments.commons.test.restdocs

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import java.io.FileNotFoundException
import java.util.MissingResourceException
import kotlin.test.assertFailsWith

class RestDocsUtilsTest {

    private val restDocsUtils = RestDocsUtils("src/test/resources/field-descriptions.properties")

    @Test
    fun `when the field descriptions file cannot be found a FileNotFoundException is thrown`() {
        assertFailsWith<FileNotFoundException> { RestDocsUtils() }
    }

    @Test
    fun `when a field description key cannot be found a MissingResourceException is thrown`() {
        assertFailsWith<MissingResourceException> { restDocsUtils.getDescription("non-existing-key")  }
    }

    @Test
    fun `when a field description key is found the corresponding description is returned`() {
        assertThat(restDocsUtils.getDescription("a.field")).isEqualTo("A description.")
    }

    @Test
    fun `when a field with an array path is requested the array construct is prepended to the field`() {
        assertThat(restDocsUtils.fieldWithArrayPath("aField")?.path).isEqualTo("[].aField")
    }

    @Test
    fun `when a subsection with an array path is requested the array construct is prepended to the subsection`() {
        assertThat(restDocsUtils.subsectionWithArrayPath("aSubsection")?.path).isEqualTo("[].aSubsection")
    }
}
