package nl.rabobank.investments.commons.test

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.core.env.Environment

@SpringBootTest(properties = [ "local.server.port=8080" ])
class BaseIntegrationTestClassIT : BaseIntegrationTestClass() {

    @Autowired
    lateinit var environment: Environment

    @Test
    fun verifyActiveProfile() {
        assertThat(environment.activeProfiles).containsExactly("integration-test")
    }
}
