package nl.rabobank.investments.commons.test

import io.restassured.RestAssured
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test

class BaseTestClassTest {

    @Test
    fun verifyRestAssuredSetUp() {
        BaseTestClassImpl().setUpRestAssured()
        assertThat(RestAssured.config.jsonConfig.numberReturnType().isFloatOrDouble).isTrue
        assertThat(RestAssured.config.logConfig.isLoggingOfRequestAndResponseIfValidationFailsEnabled).isTrue
    }
}

class BaseTestClassImpl : BaseTestClass()
