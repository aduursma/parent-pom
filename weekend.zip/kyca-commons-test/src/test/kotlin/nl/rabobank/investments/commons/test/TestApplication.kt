package nl.rabobank.investments.commons.test

import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class TestApplication
