package nl.rabobank.investments.commons.test

import org.assertj.core.api.Assertions
import org.junit.jupiter.api.Test
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.core.env.Environment

@SpringBootTest(properties = [ "local.server.port=8080" ])
class BaseDocumentationTestClassIT : BaseDocumentationTestClass() {

    @Autowired
    lateinit var environment: Environment

    @Test
    fun verifyActiveProfile() {
        Assertions.assertThat(environment.activeProfiles).containsExactly("documentation-test")
    }
}
