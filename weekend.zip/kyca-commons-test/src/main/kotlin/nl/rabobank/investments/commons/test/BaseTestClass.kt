package nl.rabobank.investments.commons.test

import io.restassured.RestAssured
import io.restassured.config.JsonConfig
import io.restassured.config.LogConfig
import io.restassured.config.RestAssuredConfig
import io.restassured.path.json.config.JsonPathConfig
import io.restassured.response.Response
import nl.rabobank.investments.commons.test.wiremock.CrmiRequestMatcher
import org.apache.commons.io.FileUtils
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.springframework.boot.test.context.SpringBootTest
import org.springframework.boot.test.context.TestConfiguration
import org.springframework.boot.test.web.server.LocalServerPort
import org.springframework.cloud.contract.wiremock.AutoConfigureWireMock
import org.springframework.cloud.contract.wiremock.WireMockConfigurationCustomizer
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Import
import org.springframework.util.ResourceUtils

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Import(WiremockConfig::class)
@AutoConfigureWireMock(port = 0, files = ["classpath:/stubs"])
class BaseTestClass {

    @LocalServerPort
    internal var serverPort: Int = 0

    @BeforeEach
    fun setUpRestAssured() {
        RestAssured.port = serverPort
        RestAssured.config = RestAssuredConfig.newConfig()
            .jsonConfig(JsonConfig.jsonConfig().numberReturnType(JsonPathConfig.NumberReturnType.DOUBLE))
            .logConfig(LogConfig.logConfig().enableLoggingOfRequestAndResponseIfValidationFails())
    }

    fun loadFileContentsFromClassPath(fileName: String): String {
        val file = ResourceUtils.getFile("classpath:$fileName")
        return FileUtils.readFileToString(file, "UTF-8")
    }

    fun verifyResponseHeaders(response: Response) {
        assertThat(response.header("X-Content-Type-Options")).isEqualTo("nosniff")
        assertThat(response.header("Server")).isEqualTo("Unknown")
        assertThat(response.header("Pragma")).isEqualTo("no-cache")
        assertThat(response.header("X-Frame-Options")).isEqualTo("SAMEORIGIN")
        assertThat(response.header("X-XSS-Protection")).isEqualTo("1; mode=block")
    }

    fun verifyResponseHeadersWithResponseBody(response: Response) {
        verifyResponseHeaders(response)
        assertThat(response.header("Expires")).isEqualTo("0")
        assertThat(response.header("Content-Type")).isEqualTo("application/json;charset=UTF-8")
        assertThat(response.header("Cache-Control")).isEqualTo("no-cache, no-store, max-age=0, must-revalidate")
    }
}

@TestConfiguration
class WiremockConfig {

    @Bean
    fun optionsCustomizer(): WireMockConfigurationCustomizer? {
        return WireMockConfigurationCustomizer {
            it.extensions(CrmiRequestMatcher())
        }
    }
}
