package nl.rabobank.investments.commons.test

import io.restassured.builder.RequestSpecBuilder
import io.restassured.specification.RequestSpecification
import nl.rabobank.investments.commons.test.restdocs.RestDocsUtils
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.extension.ExtendWith
import org.springframework.http.HttpHeaders.ACCEPT
import org.springframework.http.HttpHeaders.AUTHORIZATION
import org.springframework.http.HttpHeaders.CACHE_CONTROL
import org.springframework.http.HttpHeaders.COOKIE
import org.springframework.http.HttpHeaders.EXPIRES
import org.springframework.http.HttpHeaders.PRAGMA
import org.springframework.http.HttpHeaders.SERVER
import org.springframework.http.HttpHeaders.SET_COOKIE
import org.springframework.http.HttpHeaders.TRANSFER_ENCODING
import org.springframework.restdocs.RestDocumentationContextProvider
import org.springframework.restdocs.RestDocumentationExtension
import org.springframework.restdocs.operation.preprocess.OperationPreprocessor
import org.springframework.restdocs.operation.preprocess.Preprocessors.modifyUris
import org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessRequest
import org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse
import org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint
import org.springframework.restdocs.operation.preprocess.Preprocessors.removeHeaders
import org.springframework.restdocs.payload.FieldDescriptor
import org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath
import org.springframework.restdocs.restassured3.RestAssuredRestDocumentation.document
import org.springframework.restdocs.restassured3.RestAssuredRestDocumentation.documentationConfiguration
import org.springframework.restdocs.restassured3.RestDocumentationFilter
import org.springframework.test.context.ActiveProfiles

private const val APPLICATION_CONTEXT = "X-Application-Context"
private const val CONTENT_TYPE_OPTIONS = "X-Content-Type-Options"
private const val CONTENT_SECURITY_POLICY = "Content-Security-Policy"
private const val FRAME_OPTIONS = "X-Frame-Options"
private const val POWERED_BY = "X-Powered-By"
private const val XSS_PROTECTION = "X-XSS-Protection"
private const val X_AUTH_USER = "x-auth-user"
private const val X_AUTH_EMPLOYEE = "x-auth-employee"
private const val X_FORWARDED_CLIENT_CERT = "x-forwarded-client-cert"

private const val VARY = "Vary"
private const val DATE = "Date"
private const val KEEP_ALIVE = "Keep-Alive"
private const val CONNECTION = "Connection"
private const val CONTENT_LENGTH = "Content-Length"

@ActiveProfiles("documentation-test")
@ExtendWith(RestDocumentationExtension::class)
abstract class BaseDocumentationTestClass : BaseTestClass() {

    var documentationSpec: RequestSpecification? = null
    var documentationFilter: RestDocumentationFilter? = null

    protected var error: List<FieldDescriptor> = listOf(
        fieldWithPath("timestamp").description("The timestamp the error occurred."),
        fieldWithPath("status").description("The HTTP response code."),
        fieldWithPath("error").description("The HTTP response code description."),
        fieldWithPath("message").description("An informational error message."),
        fieldWithPath("exception").description("The actual error which occurred."),
        fieldWithPath("path").description("The requested URI.")
    )

    @BeforeEach
    fun setUpRestDocs(restDocumentation: RestDocumentationContextProvider) {
        documentationFilter = document(
            "{method-name}",
            preprocessRequest(prettyPrint(), modifyHostname(), removeRequestHeaders()),
            preprocessResponse(prettyPrint(), modifyHostname(), removeResponseHeaders())
        )

        documentationSpec = RequestSpecBuilder()
            .addFilter(documentationConfiguration(restDocumentation))
            .addFilter(documentationFilter)
            .build()
    }

    fun modifyHostname(): OperationPreprocessor? {
        return modifyUris().scheme("https").host("api.rabobank.nl").removePort()
    }

    fun removeRequestHeaders(): OperationPreprocessor? {
        return removeHeaders(ACCEPT, AUTHORIZATION, COOKIE, X_AUTH_USER, X_AUTH_EMPLOYEE, X_FORWARDED_CLIENT_CERT)
    }

    fun removeResponseHeaders(): OperationPreprocessor? {
        return removeHeaders(
            SET_COOKIE, TRANSFER_ENCODING, CACHE_CONTROL, EXPIRES, PRAGMA, SERVER, APPLICATION_CONTEXT,
            CONTENT_TYPE_OPTIONS, FRAME_OPTIONS, XSS_PROTECTION, POWERED_BY, VARY, DATE, KEEP_ALIVE, CONNECTION,
            CONTENT_LENGTH, CONTENT_SECURITY_POLICY
        )
    }

    fun getDescription(key: String): String? {
        return RestDocsUtils().getDescription(key)
    }
}
