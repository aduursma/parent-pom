package nl.rabobank.investments.commons.test.restdocs

object RestDocsConstants {

    const val QUERY = "query"
    const val OPERATION_NAME = "operationName"
    const val VARIABLES = "variables"

}
