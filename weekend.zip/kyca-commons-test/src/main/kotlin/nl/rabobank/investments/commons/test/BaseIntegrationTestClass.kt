package nl.rabobank.investments.commons.test

import org.springframework.test.context.ActiveProfiles

@ActiveProfiles("integration-test")
abstract class BaseIntegrationTestClass : BaseTestClass()
