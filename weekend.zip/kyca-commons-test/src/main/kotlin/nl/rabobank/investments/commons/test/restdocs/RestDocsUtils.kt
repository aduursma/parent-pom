package nl.rabobank.investments.commons.test.restdocs

import org.apache.commons.io.FileUtils
import org.apache.commons.io.IOUtils
import org.springframework.restdocs.payload.FieldDescriptor
import org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath
import org.springframework.restdocs.payload.PayloadDocumentation.subsectionWithPath
import org.springframework.restdocs.snippet.Attributes.key
import java.io.File
import java.util.PropertyResourceBundle

const val DEFAULT_FIELD_DESCRIPTIONS_FILE = "src/main/asciidoc/descriptions/field-descriptions.properties"

class RestDocsUtils(fileLocation: String = DEFAULT_FIELD_DESCRIPTIONS_FILE) {

    private val fieldDescriptions = retrieveAllFieldDescriptions(File(fileLocation))

    fun getDescription(key: String): String? {
        return fieldDescriptions.getString(key)
    }

    fun fieldWithArrayPath(path: String): FieldDescriptor? {
        return fieldWithPath("[].$path").attributes(key("arrayPath").value(path))
    }

    fun subsectionWithArrayPath(path: String): FieldDescriptor? {
        return subsectionWithPath("[].$path").attributes(key("arrayPath").value(path))
    }

    private fun retrieveAllFieldDescriptions(fieldDescriptionsFile: File): PropertyResourceBundle {
        val fieldDescriptionsFileInputStream = FileUtils.openInputStream(fieldDescriptionsFile)
        try {
            return PropertyResourceBundle(fieldDescriptionsFileInputStream)
        } finally {
            IOUtils.closeQuietly(fieldDescriptionsFileInputStream)
        }
    }
}
