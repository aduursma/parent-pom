package nl.rabobank.investments.commons.test.wiremock

import com.github.tomakehurst.wiremock.extension.Parameters
import com.github.tomakehurst.wiremock.http.Request
import com.github.tomakehurst.wiremock.http.RequestMethod
import com.github.tomakehurst.wiremock.matching.MatchResult
import com.github.tomakehurst.wiremock.matching.RequestMatcherExtension
import org.apache.commons.lang3.StringUtils

class CrmiRequestMatcher : RequestMatcherExtension() {

    private val predefinedKeys = listOf("url", "count")

    override fun getName(): String {
        return "crmiRequestMatcher"
    }

    override fun match(request: Request, parameters: Parameters): MatchResult {
        return if (urlMatches(request, parameters) && methodMatches(request) && xmlTagsMatch(request, parameters)) {
            MatchResult.exactMatch()
        } else {
            MatchResult.noMatch()
        }
    }

    private fun urlMatches(request: Request, parameters: Parameters): Boolean {
        val url = parameters.getString("url")
        return request.url.endsWith(url)
    }

    private fun methodMatches(request: Request): Boolean {
        return request.method == RequestMethod.POST
    }

    private fun xmlTagsMatch(request: Request, parameters: Parameters): Boolean {
        val requestBody = request.bodyAsString
        for ((key, value1) in parameters) {
            if (!isPredefinedKey(key)) {
                val values = StringUtils.split(value1 as String, ',')
                for (value in values) {
                    val tag = String.format("%s>%s<", key, value.trim { it <= ' ' })
                    if (!requestBody.contains(tag)) {
                        return false
                    }
                }
            }
        }
        for (key in parameters.keys) {
            if (key.startsWith("count")) {
                val xmlTag = StringUtils.substringBetween(key, "count(", ")") + ">"
                val expectedOccurenceCount = parameters.getInt(key)
                val actualOccurenceCount = StringUtils.countMatches(requestBody, xmlTag) / 2
                if (expectedOccurenceCount != actualOccurenceCount) {
                    return false
                }
            }
        }
        return true
    }

    private fun isPredefinedKey(key: String): Boolean {
        return predefinedKeys.stream().anyMatch { predefinedKey: String? -> key.startsWith(predefinedKey!!) }
    }
}
