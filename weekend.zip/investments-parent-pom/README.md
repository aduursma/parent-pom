[![Build Status](https://dev.azure.com/raboweb/Investments/_apis/build/status/investments-parent-pom?repoName=investments-parent-pom&branchName=master)](https://dev.azure.com/raboweb/Investments/_build/latest?definitionId=21962&repoName=investments-parent-pom&branchName=master)


# Introduction 
This Maven POM is the root POM for all of our Maven projects.

In this POM the following configuration is defined for all derived Maven projects:

* Java version
* Kotlin version
* Spring Boot version
* Spring Cloud version
* Maven plugin versions

Also, the Maven lifecycle steps are configured to enable:

* Trunk-based development using CI friendly Maven versions

# Getting Started
Just add the root POM as a parent to the Maven project you want to derive from the root POM, replacing the version number with the actual latest version number.

```
<parent>
    <groupId>nl.rabobank.investments.sales</groupId>
    <artifactId>investments-parent-pom</artifactId>
    <version>...</version>
</parent>
```
