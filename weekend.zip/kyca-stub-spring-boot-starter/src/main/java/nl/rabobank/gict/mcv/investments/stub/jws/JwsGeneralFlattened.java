package nl.rabobank.gict.mcv.investments.stub.jws;

import lombok.Data;
import wiremock.com.fasterxml.jackson.annotation.JsonProperty;

/**
 * JWS General JSON serialization object for the 'flattened' case ex RFC-7515, para 7.2.2 See
 * https://tools.ietf.org/html/rfc7515#section-7.2.2 and https://tools.ietf.org/html/rfc7515#appendix-A.7
 */

@Data
public class JwsGeneralFlattened {

  /**
   * RFC-7515: this should be marshalled to base64url encoded string E.g. <code> "payload":
   * "eyJpc3MiOiJqb2UiLA0KICJleHAiOjEzMDA4MTkzODAsDQogImh0dHA6Ly9leGFtcGxlLmNvbS9pc19yb290Ijp0cnVlfQ",
   * </code>
   */
  private byte[] payload; // should (un)marshall to base64encoded string

  /**
   * RFC-7515: this should be marshalled to base64url encoded string
   */
  @JsonProperty("protected")
  private byte[] Protected;

  /**
   * RFC-7515: this should be marshalled to plain json by marshaller. E.g. <code> "header":
   * {"kid":"e9bc097a-ce51-4036-9562-d2ade882db0d"}, </code>S
   */
  private Object header;

  /**
   * RFC-7515: this should be marshalled to base64url encoded string
   */
  private byte[] signature;

}
