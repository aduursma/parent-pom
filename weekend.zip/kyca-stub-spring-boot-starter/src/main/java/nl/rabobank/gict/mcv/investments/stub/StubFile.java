package nl.rabobank.gict.mcv.investments.stub;

import com.github.tomakehurst.wiremock.common.TextFile;
import java.io.IOException;
import java.nio.charset.Charset;
import org.springframework.core.io.Resource;
import org.springframework.util.FileCopyUtils;

public class StubFile extends TextFile {

    private byte[] contents;
    private String path;

    public StubFile(String path, Resource resource) throws IOException {
        super(resource.getURI());
        this.contents = FileCopyUtils.copyToByteArray(resource.getInputStream());
        this.path = path;
    }

    @Override
    public String getPath() {
        return path;
    }

    @Override
    public byte[] readContents() {
        return contents;
    }

    @Override
    public String readContentsAsString() {
        return new String(readContents(), Charset.forName("UTF-8"));
    }
}
