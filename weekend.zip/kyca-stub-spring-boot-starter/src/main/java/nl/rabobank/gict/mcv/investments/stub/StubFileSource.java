package nl.rabobank.gict.mcv.investments.stub;

import com.github.tomakehurst.wiremock.common.BinaryFile;
import com.github.tomakehurst.wiremock.common.FileSource;
import com.github.tomakehurst.wiremock.common.TextFile;
import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

public class StubFileSource implements FileSource {

    private List<StubFile> stubFiles;

    public StubFileSource(List<StubFile> stubFiles) {
        this.stubFiles = stubFiles;
    }

    @Override
    public BinaryFile getBinaryFileNamed(String name) {
        return stubFiles.stream().filter(stubFile -> stubFile.getPath().endsWith(name)).findFirst().get();
    }

    @Override
    public TextFile getTextFileNamed(String name) {
        return stubFiles.stream().filter(stubFile -> stubFile.getPath().endsWith(name)).findFirst().get();
    }

    @Override
    public void createIfNecessary() {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public FileSource child(String subDirectoryName) {
        List<StubFile> files =
                stubFiles.stream().filter(stubFile -> stubFile.getPath().contains(subDirectoryName)).collect(Collectors.toList());
        return new StubFileSource(files);
    }

    @Override
    public String getPath() {
        return null;
    }

    @Override
    public URI getUri() {
        return null;
    }

    @Override
    public List<TextFile> listFilesRecursively() {
        return stubFiles.stream().filter(stubFile -> (stubFile.getPath().endsWith(".json") && stubFile.getPath().contains("mapping")))
                .collect(Collectors.toList());
    }

    @Override
    public void writeTextFile(String s, String s1) {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public void writeBinaryFile(String s, byte[] bytes) {
        throw new UnsupportedOperationException("Not supported");
    }

    @Override
    public boolean exists() {
        return true;
    }

    @Override
    public void deleteFile(String s) {
    }
}

