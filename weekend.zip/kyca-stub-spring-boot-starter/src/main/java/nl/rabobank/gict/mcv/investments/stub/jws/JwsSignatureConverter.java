package nl.rabobank.gict.mcv.investments.stub.jws;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.security.KeyFactory;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.text.ParseException;

import com.nimbusds.jose.JOSEException;
import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.JWSHeader;
import com.nimbusds.jose.JWSObject;
import com.nimbusds.jose.JWSSigner;
import com.nimbusds.jose.Payload;
import com.nimbusds.jose.crypto.RSASSASigner;
import com.nimbusds.jose.util.Base64URL;
import com.nimbusds.jose.util.IOUtils;
import lombok.extern.slf4j.Slf4j;
import org.bouncycastle.util.io.pem.PemObject;
import org.bouncycastle.util.io.pem.PemReader;
import wiremock.com.fasterxml.jackson.core.JsonProcessingException;
import wiremock.com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.core.io.ClassPathResource;

@Slf4j
public class JwsSignatureConverter {

    private static final String PRIVATE_KEY_FILE_NAME = "ah_wiremock_private_key.pkcs8";

    private static final int BASE_64_PARTS_PROTECTED_INDEX = 0;

    private static final int BAE_64_PARTS_PAYLOAD_INDEX = 1;

    private static final int BASE_64_PARTS_SIGNATURE_INDEX = 2;

    private PrivateKey jwsPrivateKey;

    private JWSAlgorithm jwsAlgorithm;

    private ObjectMapper objectMapper = new ObjectMapper();

    public JwsSignatureConverter() {
        jwsPrivateKey = readPrivateKey();
        jwsAlgorithm = JWSAlgorithm.parse("RS256");
    }

    private PrivateKey readPrivateKey() {
        try {
            InputStream in = new ClassPathResource(PRIVATE_KEY_FILE_NAME).getInputStream();
            String privateKeyAsString = IOUtils.readInputStreamToString(in, StandardCharsets.UTF_8);

            PemObject pem = new PemReader(new StringReader(privateKeyAsString)).readPemObject();
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            PKCS8EncodedKeySpec ks = new PKCS8EncodedKeySpec(pem.getContent());
            return keyFactory.generatePrivate(ks);
        } catch (IOException | NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new IllegalStateException(e);
        }
    }

    public String convert(String input) {
        // set payload
        JwsGeneralFlattened rfc7515Result = new JwsGeneralFlattened();
        String serializedJwsObject;
        byte[] payloadAsBytes = input.getBytes(StandardCharsets.UTF_8);

        JWSHeader jwsHeader = new JWSHeader.Builder(jwsAlgorithm).build();

        try {
            JWSObject jwsObject = new JWSObject(jwsHeader, new Payload(payloadAsBytes));
            JWSSigner jwsSigner = new RSASSASigner(jwsPrivateKey);
            jwsObject.sign(jwsSigner);

            // Serialize jwsObject into String
            serializedJwsObject = jwsObject.serialize();
            // Split it into JOSE Base64URL-encoded parts
            Base64URL[] base64parts = JWSObject.split(serializedJwsObject);

            // Build the RFC7515-compliant object
            rfc7515Result.setProtected(base64parts[BASE_64_PARTS_PROTECTED_INDEX].decode());
            rfc7515Result.setPayload(base64parts[BAE_64_PARTS_PAYLOAD_INDEX].decode());
            rfc7515Result.setSignature(base64parts[BASE_64_PARTS_SIGNATURE_INDEX].decode());

            return objectMapper.writeValueAsString(rfc7515Result);
        } catch (JOSEException | ParseException | JsonProcessingException e) {
            log.warn("Error converting input", e);
            throw new IllegalStateException(e);
        }

    }
}
