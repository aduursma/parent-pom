package nl.rabobank.gict.mcv.investments.stub;

import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.util.JsonFormat;
import com.google.protobuf.util.JsonFormat.Parser;
import com.google.protobuf.util.JsonFormat.Printer;
import nl.rabobank.authorisationhub.rpm.api.model.Limit;
import nl.rabobank.authorisationhub.users.api.model.Arrangement;
import nl.rabobank.authorisationhub.users.api.model.Customer;
import nl.rabobank.authorisationhub.users.api.model.User;

import java.util.HashSet;
import java.util.Set;

public class JsonFormaterParser {

    public static final Printer AH_JSON_FORMAT_PRINTER;
    public static final Parser AH_JSON_FORMAT_PARSER;

    private JsonFormaterParser() {
    }

    static {
        Set<FieldDescriptor> fieldsToAlwaysOutput = new HashSet<>();
        fieldsToAlwaysOutput.add(User.getDescriptor().findFieldByName("customers"));
        fieldsToAlwaysOutput.add(Customer.getDescriptor().findFieldByName("authorisations"));
        fieldsToAlwaysOutput.add(Arrangement.getDescriptor().findFieldByName("authorisations"));
        fieldsToAlwaysOutput.addAll(Limit.getDescriptor().getFields());
        AH_JSON_FORMAT_PRINTER = JsonFormat.printer().omittingInsignificantWhitespace().includingDefaultValueFields(fieldsToAlwaysOutput)
                                           .preservingProtoFieldNames();
        AH_JSON_FORMAT_PARSER = JsonFormat.parser();
    }
}
