package nl.rabobank.gict.mcv.investments.stub;

import com.github.jknack.handlebars.Helper;
import com.github.jknack.handlebars.Options;
import com.github.jknack.handlebars.TagType;
import com.github.tomakehurst.wiremock.common.ClasspathFileSource;
import com.github.tomakehurst.wiremock.common.Slf4jNotifier;
import com.github.tomakehurst.wiremock.core.WireMockApp;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import com.github.tomakehurst.wiremock.extension.responsetemplating.ResponseTemplateTransformer;
import com.github.tomakehurst.wiremock.http.AdminRequestHandler;
import com.github.tomakehurst.wiremock.http.StubRequestHandler;
import com.github.tomakehurst.wiremock.jetty9.DefaultMultipartRequestConfigurer;
import com.github.tomakehurst.wiremock.servlet.MultipartRequestConfigurer;
import com.github.tomakehurst.wiremock.servlet.NotImplementedContainer;
import com.github.tomakehurst.wiremock.servlet.WireMockHandlerDispatchingServlet;
import lombok.extern.slf4j.Slf4j;
import nl.rabobank.gict.mcv.investments.stub.jws.JoseJsonTransformer;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.github.tomakehurst.wiremock.core.WireMockConfiguration.options;

@Slf4j
@Configuration
@ComponentScan(basePackages = "nl.rabobank.gict.mcv.investments.stub")
public class StubAutoConfiguration {

    private static final String WIREMOCK_CONTEXT_ROOT = "/data";
    private static final String[] SPRING_BOOT_URIS = {"/actuator", "/ops", "/cloudfoundry"};
    private static final String PING_URI = "/ping";

    @Value("${stubdata.folder:stubdata}")
    private String stubdataFolder;
    @Value("${ssl.keystore.file:BOOT-INF/classes/keyt2018.jks}")
    private String sslKeystoreFile;
    @Value("${ssl.keystore.password:mcv_ktn}")
    private String sslKeystorePassword;
    @Value("${ssl.keystore.type:jks}")
    private String sslKeystoreType;
    @Value("${ssl.truststore.file:BOOT-INF/classes/keyt2018.jks}")
    private String sslTruststoreFile;
    @Value("${ssl.truststore.password:mcv_ktn}")
    private String sslTruststorePassword;
    @Value("${ssl.truststore.type:jks}")
    private String sslTruststoreType;
    @Autowired
    private ApplicationContext ctx;

    @Bean
    public WireMockConfiguration wireMockConfiguration() throws IOException {
        WireMockConfiguration wireMockConfiguration = options();
        if (StringUtils.isNotEmpty(sslKeystoreFile) && StringUtils.isNotEmpty(sslTruststoreFile)) {
            String keystorePath = new ClasspathFileSource(sslKeystoreFile).getPath();
            String truststorePath = new ClasspathFileSource(sslTruststoreFile).getPath();
            wireMockConfiguration.keystorePath(keystorePath).keystorePassword(sslKeystorePassword)
                    .keystoreType(sslKeystoreType);
            wireMockConfiguration.trustStorePath(truststorePath).trustStorePassword(sslTruststorePassword)
                    .trustStoreType(sslTruststoreType);
        }
        wireMockConfiguration.fileSource(new StubFileSource(readStubFiles()));
        Helper<String> stringContainsHelper = (String value, Options options) -> {
            boolean contains = StringUtils.contains(value, options.param(0, ""));
            if (options.tagType == TagType.SECTION) {
                return contains ? options.fn() : options.inverse();
            } else {
                return contains ? options.hash("yes", true) : options.hash("no", false);
            }
        };

        Helper<String> stringContainsAnyHelper = (String value, Options options) -> {
            String commaSeparatedSearchString = options.param(0, "");
            commaSeparatedSearchString = StringUtils.removeAll(commaSeparatedSearchString, "s/\\s+//g");
            String[] searchStrings = StringUtils.split(commaSeparatedSearchString, ",");
            boolean contains = StringUtils.containsAny(value, searchStrings);
            if (options.tagType == TagType.SECTION) {
                return contains ? options.fn() : options.inverse();
            } else {
                return contains ? options.hash("yes", true) : options.hash("no", false);
            }
        };

        wireMockConfiguration.extensions(new CrmiRequestMatcher());

        Map<String, Helper> helpers = new HashMap<>();
        helpers.put("contains", stringContainsHelper);
        helpers.put("containsAny", stringContainsAnyHelper);
        wireMockConfiguration.extensions(new ResponseTemplateTransformer(false, helpers),
                new JoseJsonTransformer(), new ProtobufTransformer());
        return wireMockConfiguration;
    }

    @Bean
    public WireMockApp wireMockApp(WireMockConfiguration wireMockConfiguration) throws IOException {
        return new WireMockApp(wireMockConfiguration, new NotImplementedContainer());
    }

    @Bean
    public ServletRegistrationBean servletRegistrationBean() {
        ServletRegistrationBean bean = new ServletRegistrationBean(
                new WireMockHandlerDispatchingServlet(), WIREMOCK_CONTEXT_ROOT + "/*");
        bean.getInitParameters().put("mappedUnder", WIREMOCK_CONTEXT_ROOT);
        bean.getInitParameters().put("RequestHandlerClass", "com.github.tomakehurst.wiremock.http.StubRequestHandler");
        return bean;
    }

    @Bean
    public FilterRegistrationBean urlRewritingFilter() {
        FilterRegistrationBean filterRegistrationBean = new FilterRegistrationBean();
        filterRegistrationBean.setFilter((request, response, chain) -> {
            String uri = ((HttpServletRequest) request).getRequestURI();
            if (isPingUri(uri)) {
                ((HttpServletResponse) response).setStatus(HttpServletResponse.SC_OK);
            } else if (isSpringBootUri(uri)) {
                chain.doFilter(request, response);
            } else {
                request.getRequestDispatcher(WIREMOCK_CONTEXT_ROOT + uri).forward(request, response);
            }
        });
        filterRegistrationBean.addUrlPatterns("/*");
        return filterRegistrationBean;
    }

    @Bean
    public ServletListenerRegistrationBean<ServletContextListener> listenerRegistrationBean(WireMockApp wireMockApp) {
        ServletListenerRegistrationBean<ServletContextListener> bean =
                new ServletListenerRegistrationBean<>();
        bean.setListener(new ServletContextListener() {
            public void contextInitialized(ServletContextEvent sce) {
                ServletContext context = sce.getServletContext();
                context.setAttribute("WireMockApp", wireMockApp);
                context.setAttribute(StubRequestHandler.class.getName(), wireMockApp.buildStubRequestHandler());
                context.setAttribute(AdminRequestHandler.class.getName(), wireMockApp.buildAdminRequestHandler());
                context.setAttribute("Notifier", new Slf4jNotifier(false));
                context.setAttribute(MultipartRequestConfigurer.KEY, new DefaultMultipartRequestConfigurer());
            }

            public void contextDestroyed(ServletContextEvent sce) {
            }
        });

        return bean;
    }

    private List<StubFile> readStubFiles() throws IOException {
        List<StubFile> stubFiles = new ArrayList<>();
        Resource[] resources = ctx.getResources(String.format("classpath:/%s/**/*.*", stubdataFolder));
        for (Resource resource : resources) {
            String resourcePath = StringUtils
                    .substringAfterLast(resource.getURI().toString(), String.format("%s/", stubdataFolder));
            stubFiles.add(new StubFile(resourcePath, resource));
        }
        return stubFiles;
    }

    private boolean isPingUri(String uri) {
        return uri.endsWith(PING_URI);
    }

    private boolean isSpringBootUri(String uri) {
        return Arrays.stream(SPRING_BOOT_URIS).anyMatch(springBootUri -> uri.contains(springBootUri));
    }
}
