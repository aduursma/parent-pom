package nl.rabobank.gict.mcv.investments.stub.jws;

import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder;
import com.github.tomakehurst.wiremock.common.FileSource;
import com.github.tomakehurst.wiremock.extension.Parameters;
import com.github.tomakehurst.wiremock.extension.ResponseDefinitionTransformer;
import com.github.tomakehurst.wiremock.http.Request;
import com.github.tomakehurst.wiremock.http.ResponseDefinition;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JoseJsonTransformer extends ResponseDefinitionTransformer {

    private static final JwsSignatureConverter CONVERTER = new JwsSignatureConverter();

    @Override
    public ResponseDefinition transform(Request request, ResponseDefinition responseDefinition, FileSource files, Parameters parameters) {
        final int status = responseDefinition.getStatus();
        final String body = responseDefinition.getBody();
        log.debug("Transforming body to jose+json encoded body. Original: {}", body);

        String encodedBody;
        if (body != null && status >= 200 && status < 300) {
            encodedBody = CONVERTER.convert(body);
            log.debug("Transformed body result: {}", encodedBody);
        } else {
            encodedBody = body;
        }

        return new ResponseDefinitionBuilder()
                .withHeaders(responseDefinition.getHeaders())
                .withBody(encodedBody)
                .withStatus(status)
                .build();
    }

    public String getName() {
        return "jose-json-transformer";
    }

    @Override
    public boolean applyGlobally() {
        return false;
    }
}
