package nl.rabobank.gict.mcv.investments.stub;

import com.github.tomakehurst.wiremock.extension.Parameters;
import com.github.tomakehurst.wiremock.http.Request;
import com.github.tomakehurst.wiremock.http.RequestMethod;
import com.github.tomakehurst.wiremock.matching.MatchResult;
import com.github.tomakehurst.wiremock.matching.RequestMatcherExtension;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.apache.commons.lang3.StringUtils;

public class CrmiRequestMatcher extends RequestMatcherExtension {

    private List<String> predefinedKeys = Arrays.asList("url", "count");

    @Override
    public String getName() {
        return "crmiRequestMatcher";
    }

    @Override
    public MatchResult match(Request request, Parameters parameters) {
        if (urlMatches(request, parameters) && methodMatches(request) && xmlTagsMatch(request, parameters)) {
            return MatchResult.exactMatch();
        } else {
            return MatchResult.noMatch();
        }
    }

    private boolean urlMatches(Request request, Parameters parameters) {
        String url = parameters.getString("url");
        return request.getUrl().endsWith(url);
    }

    private boolean methodMatches(Request request) {
        return request.getMethod().equals(RequestMethod.POST);
    }

    private boolean xmlTagsMatch(Request request, Parameters parameters) {
        String requestBody = request.getBodyAsString();
        for (Map.Entry<String, Object> entry : parameters.entrySet()) {
            String key = entry.getKey();
            if (!isPredefinedKey(entry.getKey())) {
                String[] values = StringUtils.split((String) entry.getValue(), ',');
                for (String value : values) {
                    String tag = String.format("%s>%s<", key, value.trim());
                    if (!requestBody.contains(tag)) {
                        return false;
                    }
                }
            }
        }

        for (String key : parameters.keySet()) {
            if (key.startsWith("count")) {
                String xmlTag = StringUtils.substringBetween(key, "count(", ")") + ">";
                int expectedOccurenceCount = parameters.getInt(key);
                int actualOccurenceCount = StringUtils.countMatches(requestBody, xmlTag) / 2;
                if (expectedOccurenceCount != actualOccurenceCount) {
                    return false;
                }
            }
        }

        return true;
    }

    private boolean isPredefinedKey(String key) {
        return predefinedKeys.stream().anyMatch(predefinedKey -> key.startsWith(predefinedKey));
    }
}
