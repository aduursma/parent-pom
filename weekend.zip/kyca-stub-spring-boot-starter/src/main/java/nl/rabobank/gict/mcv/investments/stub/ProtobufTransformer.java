package nl.rabobank.gict.mcv.investments.stub;

import com.github.tomakehurst.wiremock.common.FileSource;
import com.github.tomakehurst.wiremock.extension.Parameters;
import com.github.tomakehurst.wiremock.extension.ResponseTransformer;
import com.github.tomakehurst.wiremock.http.Request;
import com.github.tomakehurst.wiremock.http.Response;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.Message.Builder;
import com.google.protobuf.util.JsonFormat;
import nl.rabobank.authorisationhub.rpm.api.model.Limit;
import nl.rabobank.authorisationhub.users.api.model.Customer;
import nl.rabobank.authorisationhub.users.api.model.User;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Supplier;

import static nl.rabobank.gict.mcv.investments.stub.JsonFormaterParser.AH_JSON_FORMAT_PARSER;

public class ProtobufTransformer extends ResponseTransformer {

    private static final String X_PROTOBUF_MESSAGE_HEADER = "X-Protobuf-Message";
    private static final String APPLICATION_X_PROTOBUF = "application/x-protobuf";

    private static final String MODEL_USER = User.class.getName();
    private static final String MODEL_LIMIT = Limit.class.getName();
    private static final String MODEL_CUSTOMER = Customer.class.getName();

    private static final Map<String, Supplier<Builder>> protobufBuilderMap;

    static {
        protobufBuilderMap = new HashMap<>();
        protobufBuilderMap.put(MODEL_CUSTOMER, Customer::newBuilder);
        protobufBuilderMap.put(MODEL_USER, User::newBuilder);
        protobufBuilderMap.put(MODEL_LIMIT, Limit::newBuilder);
    }

    private static final JsonFormat.Parser jsonFormatParser = AH_JSON_FORMAT_PARSER;

    @Override
    public String getName() {
        return "ProtobufTransformer";
    }

    @Override
    public Response transform(
            final Request request,
            final Response response,
            final FileSource fileSource,
            final Parameters parameters
    ) {
        if (response.getHeaders().getContentTypeHeader().containsValue(APPLICATION_X_PROTOBUF)) {
            return Response.Builder.like(response)
                                   .but().body(toProtobufBody(response))
                                   .build();
        }
        return response;
    }

    public byte[] toProtobufBody(Response response) {
        String messageType = response.getHeaders().getHeader(X_PROTOBUF_MESSAGE_HEADER).values().get(0);
        Supplier<Message.Builder> messageBuilderSupplier = protobufBuilderMap.get(messageType);
        if (messageBuilderSupplier == null) {
            throw new IllegalArgumentException("Unknown message type " + messageType);
        }
        Builder builder = messageBuilderSupplier.get();
        try {
            jsonFormatParser.merge(response.getBodyAsString(), builder);
        } catch (InvalidProtocolBufferException e) {
            throw new IllegalStateException("Error parsing json message of type " + messageType, e);
        }
        return builder.build().toByteArray();
    }

    @Override
    public boolean applyGlobally() {
        return false;
    }
}