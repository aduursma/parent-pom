package nl.rabobank.gict.mcv.investments.stub;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StubTestApplication {
    public static void main(String[] args) {
        SpringApplication.run(StubTestApplication.class, args);
    }
}
