[![Build Status](https://dev.azure.com/raboweb/Investments/_apis/build/status/expedite-commons-architecture-test?repoName=expedite-commons-architecture-test&branchName=master)](https://dev.azure.com/raboweb/Investments/_build/latest?definitionId=24307&repoName=expedite-commons-architecture-test&branchName=master)


# Introduction
This project contains the architectural test cases we use for validating the software architecture of our microservices.

# Getting Started
Just add this project as a dependency to the Maven project you want to validate the software architecture for, replacing the version number with the actual latest version number.

```
<parent>
    <groupId>nl.rabobank.investments.sales</groupId>
    <artifactId>kyca-commons-architecture-test</artifactId>
    <version>...</version>
</parent>
```
