package nl.rabobank.investments.architecture.rules

import com.tngtech.archunit.junit.AnalyzeClasses
import com.tngtech.archunit.junit.ArchTest
import com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes
import nl.rabobank.investments.architecture.rules.RulesConstants.AUTOCONFIGURE_PACKAGE
import nl.rabobank.investments.architecture.rules.RulesConstants.AUTO_CONFIGURATION_KT_SUFFIX
import nl.rabobank.investments.architecture.rules.RulesConstants.AUTO_CONFIGURATION_SUFFIX
import nl.rabobank.investments.architecture.rules.RulesConstants.BASE_PACKAGE
import nl.rabobank.investments.architecture.rules.RulesConstants.CONFIG_KT_SUFFIX
import nl.rabobank.investments.architecture.rules.RulesConstants.CONFIG_PACKAGE
import nl.rabobank.investments.architecture.rules.RulesConstants.CONFIG_SUFFIX
import nl.rabobank.investments.architecture.rules.RulesConstants.CONTROLLER_KT_SUFFIX
import nl.rabobank.investments.architecture.rules.RulesConstants.CONTROLLER_SUFFIX
import nl.rabobank.investments.architecture.rules.RulesConstants.PERSISTENCE_PACKAGE
import nl.rabobank.investments.architecture.rules.RulesConstants.PRESENTATION_PACKAGE
import nl.rabobank.investments.architecture.rules.RulesConstants.REPOSITORY_KT_SUFFIX
import nl.rabobank.investments.architecture.rules.RulesConstants.REPOSITORY_SUFFIX
import nl.rabobank.investments.architecture.rules.RulesConstants.SERVICE_KT_SUFFIX
import nl.rabobank.investments.architecture.rules.RulesConstants.SERVICE_PACKAGE
import nl.rabobank.investments.architecture.rules.RulesConstants.SERVICE_SUFFIX
import org.springframework.context.annotation.Configuration
import org.springframework.stereotype.Repository
import org.springframework.stereotype.Service
import org.springframework.web.bind.annotation.RestController

@AnalyzeClasses(packages = [BASE_PACKAGE])
class NamingConventionRules {

    @ArchTest
    val classesInAConfigPackageShouldBeNamedProperly = classes()
        .that().resideInAPackage(CONFIG_PACKAGE)
        .should().haveSimpleNameEndingWith(CONFIG_SUFFIX)
        .orShould().haveSimpleNameEndingWith(CONFIG_KT_SUFFIX)
        .because("Classes in a '$CONFIG_PACKAGE' package should have their name ending with '$CONFIG_SUFFIX'")

    @ArchTest
    val classesNamedConfigShouldBeInAConfigPackage = classes()
        .that().haveSimpleNameEndingWith(CONFIG_SUFFIX)
        .should().resideInAPackage(CONFIG_PACKAGE)
        .because("Classes that have their name ending with '$CONFIG_SUFFIX' should be in a '$CONFIG_PACKAGE' package")

    @ArchTest
    val configNamedClassesShouldBeAnnotatedProperly = classes()
        .that().haveSimpleNameEndingWith(CONFIG_SUFFIX)
        .should().beAnnotatedWith(Configuration::class.java)
        .because("Classes that have their name ending with '$CONFIG_SUFFIX' should be annotated with '@Configuration'")

    @ArchTest
    val classesInAAutoconfigurePackageShouldBeNamedProperly = classes()
        .that().resideInAPackage(AUTOCONFIGURE_PACKAGE)
        .should().haveSimpleNameEndingWith(AUTO_CONFIGURATION_SUFFIX)
        .orShould().haveSimpleNameEndingWith(AUTO_CONFIGURATION_KT_SUFFIX)
        .because("Classes in a 'autoconfigure' package should have their name ending with '$AUTO_CONFIGURATION_SUFFIX'")

    @ArchTest
    val classesNamedAutoConfigurationShouldBeInAAutoconfigurePackage = classes()
        .that().haveSimpleNameEndingWith(AUTO_CONFIGURATION_SUFFIX)
        .should().resideInAPackage(AUTOCONFIGURE_PACKAGE)
        .because(
            "Classes that have their name ending with '$AUTO_CONFIGURATION_SUFFIX' should be in a " +
                "'$AUTOCONFIGURE_PACKAGE' package"
        )

    @ArchTest
    val autoConfigurationNamedClassesShouldBeAnnotatedProperly = classes()
        .that().haveSimpleNameEndingWith(AUTO_CONFIGURATION_SUFFIX)
        .should().beAnnotatedWith(Configuration::class.java)
        .because(
            "Classes that have their name ending with '$AUTO_CONFIGURATION_SUFFIX' should be annotated with " +
                "'@Configuration'"
        )

    @ArchTest
    val configurationAnnotatedClassesShouldBeNamedProperly = classes()
        .that().areAnnotatedWith(Configuration::class.java)
        .should().haveSimpleNameEndingWith(CONFIG_SUFFIX)
        .orShould().haveSimpleNameEndingWith(AUTO_CONFIGURATION_SUFFIX)
        .because(
            "Classes that are annotated with '@Configuration' should have their name ending with either " +
                "'$CONFIG_SUFFIX' or '$AUTO_CONFIGURATION_SUFFIX'"
        )

    @ArchTest
    val classesInAPresentationPackageShouldBeNamedProperly = classes()
        .that().resideInAPackage(PRESENTATION_PACKAGE.dropLast(2))
        .should().haveSimpleNameEndingWith(CONTROLLER_SUFFIX)
        .orShould().haveSimpleNameEndingWith(CONTROLLER_KT_SUFFIX)
        .because(
            "Classes in a '${PRESENTATION_PACKAGE.dropLast(2)}' package should have their name ending with " +
                "'$CONTROLLER_SUFFIX'"
        )

    @ArchTest
    val classesNamedControllerShouldBeInAPresentationPackage = classes()
        .that().haveSimpleNameEndingWith(CONTROLLER_SUFFIX)
        .should().resideInAPackage(PRESENTATION_PACKAGE)
        .because(
            "Classes that have their name ending with '$CONTROLLER_SUFFIX' should be in a " +
                "'$PRESENTATION_PACKAGE' package"
        )

    @ArchTest
    val controllerNamedClassesShouldBeAnnotatedProperly = classes()
        .that().haveSimpleNameEndingWith(CONTROLLER_SUFFIX)
        .should().beAnnotatedWith(RestController::class.java)
        .because(
            "Classes that have their name ending with '$CONTROLLER_SUFFIX' should be annotated with " +
                "'@RestController'"
        )

    @ArchTest
    val restControllerAnnotatedClassesShouldBeNamedProperly = classes()
        .that().areAnnotatedWith(RestController::class.java)
        .should().haveSimpleNameEndingWith(CONTROLLER_SUFFIX)
        .because(
            "Classes that are annotated with '@RestController' should have their name ending with " +
                "'$CONTROLLER_SUFFIX'"
        )

    @ArchTest
    val classesInAServicePackageShouldBeNamedProperly = classes()
        .that().resideInAPackage(SERVICE_PACKAGE.dropLast(2))
        .should().haveSimpleNameEndingWith(SERVICE_SUFFIX)
        .orShould().haveSimpleNameEndingWith(SERVICE_KT_SUFFIX)
        .because(
            "Classes in a '${SERVICE_PACKAGE.dropLast(2)}' package should have their name ending with " +
                "'$SERVICE_SUFFIX'"
        )

    @ArchTest
    val classesNamedServiceShouldBeInAServicePackage = classes()
        .that().haveSimpleNameEndingWith(SERVICE_SUFFIX)
        .should().resideInAPackage(SERVICE_PACKAGE)
        .because(
            "Classes that have their name ending with '$SERVICE_SUFFIX' should be in a " +
                "'$SERVICE_PACKAGE' package"
        )

    @ArchTest
    val serviceNamedClassesShouldBeAnnotatedProperly = classes()
        .that().haveSimpleNameEndingWith(SERVICE_SUFFIX)
        .should().beAnnotatedWith(Service::class.java)
        .because(
            "Classes that have their name ending with '$SERVICE_SUFFIX' should be annotated with " +
                "'@Service'"
        )

    @ArchTest
    val serviceAnnotatedClassesShouldBeNamedProperly = classes()
        .that().areAnnotatedWith(Service::class.java)
        .should().haveSimpleNameEndingWith(SERVICE_SUFFIX)
        .because(
            "Classes that are annotated with '@Service' should have their name ending with " +
                "'$SERVICE_SUFFIX'"
        )

    @ArchTest
    val classesInARepositoryPackageShouldBeNamedProperly = classes()
        .that().resideInAPackage(PERSISTENCE_PACKAGE.dropLast(2))
        .should().haveSimpleNameEndingWith(REPOSITORY_SUFFIX)
        .orShould().haveSimpleNameEndingWith(REPOSITORY_KT_SUFFIX)
        .because(
            "Classes in a '${PERSISTENCE_PACKAGE.dropLast(2)}' package should have their name ending with " +
                "'$REPOSITORY_SUFFIX'"
        )

    @ArchTest
    val classesNamedRepositoryShouldBeInARepositoryPackage = classes()
        .that().haveSimpleNameEndingWith(REPOSITORY_SUFFIX)
        .should().resideInAPackage(PERSISTENCE_PACKAGE)
        .because(
            "Classes that have their name ending with '$REPOSITORY_SUFFIX' should be in a " +
                "'$PERSISTENCE_PACKAGE' package"
        )

    @ArchTest
    val repositoryNamedClassesShouldBeAnnotatedProperly = classes()
        .that().haveSimpleNameEndingWith(REPOSITORY_SUFFIX)
        .should().beAnnotatedWith(Repository::class.java)
        .because(
            "Classes that have their name ending with '$REPOSITORY_SUFFIX' should be annotated with " +
                "'@Repository'"
        )

    @ArchTest
    val repositoryAnnotatedClassesShouldBeNamedProperly = classes()
        .that().areAnnotatedWith(Repository::class.java)
        .should().haveSimpleNameEndingWith(REPOSITORY_SUFFIX)
        .because(
            "Classes that are annotated with '@Repository' should have their name ending with " +
                "'$REPOSITORY_SUFFIX'"
        )
}
