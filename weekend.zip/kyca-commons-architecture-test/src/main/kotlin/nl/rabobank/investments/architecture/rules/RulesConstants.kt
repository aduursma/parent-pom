package nl.rabobank.investments.architecture.rules

object RulesConstants {

    const val BASE_PACKAGE = "nl.rabobank.investments"
    const val PRESENTATION_PACKAGE = "..rest.."
    const val SERVICE_PACKAGE = "..service.."
    const val PERSISTENCE_PACKAGE = "..repository.."
    const val AUTOCONFIGURE_PACKAGE = "..autoconfigure.."
    const val CONFIG_PACKAGE = "..config.."
    const val DOMAIN_PACKAGE = "..domain.."

    const val PRESENTATION = "Presentation"
    const val SERVICE = "Service"
    const val PERSISTENCE = "Persistence"

    const val CONFIG_SUFFIX = "Config"
    const val CONFIG_KT_SUFFIX = "ConfigKt"
    const val AUTO_CONFIGURATION_SUFFIX = "AutoConfiguration"
    const val AUTO_CONFIGURATION_KT_SUFFIX = "AutoConfigurationKt"
    const val CONTROLLER_SUFFIX = "Controller"
    const val CONTROLLER_KT_SUFFIX = "ControllerKt"
    const val SERVICE_SUFFIX = "Service"
    const val SERVICE_KT_SUFFIX = "ServiceKt"
    const val REPOSITORY_SUFFIX = "Repository"
    const val REPOSITORY_KT_SUFFIX = "RepositoryKt"
}
