package nl.rabobank.investments.architecture.rules

import com.tngtech.archunit.base.DescribedPredicate.alwaysTrue
import com.tngtech.archunit.core.domain.properties.HasName.Predicates.nameMatching
import com.tngtech.archunit.junit.AnalyzeClasses
import com.tngtech.archunit.junit.ArchTest
import com.tngtech.archunit.library.Architectures.layeredArchitecture
import com.tngtech.archunit.library.dependencies.SlicesRuleDefinition
import nl.rabobank.investments.architecture.rules.RulesConstants.BASE_PACKAGE
import nl.rabobank.investments.architecture.rules.RulesConstants.PERSISTENCE
import nl.rabobank.investments.architecture.rules.RulesConstants.PERSISTENCE_PACKAGE
import nl.rabobank.investments.architecture.rules.RulesConstants.PRESENTATION
import nl.rabobank.investments.architecture.rules.RulesConstants.PRESENTATION_PACKAGE
import nl.rabobank.investments.architecture.rules.RulesConstants.SERVICE
import nl.rabobank.investments.architecture.rules.RulesConstants.SERVICE_PACKAGE

@AnalyzeClasses(packages = [BASE_PACKAGE])
class LayeredArchitectureRules {

    @ArchTest
    val layerBoundariesAreRespected =
        layeredArchitecture()
            .consideringAllDependencies()
            .layer(PRESENTATION).definedBy(PRESENTATION_PACKAGE)
            .layer(SERVICE).definedBy(SERVICE_PACKAGE)
            .layer(PERSISTENCE).definedBy(PERSISTENCE_PACKAGE)
            .whereLayer(PRESENTATION).mayNotBeAccessedByAnyLayer()
            .whereLayer(SERVICE).mayOnlyBeAccessedByLayers(PRESENTATION)
            .whereLayer(PERSISTENCE).mayOnlyBeAccessedByLayers(SERVICE)
            .ignoreDependency(
                nameMatching(".*\\.DatabaseSeeder"),
                alwaysTrue()
            )
            .ignoreDependency(
                nameMatching(".*\\.RestExceptionAdvice"),
                alwaysTrue()
            )
            .because("The boundaries between layers should be respected.")

    @ArchTest
    val layersShouldBeFreeOfCycles =
        SlicesRuleDefinition.slices()
            .matching("$BASE_PACKAGE.(**)..")
            .should().beFreeOfCycles()
            .because("Cycles should never occur.")
}
