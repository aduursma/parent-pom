package nl.rabobank.investments.architecture.rules

import com.tngtech.archunit.junit.AnalyzeClasses
import com.tngtech.archunit.junit.ArchTest
import com.tngtech.archunit.library.GeneralCodingRules.NO_CLASSES_SHOULD_THROW_GENERIC_EXCEPTIONS
import nl.rabobank.investments.architecture.rules.RulesConstants.BASE_PACKAGE

@AnalyzeClasses(packages = [BASE_PACKAGE])
class GeneralCodingRules {

    @ArchTest
    val noGenericExceptions = NO_CLASSES_SHOULD_THROW_GENERIC_EXCEPTIONS
}
