[![Build Status](https://dev.azure.com/raboweb/Investments/_apis/build/status/kyca-services-parent-pom?repoName=kyca-services-parent-pom&branchName=master)](https://dev.azure.com/raboweb/Investments/_build/latest?definitionId=21969&repoName=kyca-services-parent-pom&branchName=master)

# Introduction
This Maven POM is the root POM for all of our microservices.

In this POM we define the dependencies we use for _cross-cutting concerns_ shared by all the microservices we build, like:

* Security
* Authentication and Authorization
* Logging
* Test-driven documentation

---
> **_NOTE:_**  Dependencies, like database dependencies for example, which are not used in all of our microservices should never be part of this root POM, but be part of the microservice in question instead.
---

# Getting Started
Just add the root POM as a parent to the microservice Maven project you want to derive from the root POM, replacing the version number with the actual latest version number.

```
<parent>
    <groupId>nl.rabobank.investments.sales</groupId>
    <artifactId>kyca-services-parent-pom</artifactId>
    <version>...</version>
</parent>
```
