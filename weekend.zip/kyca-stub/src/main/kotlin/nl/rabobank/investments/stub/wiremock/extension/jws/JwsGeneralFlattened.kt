package nl.rabobank.investments.stub.wiremock.extension.jws

class JwsGeneralFlattened {
    var payload: ByteArray? = null
    var protected: ByteArray? = null
    var header: Any? = null
    var signature: ByteArray? = null
}
