package nl.rabobank.investments.stub.wiremock.extension.ah

import com.github.tomakehurst.wiremock.common.FileSource
import com.github.tomakehurst.wiremock.extension.Parameters
import com.github.tomakehurst.wiremock.extension.ResponseTransformer
import com.github.tomakehurst.wiremock.http.Request
import com.github.tomakehurst.wiremock.http.Response
import com.google.protobuf.Message
import nl.rabobank.authorisationhub.rpm.api.model.Limit
import nl.rabobank.authorisationhub.users.api.model.Customer
import nl.rabobank.authorisationhub.users.api.model.User
import nl.rabobank.investments.stub.wiremock.extension.ah.JsonFormatterParser.ahJsonFormatParser
import java.util.function.Supplier

const val APPLICATION_X_PROTOBUF = "application/x-protobuf"
const val X_PROTOBUF_MESSAGE_HEADER = "X-Protobuf-Message"

class ProtobufTransformer : ResponseTransformer() {

    override fun transform(
        request: Request?,
        response: Response,
        files: FileSource?,
        parameters: Parameters?
    ): Response {
        return if (response.headers.contentTypeHeader.containsValue(APPLICATION_X_PROTOBUF)) {
            Response.Builder.like(response)
                .but().body(toProtobufBody(response))
                .build()
        } else response
    }

    override fun getName(): String {
        return "protobuf-transformer"
    }

    override fun applyGlobally(): Boolean {
        return false
    }

    private fun toProtobufBody(response: Response): ByteArray? {
        val messageType: String = response.headers.getHeader(X_PROTOBUF_MESSAGE_HEADER).values()[0]
        val messageBuilderSupplier: Supplier<Message.Builder> = protobufBuilderMap!![messageType]
            ?: throw IllegalArgumentException("Unknown message type $messageType")

        val builder: Message.Builder = messageBuilderSupplier.get()
        try {
            jsonFormatParser!!.merge(response.bodyAsString, builder)
        } catch (e: com.google.protobuf.InvalidProtocolBufferException) {
            throw IllegalStateException("Error parsing json message of type $messageType", e)
        }
        return builder.build().toByteArray()
    }

    companion object {
        private val MODEL_USER: String = User::class.java.name
        private val MODEL_LIMIT: String = Limit::class.java.name
        private val MODEL_CUSTOMER: String = Customer::class.java.name

        val jsonFormatParser: com.google.protobuf.util.JsonFormat.Parser? = ahJsonFormatParser
        val protobufBuilderMap: Map<String, Supplier<Message.Builder>>?

        init {
            protobufBuilderMap = HashMap()
            protobufBuilderMap.put(MODEL_CUSTOMER, Customer::newBuilder)
            protobufBuilderMap.put(MODEL_USER, User::newBuilder)
            protobufBuilderMap.put(MODEL_LIMIT, Limit::newBuilder)
        }
    }
}
