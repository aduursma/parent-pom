package nl.rabobank.investments.stub.routes

import nl.rabobank.investments.stub.StubProperties
import org.slf4j.LoggerFactory
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Service
import org.springframework.util.MultiValueMap
import org.springframework.web.server.ResponseStatusException

@Service
class RouteMapper(private val properties: StubProperties) {

    private val log = LoggerFactory.getLogger(javaClass)

    fun mapExternalToInternalRoute(requestPath: String, queryParams: MultiValueMap<String, String>): String {
        val replacement = properties.routes.entries.findLast {
            requestPath.startsWith(it.key)
        }
        if (replacement != null) {
            val url = requestPath.replaceFirst(replacement.key, replacement.value)
            val queryParamsString = translateQueryParams(queryParams)
            return "$url$queryParamsString"
        } else {
            log.error("Route not implemented: $requestPath")
            throw ResponseStatusException(HttpStatus.NOT_IMPLEMENTED, "Route is not implemented")
        }
    }

    fun translateQueryParams(queryParams: MultiValueMap<String, String>): String {
        return if (queryParams.isEmpty()) {
            ""
        } else {
            val requestParams = queryParams.entries.joinToString(separator = "&") { entry ->
                val joined = entry.value.joinToString(separator = "&") { value ->
                    "${entry.key}=$value"
                }
                joined
            }
            "?$requestParams"
        }
    }
}
