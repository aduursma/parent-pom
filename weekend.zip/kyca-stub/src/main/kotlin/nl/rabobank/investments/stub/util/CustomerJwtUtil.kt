package nl.rabobank.investments.stub.util

import com.nimbusds.jose.JOSEException
import com.nimbusds.jose.JWSAlgorithm
import com.nimbusds.jose.JWSHeader
import com.nimbusds.jose.JWSSigner
import com.nimbusds.jose.crypto.RSASSASigner
import com.nimbusds.jwt.JWTClaimsSet
import com.nimbusds.jwt.SignedJWT
import org.apache.commons.io.IOUtils
import org.springframework.stereotype.Component
import java.security.KeyFactory
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.time.ZonedDateTime
import java.util.Base64
import java.util.Date
import javax.annotation.PostConstruct

private const val EXPIRATION_TIME_SIGNATURE = 120
private const val KEY_ID = "edge-router-v1"

@Component
class CustomerJwtUtil {

    private lateinit var rsaPrivateKey: RSAPrivateKey
    private lateinit var rsaPublicKey: RSAPublicKey

    @PostConstruct
    fun postConstruct() {
        val privateKeyBytes = Base64.getDecoder().decode(IOUtils.resourceToByteArray("/test_private_rsa_key"))
        rsaPrivateKey =
            KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(privateKeyBytes)) as RSAPrivateKey

        val publicKeyBytes = Base64.getDecoder().decode(IOUtils.resourceToByteArray("/test_public_rsa_key"))
        rsaPublicKey = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(publicKeyBytes)) as RSAPublicKey
    }

    fun jwtToken(relationId: String, klid: String): String {
        val claimsSet = JWTClaimsSet.Builder()
            .issueTime(Date())
            .expirationTime(Date.from(ZonedDateTime.now().plusSeconds(EXPIRATION_TIME_SIGNATURE.toLong()).toInstant()))
            .claim("authUserId", "X051873984000001143")
            .claim("authUserType", "CUSTOMER")
            .claim("authUserLevel", "2")
            .claim("authTicket", "23fadf2309aoiijassegg")
            .claim("siebelCustomerRelationId", relationId)
            .claim("siebelUserRelationId", relationId)
            .claim("edoKlid", klid)
            .claim("edoAgreementId", "000001143")
            .claim("edoUserId", "51873984")
            .claim("sources", listOf("RASS", "TA"))
            .build()
        val signedJWT = SignedJWT(
            JWSHeader.Builder(JWSAlgorithm.RS512)
                .keyID(KEY_ID)
                .build(),
            claimsSet
        )
        val signer: JWSSigner = RSASSASigner(rsaPrivateKey)
        try {
            signedJWT.sign(signer)
        } catch (e: JOSEException) {
            throw IllegalArgumentException(e)
        }
        return signedJWT.serialize()
    }

    fun getRsaPublicKey(): RSAPublicKey {
        return rsaPublicKey
    }

    fun getKeyId(): String {
        return KEY_ID
    }
}
