package nl.rabobank.investments.stub.util

import com.nimbusds.jose.JOSEException
import com.nimbusds.jose.JWSAlgorithm
import com.nimbusds.jose.JWSHeader
import com.nimbusds.jose.JWSSigner
import com.nimbusds.jose.crypto.RSASSASigner
import com.nimbusds.jwt.JWTClaimsSet
import com.nimbusds.jwt.SignedJWT
import org.apache.commons.io.IOUtils
import org.springframework.http.HttpStatus
import org.springframework.stereotype.Component
import org.springframework.web.server.ResponseStatusException
import java.security.KeyFactory
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import java.time.LocalDateTime
import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Base64
import java.util.Date
import javax.annotation.PostConstruct

val employees = listOf(
    Employee(
        "7000115606", "V.Vermogensbeheerder", "3000351915",
        listOf(
            "INVESTMENTS;mandates-view", "INVESTMENTS;mandates-edit",
            "INVESTMENTS;offers-view", "INVESTMENTS;offers-edit",
            "INVESTMENTS;subscriptions-view", "INVESTMENTS;subscriptions-edit",
            "MUI-CRZB;IVO-CRZB-Nieuw-functie", "MUI-CRZB;IVO-CRZB-Wijzigen-functie",
            "MUI-CRZB;IVO-CRZB-Beeindigen-functie"
        ),
        emptyList()
    ),
    Employee(
        "7000115607", "V.Vermogensbeheerder", "3000351915",
        listOf(
            "MUI-CRZB;IVO-CRZB-Wijzigen-functie",
            "MUI-CRZB;IVO-CRZB-Beeindigen-functie",
            "MUI-CRZB;IVO-CRZB-Nieuw-functie"
        ),
        listOf(
            "InvsalesmedAgreementsView",
            "InvsalesmedAgreementsEdit",
            "InvsalesmedPBAGRMENTSVIEW",
            "InvsalesmedPBAGRMENTSEDIT",
            "InvsalesmedNPBAGRMENTSVIEW",
            "InvsalesmedNPBAGRMENTSEDIT",
            "InvsalesmedPBSUBSCRVIEW",
            "InvsalesmedPBSUBSCREDIT",
            "InvsalesmedNPBSUBSCRVIEW",
            "InvsalesmedNPBSUBSCREDIT",
            "InvsalesmedPBKECVIEW",
            "InvsalesmedPBKECEDIT",
            "InvsalesmedNPBKECVIEW",
            "InvsalesmedNPBKECEDIT",
        )
    ),
    Employee(
        "7000118439", "V.Vermogensbeheerder", "3000351915",
        listOf("INVESTMENTS;mandates-view", "INVESTMENTS;offers-view", "INVESTMENTS;subscriptions-view"), emptyList()
    ),
    Employee(
        "7000118900", "O.Opser", "3000351915",
        emptyList(), listOf("InvsalesmedOps")
    )
)

private const val EXPIRATION_TIME_SIGNATURE = 120
private const val KEY_ID = "edge-router-v1"

@Component
class EmployeeJwtUtil {
    private lateinit var rsaPrivateKey: RSAPrivateKey
    private lateinit var rsaPublicKey: RSAPublicKey

    @PostConstruct
    fun postConstruct() {
        val privateKeyBytes = Base64.getDecoder().decode(IOUtils.resourceToByteArray("/test_private_rsa_key"))
        rsaPrivateKey =
            KeyFactory.getInstance("RSA").generatePrivate(PKCS8EncodedKeySpec(privateKeyBytes)) as RSAPrivateKey

        val publicKeyBytes = Base64.getDecoder().decode(IOUtils.resourceToByteArray("/test_public_rsa_key"))
        rsaPublicKey = KeyFactory.getInstance("RSA").generatePublic(X509EncodedKeySpec(publicKeyBytes)) as RSAPublicKey
    }

    fun getRsaPublicKey(): RSAPublicKey {
        return rsaPublicKey
    }

    fun getKeyId(): String {
        return KEY_ID
    }

    fun jwtToken(employeeId: String, timeout: Int = EXPIRATION_TIME_SIGNATURE): String {
        val employee =
            employees.find { it.employeeId == employeeId } ?: throw ResponseStatusException(HttpStatus.BAD_REQUEST)

        val claims: MutableMap<String, Any> = HashMap()
        claims["upn"] = "dummy@rabobank.nl"
        claims["unique_name"] = "RABONETEU\\${employee.name}"
        claims["auth_time"] = LocalDateTime.now().format(DateTimeFormatter.ISO_DATE_TIME)
        claims["http://schemas.rabobankinternational.com/identity/claims/riRaboID"] = employee.employeeId
        claims["http://schemas.rabobankinternational.com/identity/claims/DisplayName"] = employee.name
        claims["http://schemas.rabobankinternational.com/identity/claims/raboDN"] =
            "rabobankid=${employee.employeeId},organizationID=${employee.organisationId},o=Rabobank,c=NL"
        claims["http://schemas.rabobankinternational.com/identity/claims/raboDepartment"] = "SYS AB CD North"

        if (employee.roles.isNotEmpty()) {
            claims["role"] = employee.roles.toTypedArray()
        } else {
            val rwaFunctions = employee.rwaFunctions.map { "$it;${employee.organisationId}" }.toTypedArray()
            claims["http://schemas.rabobankinternational.com/identity/claims/ApplicationProfileFull"] = rwaFunctions
        }
        return createJwtToken(claims, timeout)
    }

    fun createJwtToken(claims: Map<String, Any>, timeout: Int): String {
        val claimsBuilder = JWTClaimsSet.Builder()
            .issueTime(Date())
            .expirationTime(Date.from(ZonedDateTime.now().plusSeconds(timeout.toLong()).toInstant()))
        for ((key, value) in claims) {
            claimsBuilder.claim(key, value)
        }
        val signedJWT = SignedJWT(
            JWSHeader.Builder(JWSAlgorithm.RS512).keyID(KEY_ID).build(),
            claimsBuilder.build()
        )
        val signer: JWSSigner = RSASSASigner(rsaPrivateKey)
        try {
            signedJWT.sign(signer)
        } catch (e: JOSEException) {
            throw IllegalArgumentException(e)
        }
        return signedJWT.serialize()
    }
}

data class Employee(
    val employeeId: String,
    val name: String,
    val organisationId: String,
    val rwaFunctions: List<String>,
    val roles: List<String>
)
