package nl.rabobank.investments.stub.controller

import com.nimbusds.jose.jwk.JWKSet
import com.nimbusds.jose.jwk.RSAKey
import nl.rabobank.investments.stub.StubProperties
import nl.rabobank.investments.stub.util.EmployeeJwtUtil
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.ResponseBody
import org.springframework.web.bind.annotation.RestController

@RestController
class JwkController(val employeeJwtUtil: EmployeeJwtUtil, val properties: StubProperties) {

    @GetMapping("jwk")
    @ResponseBody
    fun getJwk(): MutableMap<String, Any> {
        val jwk = RSAKey.Builder(employeeJwtUtil.getRsaPublicKey()).keyID(employeeJwtUtil.getKeyId()).build()
        return JWKSet(jwk).toJSONObject()
    }
}
