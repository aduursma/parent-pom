package nl.rabobank.investments.stub.controller

import org.springframework.http.HttpStatus
import org.springframework.http.ResponseEntity
import org.springframework.util.LinkedMultiValueMap
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.RequestParam
import org.springframework.web.bind.annotation.RestController
import java.net.URI

@RestController
class LoginController {
    @GetMapping("/login")
    fun login(
        @RequestParam("employee_id", required = false) employeeId: String?,
        @RequestParam("relation_id", required = false) relationId: String?,
        @RequestParam("redirect_url", required = false) redirectUrl: String?
    ): ResponseEntity<String> {
        return if (employeeId != null) {
            getEmployeeResponse(employeeId, redirectUrl)
        } else {
            getCustomerResponse(relationId!!, redirectUrl)
        }
    }

    private fun getEmployeeResponse(employeeId: String, redirectUrl: String?): ResponseEntity<String> {
        return if (redirectUrl != null && redirectUrl.isNotEmpty()) {
            ResponseEntity
                .status(HttpStatus.TEMPORARY_REDIRECT)
                .header("Set-Cookie", "x-test-employee=$employeeId")
                .header("Set-Cookie", "x-test-user=old;Expires=Tue, 15 Jan 2013 21:47:38 GMT")
                .location(URI.create(redirectUrl))
                .build()
        } else {
            val headers = LinkedMultiValueMap<String, String>()
            headers.add("Set-Cookie", "x-test-employee=$employeeId")
            headers.add("Set-Cookie", "x-test-user=old;Expires=Tue, 15 Jan 2013 21:47:38 GMT")
            ResponseEntity("Added cookie for employee id $employeeId", headers, HttpStatus.OK)
        }
    }

    private fun getCustomerResponse(relationId: String, redirectUrl: String?): ResponseEntity<String> {
        return if (redirectUrl != null && redirectUrl.isNotEmpty()) {
            ResponseEntity
                .status(HttpStatus.TEMPORARY_REDIRECT)
                .header("Set-Cookie", "x-test-user=$relationId")
                .header("Set-Cookie", "x-test-employee=old;Expires=Tue, 15 Jan 2013 21:47:38 GMT")
                .location(URI.create(redirectUrl))
                .build()
        } else {
            val headers = LinkedMultiValueMap<String, String>()
            headers.add("Set-Cookie", "x-test-user=$relationId")
            headers.add("Set-Cookie", "x-test-employee=old;Expires=Tue, 15 Jan 2013 21:47:38 GMT")
            ResponseEntity("Added cookie for user id $relationId", headers, HttpStatus.OK)
        }
    }
}
