package nl.rabobank.investments.stub.controller

import nl.rabobank.investments.stub.util.CustomerJwtUtil
import nl.rabobank.investments.stub.util.EmployeeJwtUtil
import org.slf4j.LoggerFactory
import org.springframework.http.HttpStatus
import org.springframework.web.bind.annotation.GetMapping
import org.springframework.web.bind.annotation.PathVariable
import org.springframework.web.bind.annotation.RequestMapping
import org.springframework.web.bind.annotation.RestController
import org.springframework.web.server.ResponseStatusException

private const val TOKEN_TIMEOUT = 7200
private const val EMPLOYEE_ID_LENGTH = 10
private const val CUSTOMER_ID_LENGTH = 15

@RestController
@RequestMapping("/jwt")
class JwtController(val employeeJwtUtil: EmployeeJwtUtil, val customerJwtUtil: CustomerJwtUtil) {

    private val log = LoggerFactory.getLogger(javaClass)

    @GetMapping("/{employee_or_customer_id}")
    fun getOrder(@PathVariable("employee_or_customer_id") employeeOrCustomerId: String): String {
        return when (employeeOrCustomerId.length) {
            EMPLOYEE_ID_LENGTH -> "\"${employeeJwtUtil.jwtToken(employeeOrCustomerId, TOKEN_TIMEOUT)}\""
            CUSTOMER_ID_LENGTH -> "\"${customerJwtUtil.jwtToken(employeeOrCustomerId, employeeOrCustomerId)}\""
            else -> {
                log.warn("A JWT token was requested for invalid employee/customer id: $employeeOrCustomerId")
                throw ResponseStatusException(HttpStatus.BAD_REQUEST)
            }
        }
    }
}
