package nl.rabobank.investments.stub.wiremock.extension.ah

import com.google.protobuf.Descriptors.FieldDescriptor
import com.google.protobuf.util.JsonFormat
import com.google.protobuf.util.JsonFormat.Parser
import com.google.protobuf.util.JsonFormat.Printer
import nl.rabobank.authorisationhub.rpm.api.model.Limit
import nl.rabobank.authorisationhub.users.api.model.Arrangement
import nl.rabobank.authorisationhub.users.api.model.Customer
import nl.rabobank.authorisationhub.users.api.model.User

object JsonFormatterParser {

    val ahJsonFormatPrinter: Printer?
    val ahJsonFormatParser: Parser?

    private val fieldsToAlwaysOutput: Set<FieldDescriptor>?

    init {
        fieldsToAlwaysOutput = HashSet()
        fieldsToAlwaysOutput.add(User.getDescriptor().findFieldByName("customers"))
        fieldsToAlwaysOutput.add(Customer.getDescriptor().findFieldByName("authorisations"))
        fieldsToAlwaysOutput.add(Arrangement.getDescriptor().findFieldByName("authorisations"))
        fieldsToAlwaysOutput.addAll(Limit.getDescriptor().fields)

        ahJsonFormatPrinter = JsonFormat.printer()
            .omittingInsignificantWhitespace()
            .includingDefaultValueFields(fieldsToAlwaysOutput)
            .preservingProtoFieldNames()

        ahJsonFormatParser = JsonFormat.parser()
    }
}
