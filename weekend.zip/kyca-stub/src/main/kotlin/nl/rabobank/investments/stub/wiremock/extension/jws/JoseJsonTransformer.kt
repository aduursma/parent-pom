package nl.rabobank.investments.stub.wiremock.extension.jws

import com.github.tomakehurst.wiremock.client.ResponseDefinitionBuilder
import com.github.tomakehurst.wiremock.common.FileSource
import com.github.tomakehurst.wiremock.extension.Parameters
import com.github.tomakehurst.wiremock.extension.ResponseDefinitionTransformer
import com.github.tomakehurst.wiremock.http.Request
import com.github.tomakehurst.wiremock.http.ResponseDefinition

private const val SUCCESS_STATUS_START = 200
private const val SUCCESS_STATUS_END = 299

class JoseJsonTransformer : ResponseDefinitionTransformer() {

    override fun transform(
        request: Request?,
        responseDefinition: ResponseDefinition,
        files: FileSource?,
        parameters: Parameters?
    ): ResponseDefinition {
        val status = responseDefinition.status
        val body = if (responseDefinition.bodyFileName != null) {
            files!!.getTextFileNamed(responseDefinition.bodyFileName).readContentsAsString()
        } else if (responseDefinition.jsonBody != null) {
            responseDefinition.jsonBody.toPrettyString()
        } else {
            responseDefinition.body
        }

        val encodedBody = if (body != null && status >= SUCCESS_STATUS_START && status <= SUCCESS_STATUS_END) {
            CONVERTER.convert(body)
        } else {
            body
        }
        return ResponseDefinitionBuilder()
            .withHeaders(responseDefinition.headers)
            .withBody(encodedBody)
            .withStatus(status)
            .build()
    }

    override fun getName(): String {
        return "jose-json-transformer"
    }

    override fun applyGlobally(): Boolean {
        return false
    }

    companion object {
        private val CONVERTER = JwsSignatureConverter()
    }
}
