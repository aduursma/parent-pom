package nl.rabobank.investments.stub

import org.springframework.boot.context.properties.ConfigurationProperties
import org.springframework.boot.context.properties.ConstructorBinding
import java.util.TreeMap

@ConstructorBinding
@ConfigurationProperties(prefix = "routes")
class StubProperties(
    val routes: TreeMap<String, String>
)
