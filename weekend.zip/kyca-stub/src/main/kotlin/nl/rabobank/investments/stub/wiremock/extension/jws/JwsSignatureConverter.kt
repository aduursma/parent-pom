package nl.rabobank.investments.stub.wiremock.extension.jws

import com.fasterxml.jackson.core.JsonProcessingException
import com.fasterxml.jackson.databind.ObjectMapper
import com.nimbusds.jose.JOSEException
import com.nimbusds.jose.JWSAlgorithm
import com.nimbusds.jose.JWSHeader
import com.nimbusds.jose.JWSObject
import com.nimbusds.jose.JWSSigner
import com.nimbusds.jose.Payload
import com.nimbusds.jose.crypto.RSASSASigner
import com.nimbusds.jose.util.IOUtils
import org.bouncycastle.util.io.pem.PemReader
import org.springframework.core.io.ClassPathResource
import java.io.IOException
import java.io.StringReader
import java.nio.charset.StandardCharsets
import java.security.KeyFactory
import java.security.NoSuchAlgorithmException
import java.security.PrivateKey
import java.security.spec.InvalidKeySpecException
import java.security.spec.PKCS8EncodedKeySpec
import java.text.ParseException

private const val PRIVATE_KEY_FILE_NAME = "wiremock-stub-pk.pkcs8"
private const val BASE_64_PARTS_PROTECTED_INDEX = 0
private const val BAE_64_PARTS_PAYLOAD_INDEX = 1
private const val BASE_64_PARTS_SIGNATURE_INDEX = 2

class JwsSignatureConverter {

    private val jwsPrivateKey: PrivateKey
    private val jwsAlgorithm: JWSAlgorithm
    private val objectMapper = ObjectMapper()

    @Suppress("ThrowsCount")
    private fun readPrivateKey(): PrivateKey {
        return try {
            val inputStream = ClassPathResource(PRIVATE_KEY_FILE_NAME).inputStream
            val privateKeyAsString = IOUtils.readInputStreamToString(inputStream, StandardCharsets.UTF_8)
            val pem = PemReader(StringReader(privateKeyAsString)).readPemObject()
            val keyFactory = KeyFactory.getInstance("RSA")
            val ks = PKCS8EncodedKeySpec(pem.content)
            keyFactory.generatePrivate(ks)
        } catch (e: IOException) {
            throw IllegalStateException(e)
        } catch (e: NoSuchAlgorithmException) {
            throw IllegalStateException(e)
        } catch (e: InvalidKeySpecException) {
            throw IllegalStateException(e)
        }
    }

    @Suppress("ThrowsCount")
    fun convert(input: String): String {
        // set payload
        val rfc7515Result = JwsGeneralFlattened()
        val serializedJwsObject: String
        val payloadAsBytes = input.toByteArray(StandardCharsets.UTF_8)
        val jwsHeader = JWSHeader.Builder(jwsAlgorithm).build()
        return try {
            val jwsObject = JWSObject(jwsHeader, Payload(payloadAsBytes))
            val jwsSigner: JWSSigner = RSASSASigner(jwsPrivateKey)
            jwsObject.sign(jwsSigner)

            // Serialize jwsObject into String
            serializedJwsObject = jwsObject.serialize()
            // Split it into JOSE Base64URL-encoded parts
            val base64parts = JWSObject.split(serializedJwsObject)

            // Build the RFC7515-compliant object
            rfc7515Result.protected = base64parts[BASE_64_PARTS_PROTECTED_INDEX].decode()
            rfc7515Result.payload = base64parts[BAE_64_PARTS_PAYLOAD_INDEX].decode()
            rfc7515Result.signature = base64parts[BASE_64_PARTS_SIGNATURE_INDEX].decode()
            objectMapper.writeValueAsString(rfc7515Result)
        } catch (e: JOSEException) {
            throw IllegalStateException(e)
        } catch (e: ParseException) {
            throw IllegalStateException(e)
        } catch (e: JsonProcessingException) {
            throw IllegalStateException(e)
        }
    }

    init {
        jwsPrivateKey = readPrivateKey()
        jwsAlgorithm = JWSAlgorithm.parse("RS256")
    }
}
