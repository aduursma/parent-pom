package nl.rabobank.investments.stub.wiremock

import com.github.tomakehurst.wiremock.WireMockServer
import com.github.tomakehurst.wiremock.core.WireMockConfiguration
import com.github.tomakehurst.wiremock.extension.responsetemplating.ResponseTemplateTransformer
import nl.rabobank.investments.stub.wiremock.extension.CrmiRequestMatcher
import nl.rabobank.investments.stub.wiremock.extension.ah.ProtobufTransformer
import nl.rabobank.investments.stub.wiremock.extension.jws.JoseJsonTransformer
import org.apache.commons.lang3.RegExUtils
import org.apache.commons.lang3.StringUtils
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component
import wiremock.com.github.jknack.handlebars.Helper
import wiremock.com.github.jknack.handlebars.Options
import wiremock.com.github.jknack.handlebars.TagType

@Component
class WireMockServerManager {

    private val log = LoggerFactory.getLogger(javaClass)
    private val wiremockServers = mutableListOf<WireMockServer>()

    fun startWireMockServer(classpathRoot: String, port: Int) {
        val wireMockConfiguration = WireMockConfiguration.options().port(port)
        wireMockConfiguration.extensions(CrmiRequestMatcher::class.java)
        wireMockConfiguration.extensions(responseTemplateTransformer())
        wireMockConfiguration.extensions(JoseJsonTransformer::class.java)
        wireMockConfiguration.extensions(ProtobufTransformer::class.java)
        wireMockConfiguration.usingFilesUnderClasspath(classpathRoot)

        val wireMockServer = WireMockServer(wireMockConfiguration)
        wireMockServer.start()
        wiremockServers.add(wireMockServer)
        log.info("Started wiremock server on port $port for stub on classpath location: $classpathRoot")
    }

    fun stopWireMockServers() {
        wiremockServers.forEach {
            it.stop()
            log.info("Stopped wiremock server on port ${it.port()}")
        }
    }

    @Suppress("SpreadOperator", "kotlin:S3776")
    private fun responseTemplateTransformer(): ResponseTemplateTransformer {
        val stringContainsHelper = Helper { value: String, options: Options ->
            val contains = StringUtils.contains(value, options.param(0, ""))
            if (options.tagType === TagType.SECTION) {
                if (contains) options.fn() else options.inverse()
            } else {
                if (contains) options.hash("yes", true) else options.hash<Any>("no", false)
            }
        }

        val stringContainsAnyHelper = Helper { value: String?, options: Options ->
            var commaSeparatedSearchString = options.param(0, "")
            commaSeparatedSearchString = RegExUtils.removeAll(commaSeparatedSearchString, "s/\\s+//g")
            val searchStrings = StringUtils.split(commaSeparatedSearchString, ",")
            val contains = StringUtils.containsAny(value, *searchStrings)
            if (options.tagType === TagType.SECTION) {
                if (contains) options.fn() else options.inverse()
            } else {
                if (contains) options.hash("yes", true) else options.hash<Any>("no", false)
            }
        }

        val helpers: MutableMap<String, Helper<*>> = HashMap()
        helpers["contains"] = stringContainsHelper
        helpers["containsAny"] = stringContainsAnyHelper

        return ResponseTemplateTransformer(false, helpers)
    }
}
