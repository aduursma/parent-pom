package nl.rabobank.investments.stub.wiremock.extension

import com.github.tomakehurst.wiremock.extension.Extension
import nl.rabobank.investments.stub.wiremock.extension.ah.ProtobufTransformer
import nl.rabobank.investments.stub.wiremock.extension.jws.JoseJsonTransformer
import org.springframework.cloud.contract.verifier.dsl.wiremock.WireMockExtensions

class CustomWireMockExtensions : WireMockExtensions {
    @Override
    override fun extensions(): List<Extension> {
        println("ADD EXTENSIONS")
        return listOf(CrmiRequestMatcher(), JoseJsonTransformer(), ProtobufTransformer())
    }
}
