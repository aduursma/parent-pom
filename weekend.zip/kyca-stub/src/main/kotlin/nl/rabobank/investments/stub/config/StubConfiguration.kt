package nl.rabobank.investments.stub.config

import nl.rabobank.investments.stub.routes.RouteMapper
import nl.rabobank.investments.stub.util.CustomerJwtUtil
import nl.rabobank.investments.stub.util.EmployeeJwtUtil
import nl.rabobank.investments.stub.wiremock.WireMockServerManager
import org.springframework.cloud.gateway.route.RouteLocator
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import java.net.URI
import java.util.Optional
import javax.annotation.PostConstruct
import javax.annotation.PreDestroy

private const val STUB_PORT_API = 8082
private const val STUB_PORT_CRMI = 8083
private const val STUB_PORT_AUTHORISATION_HUB = 8085
private const val STUB_PORT_PAYMENTS = 8086
private const val STUB_PORT_ESB = 8087

@Configuration
class StubConfiguration(val wireMockServerManager: WireMockServerManager) {
    @PostConstruct
    fun startWiremockServers() {
        wireMockServerManager.startWireMockServer("stubs/api", STUB_PORT_API)
        wireMockServerManager.startWireMockServer("stubs/crmi", STUB_PORT_CRMI)
        wireMockServerManager.startWireMockServer("stubs/esb", STUB_PORT_ESB)
        wireMockServerManager.startWireMockServer("stubs/authorisation-hub", STUB_PORT_AUTHORISATION_HUB)
        wireMockServerManager.startWireMockServer("stubs/payments", STUB_PORT_PAYMENTS)
    }

    @PreDestroy
    fun stopWiremockServers() {
        wireMockServerManager.stopWireMockServers()
    }

    @Bean
    fun routeLocator(
        builder: RouteLocatorBuilder,
        employeeJwtUtil: EmployeeJwtUtil,
        customerJwtUtil: CustomerJwtUtil,
        routeMapper: RouteMapper
    ): RouteLocator {
        return builder.routes()
            .route("all") { r ->
                r.path("/**").filters { filter ->
                    filter.removeRequestHeader("X-Forwarded-Host")
                    filter.removeRequestHeader("X-Forwarded-Port")
                    filter.removeRequestHeader("X-Forwarded-Prefix")
                    filter.removeRequestHeader("X-Forwarded-Proto")
                    filter.changeRequestUri { webExchange ->
                        val requestPath = webExchange.request.path.toString()
                        val queryParams = webExchange.request.queryParams
                        val url = routeMapper.mapExternalToInternalRoute(requestPath, queryParams)
                        Optional.of(URI(url))
                    }
                    filter.filter { exchange, chain ->
                        val mutateRequest = exchange.request.mutate()
                        val testEmployeeIds = exchange.request.cookies["x-test-employee"]
                        val testUserRelationIds = exchange.request.cookies["x-test-user"]
                        if (testEmployeeIds != null && testEmployeeIds.isNotEmpty()) {
                            val testEmployeeId = testEmployeeIds[0].value
                            mutateRequest.header("x-auth-employee", employeeJwtUtil.jwtToken(testEmployeeId))
                        } else if (testUserRelationIds != null && testUserRelationIds.isNotEmpty()) {
                            val userRelationId = testUserRelationIds[0].value
                            mutateRequest.header(
                                "x-auth-user",
                                customerJwtUtil.jwtToken(userRelationId, userRelationId)
                            )
                        }
                        chain.filter(exchange.mutate().request(mutateRequest.build()).build())
                    }
                }.uri("http://dummy")
            }
            .build()
    }
}
