# Introduction 
Our apps on (P)CF use a Config Server, named `kyca-config-server`, for storing and retrieving configuration properties and secrets.

This project contains both the configuration to create and maintain the Config Server and the actual configuration properties used by the Config Server.

# Getting Started
## Prerequisites
To be able to create the Config Server the Cloud Foundry CLI must be installed. 

If you haven't done so already, you can download and install the Cloud Foundry CLI from [here](https://github.com/cloudfoundry/cli/releases).

Check to see if the installation was successful with the following command:
```
cf --version
```
The version of the installed Cloud Foundry CLI should be displayed.

## Optional for CF
To be able to interact with the Config Server and maintain secrets stored within the CredHub runtime you can install the Cloud Foundry Services Plugin by following the instructions [here](https://confluence.dev.rabobank.nl/display/IT4IT/Cloud+Foundry+Config+Server#CloudFoundryConfigServer-Installingthecfs-plugin).

## Optional for PCF
To be able to interact with the Config Server and maintain secrets stored within the CredHub runtime you can install the Spring Cloud Services Plugin by following the instructions [here](https://docs.pivotal.io/spring-cloud-services/3-1/common/cf-cli-plugin.html).

Otherwise, the Config Server also provides a `/secrets` endpoint that can be used to store and remove secrets. Click [here](https://docs.pivotal.io/spring-cloud-services/3-1/common/config-server/managing-secrets-with-credhub.html) for more information.

Synchronizing Git mirrors and restaging apps can be done from the App Manager's dashboard as well.

## App Configuration Structure
All app configuration can be found in the `config` folder. 

The configuration structure we use is as follows:
```
application.properties (1)
application-devtest.properties (2)
application-production.properties (3)
{application}/{application}-devtest.properties (4)
{application}/{application}-production.properties (5)
```

The main app configuration should come from the `application.properties` file within the app itself.

The Config Server should be used to set or override only those properties which are either global defaults or directly related to the environment in which the app is deployed.

(1) Properties in the `application.properties` file are shared by all apps in all environments.

(2) Properties in the `application-devtest.properties` file are shared by all apps in the DevTest environment.

(3) Properties in the `application-production.properties` file are shared by all apps in the Production environment.

(4) Properties in the `{application}/{application}-devtest.properties` file are specific to the app in the DevTest environment.

(5) Properties in the `{application}/{application}-production.properties` file are specific to the app in the Production environment.

## App Secrets Structure
All app secrets will follow a similar structure as the configuration properties.

The secrets structure we use is as follows:
```
application/cloud/master/{secret} (1)
application/devtest/master/{secret} (2)
application/production/master/{secret} (3)
{application}/devtest/{secret} (4)
{application}/production/{secret} (5)
```

(1) Secrets in `application/cloud/master` are shared by all apps in all environments (all apps have the `cloud` profile set as active profile).

(2) Secrets in `application/devtest/master` are shared by all apps in the DevTest environment.

(3) Secrets in `application/production/master` are shared by all apps in the Production environment.

(4) Secrets in `{application}/devtest` are specific to the app in the DevTest environment.

(5) Secrets in `{application}/production` are specific to the app in the Production environment.

# Usage
Before running any of the commands in the next sections, make sure you are logged in in the (P)CF environment and space you want to target.

## Config Server
### Configuration file
The `config-server.json` file in the root of this project contains the Config Server's configuration:
```
{
  "git": {
    "uri": "https://dev.azure.com/raboweb/Investments/_git/kyca-config-server", (1)
    "searchPaths": "/config,/config/{application}", (2)
    "username": "raboweb", (3)
    "password": "<TOKEN>" (4)
  }
}
```

(1) The GIT repository where the configuration files for use in the Config Server are stored.

(2) The location of the configuration files within the GIT repository 

(3) Since we are using a Personal Access Token (PAT), the username can be anything. Typically the organization name in Azure DevOps (raboweb) is used.

(4) Contains the Personal Access Token (PAT) used to access the GIT repository from within the Config Server. For obvious reasons the Personal Access Token (PAT) is not stored in the GIT repository. So, before creating or updating the Config Server don't forget to replace the dummy TOKEN with the actual Personal Access Token (PAT)

### Create the Config Server
To create the Config Server run the following command from the root of the project:
```
cf create-service p.config-server standard kyca-config-server -c config-server.json
```

The `config-server.json` file contains the Config Server's settings to use.

---
> **_NOTE:_**  The `searchPaths` property has been set to match the config folder in which we store our app configuration.
---

### Update the Config Server
To update the Config Server's settings (after changing the Git repository for example) run the following command from the root of the project:
```
cf update-service kyca-config-server -c config-server.json
```

### Upgrade the Config Server
To upgrade the Config Server after a new version has become available run the following command:
```
cf update-service kyca-config-server -c '{"upgrade": true}'
```

### Delete the Config Server
To delete the Config Server entirely run the following command:
```
cf delete-service kyca-config-server'
```

## Secrets on CF
### Add a secret
To add a secret (for example a secret available to all apps in all environments stored in the `mySecret` property) to the CredHub runtime run the following command:
```
cf add-config-server-secrets kyca-config-server -a application -p cloud -l master '{"mySecret": "raadjenooit"}'
```

---
> **_NOTE:_**  In a Windows command prompt you cannot use single quotes, so the JSON becomes:
> ````
> cf add-config-server-secrets kyca-config-server -a application -p cloud -l master "{\"mySecret\": \"raadjenooit\"}"
> ````
---

### Update a secret
To update a secret you just add the secret again with a different value.

### Remove a secret
To remove a secret (for example the secret from the previous example) from the CredHub runtime run the following command:
```
cf delete-config-server-secrets kyca-config-server -a application -p cloud -l master mySecret
```

### Listing secrets
You cannot list the actual secrets from the CredHub runtime, but you can list their names. This will allow you to verify if a specific secret is defined.

Run the following command:
```
cf list-config-server-secrets kyca-config-server -a application -p cloud -l master mySecret
```

## Making a change available to running apps
Whenever any configuration, properties or secrets changes have been made to Config Server, these changes will be available immediately.

### Synchronize Git mirrors
On CF there is no need to synchronize any mirrors, since there are none.

### Restage applications
On CF there is no need to restage applications, since changes are available to the applications immediately.

## Secrets on PCF
### Add a secret
To add a secret (for example a secret available to all apps in all environments stored in the `mySecret` property) to the CredHub runtime run the following command:
```
cf config-server-add-credhub-secret kyca-config-server application/cloud/master/mySecret '{"mySecret": "raadjenooit"}'
```

---
> **_NOTE:_**  In a Windows command prompt you cannot use single quotes, so the JSON becomes:
> ````
> cf config-server-add-credhub-secret kyca-config-server application/cloud/master/mySecret "{\"mySecret\": \"raadjenooit\"}"
> ````
---

Alternatively, you can add the secret using the `/secrets` endpoint:
```
curl https://config-server-93daf099-2632-4b49-b72a-27f181464007.apps.cfd06.rabobank.nl/secrets/application/cloud/master/mySecret \
-H "Authorization: $(cf oauth-token)" -X PUT --data '{"mySecret": "raadjenooit"}' \
-H "Content-Type: application/json" -i
```

### Update a secret
To update a secret you just add the secret again with a different value.

### Remove a secret
To remove a secret (for example the secret from the previous example) from the CredHub runtime run the following command:
```
cf config-server-remove-credhub-secret kyca-config-server application/cloud/master/mySecret
```

Alternatively, you can remove the secret using the `/secrets` endpoint:
```
curl https://config-server-93daf099-2632-4b49-b72a-27f181464007.apps.cfd06.rabobank.nl/secrets/application/cloud/master/mySecret \
-H "Authorization: $(cf oauth-token)" -X DELETE -i
```

## Making a change available to running apps on PCF
Whenever any configuration, properties or secrets changes have been made to Config Server, these changes will also have to be made available to the running Config Server itself and the deployed apps in the PCF environment.

### Synchronize Git mirrors
There is a Git mirror service in front of all Config Servers running in a PCF environment.

This service needs to be synchronized with the actual changes (i.e. the changes will have to be fetched from the Git repository) which can be done by running the following command:
```
cf config-server-sync-mirrors kyca-config-server
```

### Restage applications
Now, that the Git mirrors are synchronized all apps using the Config Server must be restaged. Restaging an app will cause it to fetch the configuration from the Config Server again.

The following command must be executed for all relevant apps:
```
cf restage <app-name>  \\ where <app-name> is the name of the app to restage
```
