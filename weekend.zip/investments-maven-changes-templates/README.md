[![Build Status](https://dev.azure.com/raboweb/Investments/_apis/build/status/kyca-maven-changes-templates?repoName=kyca-maven-changes-templates&branchName=master)](https://dev.azure.com/raboweb/Investments/_build/latest?definitionId=24868&repoName=kyca-maven-changes-templates&branchName=master)

# Introduction
This project contains the email template(s) we use for sending release announcements.
