package nl.rabobank.investments.commons.security.domain

import nl.rabobank.investments.commons.util.TestUtil
import org.assertj.core.api.Assertions
import org.junit.jupiter.api.Test

class CustomerPrincipalTest {

    @Test
    fun `test getName`() {
        Assertions.assertThat(TestUtil.getCustomerPrincipal().name).isEmpty()
    }
}
