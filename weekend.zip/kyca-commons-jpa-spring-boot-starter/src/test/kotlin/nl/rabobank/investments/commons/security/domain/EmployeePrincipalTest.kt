package nl.rabobank.investments.commons.security.domain

import nl.rabobank.investments.commons.util.TestUtil
import org.assertj.core.api.Assertions
import org.junit.jupiter.api.Test

class EmployeePrincipalTest {

    @Test
    fun `test getName`() {
        Assertions.assertThat(TestUtil.getEmployeePrincipal().name).isEqualTo("TEST")
    }
}
