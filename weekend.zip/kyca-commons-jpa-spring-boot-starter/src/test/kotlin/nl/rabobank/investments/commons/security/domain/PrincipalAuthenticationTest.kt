package nl.rabobank.investments.commons.security.domain

import nl.rabobank.investments.commons.util.TestUtil
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test

class PrincipalAuthenticationTest {
    private val customerPrincipal = TestUtil.getCustomerPrincipal()
    private val employeePrincipal = TestUtil.getEmployeePrincipal()
    private val customerPrincipalAuthentication = PrincipalAuthentication(
        "token", customerPrincipal, Role.CUSTOMER
    )
    private val employeePrincipalAuthentication = PrincipalAuthentication(
        "token", employeePrincipal, Role.EMPLOYEE, listOf("AuthorityABC")
    )

    @Test
    fun `test getCredentials`() {
        assertThat(customerPrincipalAuthentication.credentials).isEqualTo("token")
    }

    @Test
    fun `test getPrincipal`() {
        assertThat(customerPrincipalAuthentication.principal).isEqualTo(customerPrincipal)
    }

    @Test
    fun `test hasRole success`() {
        assertThat(customerPrincipalAuthentication.hasRole(Role.CUSTOMER)).isTrue
    }

    @Test
    fun `test hasRole failure`() {
        assertThat(customerPrincipalAuthentication.hasRole(Role.EMPLOYEE)).isFalse
    }

    @Test
    fun `test hasAuthority success`() {
        assertThat(customerPrincipalAuthentication.hasAuthority("ROLE_CUSTOMER")).isTrue
    }

    @Test
    fun `test hasAuthority failure`() {
        assertThat(customerPrincipalAuthentication.hasAuthority("ROLE_EMPLOYEE")).isFalse
    }

    @Test
    fun `test hasAuthority for principal created with additional authorities`() {
        assertThat(employeePrincipalAuthentication.hasAuthority("ROLE_EMPLOYEE")).isTrue
        assertThat(employeePrincipalAuthentication.hasAuthority("AuthorityABC")).isTrue
    }
}
