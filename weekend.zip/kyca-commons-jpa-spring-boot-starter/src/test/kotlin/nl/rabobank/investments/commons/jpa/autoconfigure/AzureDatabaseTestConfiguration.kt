package nl.rabobank.investments.commons.jpa.autoconfigure

import com.microsoft.aad.msal4j.ConfidentialClientApplication
import io.mockk.mockk
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Configuration
import org.springframework.context.annotation.Primary

@Configuration
@ConditionalOnProperty(
    prefix = "database.azure",
    name = ["enabled"],
    havingValue = "true",
    matchIfMissing = true
)
class AzureDatabaseTestConfiguration {
    val confidentialClientApplication: ConfidentialClientApplication = mockk()

    @Bean
    @Primary
    fun azureAADClient(): ConfidentialClientApplication {
        return confidentialClientApplication
    }
}
