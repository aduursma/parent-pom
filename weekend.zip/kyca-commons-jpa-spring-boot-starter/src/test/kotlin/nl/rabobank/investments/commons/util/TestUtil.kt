package nl.rabobank.investments.commons.util

import nl.rabobank.investments.commons.security.domain.CustomerPrincipal
import nl.rabobank.investments.commons.security.domain.EmployeePrincipal
import nl.rabobank.investments.commons.security.domain.Role

object TestUtil {

    fun getCustomerPrincipal(): CustomerPrincipal {
        val customerPrincipal = CustomerPrincipal()
        customerPrincipal.siebelCustomerRelationId = "AA11"
        customerPrincipal.siebelUserRelationId = "1111111"
        customerPrincipal.authUserType = Role.CUSTOMER
        customerPrincipal.authTicket = "authTicket"
        customerPrincipal.authSessionId = "authSessionId"
        customerPrincipal.authUserId = "authUserId"
        customerPrincipal.authUserLevel = "authUserLevel"
        customerPrincipal.edoKlid = "edoKlid"
        customerPrincipal.edoAgreementId = "edoAgreementId"
        customerPrincipal.edoUserId = "edoUserId"
        customerPrincipal.sources = listOf("source")
        return customerPrincipal
    }

    fun getEmployeePrincipal(): EmployeePrincipal {
        val employeePrincipal = EmployeePrincipal()
        employeePrincipal.employeePrincipalName = "TEST"
        employeePrincipal.rabobankId = "11ABC"
        employeePrincipal.employeeUniqueName = "UniqueName"
        employeePrincipal.organisationId = "organisationId"
        employeePrincipal.parentOrganisationId = "parentOrganisationId"
        return employeePrincipal
    }
}
