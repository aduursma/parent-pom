package nl.rabobank.investments.commons.jpa.domain.listener

import io.mockk.clearAllMocks
import io.mockk.every
import io.mockk.mockk
import io.mockk.mockkStatic
import nl.rabobank.investments.commons.util.TestUtil
import nl.rabobank.investments.commons.jpa.domain.AuditableEntity
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.domain.Role
import nl.rabobank.investments.commons.security.domain.RoleType
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.BeforeEach
import org.junit.jupiter.api.Test
import org.springframework.security.core.context.SecurityContextHolder
import org.springframework.security.core.context.SecurityContextImpl
import java.time.LocalDateTime

class CustomAuditingEntityListenerTest {
    private val securityContextImpl: SecurityContextImpl = mockk()
    private var auditableEntity = AuditableEntity()
    private val customerPrincipalAuthentication = PrincipalAuthentication(
        "token", TestUtil.getCustomerPrincipal(), Role.CUSTOMER
    )
    private val employeePrincipalAuthentication = PrincipalAuthentication(
        "token", TestUtil.getEmployeePrincipal(), Role.EMPLOYEE
    )
    private val principalAuthentication = PrincipalAuthentication(
        "token", TestUtil.getEmployeePrincipal(), Role.APPLICATION
    )
    private val opsPrincipalAuthentication = PrincipalAuthentication(
        "token", TestUtil.getEmployeePrincipal(), Role.OPS
    )

    private val customAuditingEntityListener: CustomAuditingEntityListener = CustomAuditingEntityListener()

    @BeforeEach
    fun setup() {
        clearAllMocks()
        mockkStatic(SecurityContextHolder::class)
        employeePrincipalAuthentication.isAuthenticated = true
        customerPrincipalAuthentication.isAuthenticated = true
        principalAuthentication.isAuthenticated = true
        opsPrincipalAuthentication.isAuthenticated = true
        every { SecurityContextHolder.getContext() } returns securityContextImpl
    }

    @Test
    fun `Happycase that testPrePersist with valid employee data`() {
        every { securityContextImpl.authentication } returns employeePrincipalAuthentication
        customAuditingEntityListener.createOn(auditableEntity)
        assertThat(auditableEntity.lastModifiedUserType).isEqualTo(RoleType.EMPLOYEE)
        assertThat(auditableEntity.lastModifiedTimestamp).isBeforeOrEqualTo(LocalDateTime.now())
        assertThat(auditableEntity.lastModifiedUserId).isEqualTo("11ABC")
        assertThat(auditableEntity.lastModifiedUserName).isEqualTo("UniqueName")
    }

    @Test
    fun `Happycase that testPrePersist with valid customer data`() {
        every { securityContextImpl.authentication } returns customerPrincipalAuthentication
        customAuditingEntityListener.createOn(auditableEntity)
        assertThat(auditableEntity.lastModifiedUserType).isEqualTo(RoleType.CUSTOMER)
        assertThat(auditableEntity.lastModifiedTimestamp).isBeforeOrEqualTo(LocalDateTime.now())
        assertThat(auditableEntity.lastModifiedUserId).isEqualTo("AA11")
        assertThat(auditableEntity.lastModifiedUserName).isEqualTo("CUSTOMER")
    }

    @Test
    fun `Happycase that testPrePersist allowed for Application`() {
        every { securityContextImpl.authentication } returns principalAuthentication
        customAuditingEntityListener.createOn(auditableEntity)
        assertThat(auditableEntity.lastModifiedUserType).isEqualTo(RoleType.APPLICATION)
        assertThat(auditableEntity.lastModifiedTimestamp).isBeforeOrEqualTo(LocalDateTime.now())
        assertThat(auditableEntity.lastModifiedUserId).isNull()
        assertThat(auditableEntity.lastModifiedUserName).isNull()
    }

    @Test
    fun `Happycase that testPrePersist allowed for Ops`() {
        every { securityContextImpl.authentication } returns opsPrincipalAuthentication
        customAuditingEntityListener.createOn(auditableEntity)
        assertThat(auditableEntity.lastModifiedUserType).isEqualTo(RoleType.OPS)
        assertThat(auditableEntity.lastModifiedTimestamp).isBeforeOrEqualTo(LocalDateTime.now())
        assertThat(auditableEntity.lastModifiedUserId).isNull()
        assertThat(auditableEntity.lastModifiedUserName).isNull()
    }

    @Test
    fun `Sadcase that testPrePersist with null data`() {
        every { securityContextImpl.authentication } returns null
        customAuditingEntityListener.createOn(auditableEntity)
        assertThat(auditableEntity.lastModifiedUserType).isNull()
        assertThat(auditableEntity.lastModifiedTimestamp).isNull()
        assertThat(auditableEntity.lastModifiedUserId).isNull()
        assertThat(auditableEntity.lastModifiedUserName).isNull()
    }

    @Test
    fun `Sadcase that testPreUpdate with valid customer data and update not allowed for Application`() {
        every { securityContextImpl.authentication } returns principalAuthentication
        customAuditingEntityListener.updateOn(auditableEntity)
        assertThat(auditableEntity.lastModifiedUserType).isNull()
        assertThat(auditableEntity.lastModifiedTimestamp).isNull()
        assertThat(auditableEntity.lastModifiedUserId).isNull()
        assertThat(auditableEntity.lastModifiedUserName).isNull()
    }

    @Test
    fun `Happycase that testPreUpdate with valid customer data and update allowed`() {
        every { securityContextImpl.authentication } returns customerPrincipalAuthentication
        customAuditingEntityListener.updateOn(auditableEntity)
        assertThat(auditableEntity.lastModifiedUserType).isEqualTo(RoleType.CUSTOMER)
        assertThat(auditableEntity.lastModifiedTimestamp).isBeforeOrEqualTo(LocalDateTime.now())
        assertThat(auditableEntity.lastModifiedUserId).isEqualTo("AA11")
        assertThat(auditableEntity.lastModifiedUserName).isEqualTo("CUSTOMER")
    }

    @Test
    fun `Happycase that testPreUpdate with valid employee data`() {
        every { securityContextImpl.authentication } returns employeePrincipalAuthentication
        customAuditingEntityListener.updateOn(auditableEntity)
        assertThat(auditableEntity.lastModifiedUserType).isEqualTo(RoleType.EMPLOYEE)
        assertThat(auditableEntity.lastModifiedTimestamp).isBeforeOrEqualTo(LocalDateTime.now())
        assertThat(auditableEntity.lastModifiedUserId).isEqualTo("11ABC")
        assertThat(auditableEntity.lastModifiedUserName).isEqualTo("UniqueName")
    }

    @Test
    fun `Happycase that testPreUpdate allowed for Ops`() {
        every { securityContextImpl.authentication } returns opsPrincipalAuthentication
        customAuditingEntityListener.updateOn(auditableEntity)
        assertThat(auditableEntity.lastModifiedUserType).isEqualTo(RoleType.OPS)
        assertThat(auditableEntity.lastModifiedTimestamp).isBeforeOrEqualTo(LocalDateTime.now())
        assertThat(auditableEntity.lastModifiedUserId).isNull()
        assertThat(auditableEntity.lastModifiedUserName).isNull()
    }

    @Test
    fun `Sadcase that testPreUpdate with null data`() {
        every { securityContextImpl.authentication } returns null
        customAuditingEntityListener.updateOn(auditableEntity)
        assertThat(auditableEntity.lastModifiedUserType).isNull()
        assertThat(auditableEntity.lastModifiedTimestamp).isNull()
        assertThat(auditableEntity.lastModifiedUserId).isNull()
    }
}
