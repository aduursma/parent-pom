package nl.rabobank.investments.commons.jpa.autoconfigure

import nl.rabobank.investments.commons.jpa.AzureDatabaseProperties
import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.springframework.boot.autoconfigure.AutoConfigurations
import org.springframework.boot.test.context.runner.ApplicationContextRunner

const val AZURE_DATABASE_ENABLED = "database.azure.enabled:true"
const val AZURE_DATABASE_DISABLED = "database.azure.enabled:false"
const val AZURE_DATABASE_PROPERTIES_BEAN_PREFIX = "database.azure"

class AzureDatabaseAutoConfigurationTest {

    private val contextRunner = ApplicationContextRunner()

    private val azureDatabaseProperties = arrayOf(
        "$AZURE_DATABASE_PROPERTIES_BEAN_PREFIX.databaseName:fake-database-name",
        "$AZURE_DATABASE_PROPERTIES_BEAN_PREFIX.databaseServerName:fake-database-server-name",
        "$AZURE_DATABASE_PROPERTIES_BEAN_PREFIX.oauthClientId:fake-oauth-client-id",
        "$AZURE_DATABASE_PROPERTIES_BEAN_PREFIX.oauthUrl:https//fake-ouath-url"
    )

    @Test
    fun `Azure related beans are present by default`() {
        verifyApplicationContext(
            true
        )
    }

    @Test
    fun `Azure related beans are present when azure is enabled`() {
        verifyApplicationContext(
            true,
            AZURE_DATABASE_ENABLED
        )
    }

    @Test
    fun `Azure related beans are not present when azure is disabled`() {
        verifyApplicationContext(
            false,
            AZURE_DATABASE_DISABLED
        )
    }

    private fun verifyApplicationContext(checkForPresence: Boolean, vararg pairs: String) {
        contextRunner
            .withAllowBeanDefinitionOverriding(true)
            .withPropertyValues(*pairs, *azureDatabaseProperties)
            .withConfiguration(
                AutoConfigurations.of(
                    AzureDatabaseAutoConfiguration::class.java,
                    AzureDatabaseTestConfiguration::class.java
                )
            )
            .run {
                val propertiesBeanName =
                    "$AZURE_DATABASE_PROPERTIES_BEAN_PREFIX-${AzureDatabaseProperties::class.qualifiedName}"
                if (checkForPresence) {
                    assertThat(it).hasBean(propertiesBeanName)

                    val azureDatabaseProperties = it.getBean(AzureDatabaseProperties::class.java)
                    assertThat(azureDatabaseProperties.databaseName).isEqualTo("fake-database-name")

                    assertThat(it).hasBean("azureDatabaseAutoConfiguration")
                    assertThat(it).hasBean("azureAADClient")
                    assertThat(it).hasBean("getDataSource")
                } else {
                    assertThat(it).doesNotHaveBean(propertiesBeanName)
                    assertThat(it).doesNotHaveBean("azureDatabaseAutoConfiguration")
                    assertThat(it).doesNotHaveBean("azureAADClient")
                    assertThat(it).doesNotHaveBean("getDataSource")
                }
            }
    }
}
