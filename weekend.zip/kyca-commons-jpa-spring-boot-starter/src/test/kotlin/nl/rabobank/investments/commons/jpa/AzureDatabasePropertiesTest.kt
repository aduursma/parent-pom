package nl.rabobank.investments.commons.jpa

import org.assertj.core.api.Assertions.assertThat
import org.junit.jupiter.api.Test
import org.junit.jupiter.api.extension.ExtendWith
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.test.context.TestPropertySource
import org.springframework.test.context.junit.jupiter.SpringExtension

@ExtendWith(SpringExtension::class)
@EnableConfigurationProperties(AzureDatabaseProperties::class)
@TestPropertySource("classpath:application-integration-test.properties")
class AzureDatabasePropertiesTest {

    @Autowired
    lateinit var properties: AzureDatabaseProperties

    @Test
    fun `Verify property injection from properties file`() {
        assertThat(properties.oauthUrl)
            .isEqualTo("https://login.microsoftonline.com/bla-bla-bla/oauth2/token")
        assertThat(properties.oauthClientId).isEqualTo("fake-oauth-client-id")
        assertThat(properties.databaseName).isEqualTo("fake-database-name")
        assertThat(properties.databaseServerName).isEqualTo("database-server-name.database.windows.net")
    }
}
