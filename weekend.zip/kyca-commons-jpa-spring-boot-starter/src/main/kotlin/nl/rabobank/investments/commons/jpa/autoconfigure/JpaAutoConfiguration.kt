package nl.rabobank.investments.commons.jpa.autoconfigure

import org.springframework.boot.autoconfigure.AutoConfiguration
import org.springframework.data.jpa.repository.config.EnableJpaAuditing

@EnableJpaAuditing
@AutoConfiguration
class JpaAutoConfiguration
