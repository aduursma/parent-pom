package nl.rabobank.investments.commons.jpa.autoconfigure

import com.microsoft.aad.msal4j.ClientCredentialFactory
import com.microsoft.aad.msal4j.ConfidentialClientApplication
import com.microsoft.aad.msal4j.IClientCredential
import nl.rabobank.investments.commons.jpa.AzureDatabaseProperties
import nl.rabobank.investments.commons.jpa.AzureTokenProvider
import nl.rabobank.investments.commons.jpa.AzureTokenRefreshingDataSource
import org.springframework.boot.autoconfigure.AutoConfiguration
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.boot.context.properties.EnableConfigurationProperties
import org.springframework.context.annotation.Bean
import org.springframework.context.annotation.Import
import java.security.PrivateKey
import java.security.cert.X509Certificate
import javax.sql.DataSource

@AutoConfiguration
@EnableConfigurationProperties(value = [AzureDatabaseProperties::class])
@Import(AzureTokenProvider::class)
@ConditionalOnProperty(
    prefix = "database.azure",
    name = ["enabled"],
    havingValue = "true",
    matchIfMissing = true
)
class AzureDatabaseAutoConfiguration(val properties: AzureDatabaseProperties) {

    @Bean
    fun getDataSource(azureTokenProvider: AzureTokenProvider): DataSource {

        return AzureTokenRefreshingDataSource(azureTokenProvider).apply {
            serverName = properties.databaseServerName
            databaseName = properties.databaseName
        }
    }

    @Bean
    fun azureAADClient(privateKey: PrivateKey, certificate: X509Certificate): ConfidentialClientApplication {
        val credential: IClientCredential = ClientCredentialFactory.createFromCertificate(privateKey, certificate)
        return ConfidentialClientApplication.builder(properties.oauthClientId, credential)
            .authority(properties.oauthUrl)
            .build()
    }
}
