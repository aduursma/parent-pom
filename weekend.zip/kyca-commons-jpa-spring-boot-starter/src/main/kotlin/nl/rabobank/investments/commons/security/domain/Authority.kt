package nl.rabobank.investments.commons.security.domain

object Authority {
    const val ROLE_OPS = "ROLE_OPS"
    const val ROLE_APPLICATION = "ROLE_APPLICATION"
    const val ROLE_EMPLOYEE = "ROLE_EMPLOYEE"
    const val ROLE_CUSTOMER = "ROLE_CUSTOMER"
}
