package nl.rabobank.investments.commons.security.domain

object Role {
    const val OPS = "OPS"
    const val APPLICATION = "APPLICATION"
    const val EMPLOYEE = "EMPLOYEE"
    const val CUSTOMER = "CUSTOMER"
}

enum class RoleType {
    CUSTOMER, EMPLOYEE, APPLICATION, OPS
}
