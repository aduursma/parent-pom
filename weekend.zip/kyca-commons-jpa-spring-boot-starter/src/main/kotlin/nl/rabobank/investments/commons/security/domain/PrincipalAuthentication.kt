package nl.rabobank.investments.commons.security.domain

import org.springframework.security.authentication.AbstractAuthenticationToken
import org.springframework.security.core.AuthenticatedPrincipal
import org.springframework.security.core.GrantedAuthority
import org.springframework.security.core.authority.SimpleGrantedAuthority
import org.springframework.util.CollectionUtils
import kotlin.collections.ArrayList

class PrincipalAuthentication : AbstractAuthenticationToken {
    private val token: String?
    private val principal: AuthenticatedPrincipal

    constructor(
        token: String?,
        principal: AuthenticatedPrincipal,
        role: String,
        authorities: Collection<String?>?
    ) : super(grantedAuthorities(listOf<String>(role), authorities)) {
        this.token = token
        this.principal = principal
    }

    constructor(
        token: String,
        principal: AuthenticatedPrincipal,
        role: String
    ) : super(grantedAuthorities(listOf<String>(role), null)) {
        this.token = token
        this.principal = principal
    }

    override fun getCredentials(): Any? {
        return token
    }

    override fun getPrincipal(): AuthenticatedPrincipal {
        return principal
    }

    fun hasRole(role: String): Boolean {
        return authorities.contains(roleAuthority(role))
    }

    fun hasAuthority(authority: String?): Boolean {
        return authorities.contains(SimpleGrantedAuthority(authority))
    }

    companion object {
        private const val serialVersionUID = 4560095433463575130L
        fun roleAuthority(role: String): SimpleGrantedAuthority {
            return SimpleGrantedAuthority(String.format("ROLE_%s", role))
        }
        fun grantedAuthorities(
            roles: Collection<String>,
            authorities: Collection<String?>?
        ): Collection<GrantedAuthority> {
            val grantedAuthorities: MutableList<GrantedAuthority> = ArrayList()
            for (role in roles) {
                grantedAuthorities.add(roleAuthority(role))
            }
            if (!CollectionUtils.isEmpty(authorities)) {
                for (authority in authorities!!) {
                    grantedAuthorities.add(SimpleGrantedAuthority(authority))
                }
            }
            return grantedAuthorities
        }
    }
}
