package nl.rabobank.investments.commons.jpa

import com.microsoft.sqlserver.jdbc.SQLServerDataSource
import java.sql.Connection

class AzureTokenRefreshingDataSource(private val azureTokenProvider: AzureTokenProvider) : SQLServerDataSource() {

    override fun getConnection(): Connection {
        this.accessToken = this.azureTokenProvider.getDatabaseAccessToken()
        return super.getConnection()
    }
}
