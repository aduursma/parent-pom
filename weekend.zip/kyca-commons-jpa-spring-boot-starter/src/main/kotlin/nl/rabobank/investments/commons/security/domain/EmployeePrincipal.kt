package nl.rabobank.investments.commons.security.domain

import org.springframework.security.core.AuthenticatedPrincipal

class EmployeePrincipal : AuthenticatedPrincipal {
    var employeePrincipalName: String? = null
    var organisationId: String? = null
    var parentOrganisationId: String? = null
    var rabobankId: String? = null
    var employeeUniqueName: String? = null

    override fun getName(): String? {
        return employeePrincipalName
    }
}
