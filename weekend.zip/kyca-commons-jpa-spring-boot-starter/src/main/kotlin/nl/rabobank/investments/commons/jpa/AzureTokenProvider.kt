package nl.rabobank.investments.commons.jpa

import com.microsoft.aad.msal4j.ClientCredentialParameters
import com.microsoft.aad.msal4j.ConfidentialClientApplication
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.stereotype.Component

const val DATABASE_SCOPE = "https://database.windows.net/.default"

@Component
@ConditionalOnProperty(
    prefix = "database.azure",
    name = ["enabled"],
    havingValue = "true",
    matchIfMissing = true
)
class AzureTokenProvider(
    private val azureAADClient: ConfidentialClientApplication
) {
    fun getDatabaseAccessToken(): String {
        val parameters = ClientCredentialParameters.builder(setOf(DATABASE_SCOPE)).build()
        val authenticationResult = azureAADClient.acquireToken(parameters).join()
        return authenticationResult.accessToken()
    }
}
