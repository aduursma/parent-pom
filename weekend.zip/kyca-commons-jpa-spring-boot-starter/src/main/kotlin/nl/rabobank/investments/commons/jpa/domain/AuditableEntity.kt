package nl.rabobank.investments.commons.jpa.domain

import jakarta.persistence.Column
import jakarta.persistence.EntityListeners
import jakarta.persistence.EnumType
import jakarta.persistence.Enumerated
import jakarta.persistence.MappedSuperclass
import nl.rabobank.investments.commons.jpa.domain.listener.CustomAuditingEntityListener
import nl.rabobank.investments.commons.security.domain.RoleType
import org.springframework.data.annotation.CreatedDate
import org.springframework.data.jpa.domain.support.AuditingEntityListener
import java.time.LocalDateTime

@MappedSuperclass
@EntityListeners(AuditingEntityListener::class, CustomAuditingEntityListener::class)
open class AuditableEntity {
    @CreatedDate
    var createdDate: LocalDateTime? = null

    @Column(name = "last_modified_user_id")
    var lastModifiedUserId: String? = null

    @Column(name = "last_modified_user_name")
    var lastModifiedUserName: String? = null

    @Column(name = "last_modified_user_type")
    @Enumerated(EnumType.STRING)
    var lastModifiedUserType: RoleType? = null

    @Column(name = "last_modified_timestamp")
    var lastModifiedTimestamp: LocalDateTime? = null
}
