package nl.rabobank.investments.commons.security.domain

import com.fasterxml.jackson.annotation.JsonIgnoreProperties
import org.springframework.security.core.AuthenticatedPrincipal

@JsonIgnoreProperties(ignoreUnknown = true)
class ApplicationPrincipal(private val applicationPrincipalName: String) : AuthenticatedPrincipal {
    override fun getName(): String {
        return applicationPrincipalName
    }
}
