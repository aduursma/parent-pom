package nl.rabobank.investments.commons.jpa

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty
import org.springframework.boot.context.properties.ConfigurationProperties

@ConfigurationProperties("database.azure")
@ConditionalOnProperty(
    prefix = "database.azure",
    name = ["enabled"],
    havingValue = "true",
    matchIfMissing = true
)
class AzureDatabaseProperties(
    val oauthUrl: String,
    val oauthClientId: String,
    val databaseName: String,
    val databaseServerName: String
)
