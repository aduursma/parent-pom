package nl.rabobank.investments.commons.jpa.domain.listener

import jakarta.persistence.PrePersist
import jakarta.persistence.PreUpdate
import nl.rabobank.investments.commons.jpa.domain.AuditableEntity
import nl.rabobank.investments.commons.security.domain.CustomerPrincipal
import nl.rabobank.investments.commons.security.domain.EmployeePrincipal
import nl.rabobank.investments.commons.security.domain.PrincipalAuthentication
import nl.rabobank.investments.commons.security.domain.Role
import nl.rabobank.investments.commons.security.domain.RoleType
import org.springframework.security.core.Authentication
import org.springframework.security.core.context.SecurityContextHolder
import java.time.LocalDateTime

class CustomAuditingEntityListener {

    @PrePersist
    fun createOn(auditableEntity: AuditableEntity) {
        val principalAuthentication = SecurityContextHolder.getContext().authentication as PrincipalAuthentication?
        principalAuthentication?.let {
            when {
                it.hasRole(Role.CUSTOMER) -> {
                    doCustomerAudit(auditableEntity)
                }
                it.hasRole(Role.EMPLOYEE) -> {
                    doEmployeeAudit(auditableEntity)
                }
                it.hasRole(Role.APPLICATION) -> {
                    doApplicationAudit(auditableEntity)
                }
                it.hasRole(Role.OPS) -> {
                    doOpsAudit(auditableEntity)
                }
            }
        }
    }

    @PreUpdate
    fun updateOn(auditableEntity: AuditableEntity) {
        val principalAuthentication = SecurityContextHolder.getContext().authentication as PrincipalAuthentication?
        principalAuthentication?.let {
            when {
                it.hasRole(Role.CUSTOMER) -> {
                    doCustomerAudit(auditableEntity)
                }
                it.hasRole(Role.EMPLOYEE) -> {
                    doEmployeeAudit(auditableEntity)
                }
                it.hasRole(Role.OPS) -> {
                    doOpsAudit(auditableEntity)
                }
            }
        }
    }

    private fun doCustomerAudit(auditableEntity: AuditableEntity) {
        auditableEntity.lastModifiedUserId = getAuthenticatedUserId()
        auditableEntity.lastModifiedTimestamp = LocalDateTime.now()
        auditableEntity.lastModifiedUserType = RoleType.CUSTOMER
        auditableEntity.lastModifiedUserName = RoleType.CUSTOMER.name
    }

    private fun doEmployeeAudit(auditableEntity: AuditableEntity) {
        auditableEntity.lastModifiedUserId = getAuthenticatedEmployeeId()
        auditableEntity.lastModifiedTimestamp = LocalDateTime.now()
        auditableEntity.lastModifiedUserType = RoleType.EMPLOYEE
        auditableEntity.lastModifiedUserName = getAuthenticatedEmployeeName()
    }

    private fun doOpsAudit(auditableEntity: AuditableEntity) {
        auditableEntity.lastModifiedTimestamp = LocalDateTime.now()
        auditableEntity.lastModifiedUserType = RoleType.OPS
    }

    private fun doApplicationAudit(auditableEntity: AuditableEntity) {
        auditableEntity.lastModifiedTimestamp = LocalDateTime.now()
        auditableEntity.lastModifiedUserType = RoleType.APPLICATION
    }

    private fun getAuthenticatedUserId(): String? {
        val authentication: Authentication? = SecurityContextHolder.getContext().authentication
        return if (authentication == null || !authentication.isAuthenticated) {
            null
        } else (authentication.principal as CustomerPrincipal).siebelCustomerRelationId
    }

    private fun getAuthenticatedEmployeeName(): String? {
        val authentication: Authentication? = SecurityContextHolder.getContext().authentication
        return if (authentication == null || !authentication.isAuthenticated) {
            null
        } else (authentication.principal as EmployeePrincipal).employeeUniqueName
    }

    private fun getAuthenticatedEmployeeId(): String? {
        val authentication: Authentication? = SecurityContextHolder.getContext().authentication
        return if (authentication == null || !authentication.isAuthenticated) {
            null
        } else (authentication.principal as EmployeePrincipal).rabobankId
    }
}
