[![Build Status](https://dev.azure.com/raboweb/Investments/_apis/build/status/expedite-commons-jpa-spring-boot-starter?repoName=expedite-commons-jpa-spring-boot-starter&branchName=master)](https://dev.azure.com/raboweb/Investments/_build/latest?definitionId=24463&repoName=expedite-commons-jpa-spring-boot-starter&branchName=master)

# Introduction
This project is a Spring Boot starter for adding JPA to your Spring Boot application and configure access to an Azure database running either on `DevTest` or `Production`.

# Getting Started
Just add this project as a dependency to the Maven project you want to have JPA enabled for and accessing an Azure database, replacing the version number with the actual latest version number.

```
<parent>
    <groupId>nl.rabobank.investments.sales</groupId>
    <artifactId>kyca-commons-jpa-spring-boot-starter</artifactId>
    <version>...</version>
</parent>
```
